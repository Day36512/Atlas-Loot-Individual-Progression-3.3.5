-- Auto-generated from the local AckisRecipeList database.
-- This file is self-contained and does not require AckisRecipeList at runtime.
AtlasLoot_CraftingSourceData = {
    [2149] = {
        p = "Leatherworking",
        skill = 1,
        item = 2302,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2152] = {
        p = "Leatherworking",
        skill = 1,
        item = 2304,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2153] = {
        p = "Leatherworking",
        skill = 15,
        item = 2303,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2158] = {
        p = "Leatherworking",
        skill = 90,
        item = 2307,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2159] = {
        p = "Leatherworking",
        skill = 85,
        item = 2308,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2160] = {
        p = "Leatherworking",
        skill = 40,
        item = 2300,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2161] = {
        p = "Leatherworking",
        skill = 55,
        item = 2309,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2162] = {
        p = "Leatherworking",
        skill = 60,
        item = 2310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2163] = {
        p = "Leatherworking",
        skill = 60,
        item = 2311,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2164] = {
        p = "Leatherworking",
        skill = 75,
        item = 2312,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2165] = {
        p = "Leatherworking",
        skill = 100,
        item = 2313,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2166] = {
        p = "Leatherworking",
        skill = 120,
        item = 2314,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2167] = {
        p = "Leatherworking",
        skill = 100,
        item = 2315,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2168] = {
        p = "Leatherworking",
        skill = 110,
        item = 2316,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2169] = {
        p = "Leatherworking",
        skill = 100,
        item = 2317,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2329] = {
        p = "Alchemy",
        skill = 1,
        item = 2454,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2330] = {
        p = "Alchemy",
        skill = 1,
        item = 118,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2331] = {
        p = "Alchemy",
        skill = 25,
        item = 2455,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2332] = {
        p = "Alchemy",
        skill = 40,
        item = 2456,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2333] = {
        p = "Alchemy",
        skill = 140,
        item = 3390,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2334] = {
        p = "Alchemy",
        skill = 50,
        item = 2458,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2335] = {
        p = "Alchemy",
        skill = 60,
        item = 2459,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2337] = {
        p = "Alchemy",
        skill = 55,
        item = 858,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2385] = {
        p = "Tailoring",
        skill = 10,
        item = 2568,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2386] = {
        p = "Tailoring",
        skill = 65,
        item = 2569,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2387] = {
        p = "Tailoring",
        skill = 1,
        item = 2570,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2389] = {
        p = "Tailoring",
        skill = 40,
        item = 2572,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2392] = {
        p = "Tailoring",
        skill = 40,
        item = 2575,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2393] = {
        p = "Tailoring",
        skill = 1,
        item = 2576,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2394] = {
        p = "Tailoring",
        skill = 40,
        item = 2577,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2395] = {
        p = "Tailoring",
        skill = 70,
        item = 2578,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2396] = {
        p = "Tailoring",
        skill = 70,
        item = 2579,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2397] = {
        p = "Tailoring",
        skill = 60,
        item = 2580,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2399] = {
        p = "Tailoring",
        skill = 85,
        item = 2582,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2401] = {
        p = "Tailoring",
        skill = 95,
        item = 2583,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2402] = {
        p = "Tailoring",
        skill = 75,
        item = 2584,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2403] = {
        p = "Tailoring",
        skill = 105,
        item = 2585,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2406] = {
        p = "Tailoring",
        skill = 100,
        item = 2587,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2538] = {
        p = "Cooking",
        skill = 1,
        item = 2679,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2539] = {
        p = "Cooking",
        skill = 10,
        item = 2680,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2540] = {
        p = "Cooking",
        skill = 1,
        item = 2681,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2541] = {
        p = "Cooking",
        skill = 50,
        item = 2684,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2542] = {
        p = "Cooking",
        skill = 50,
        item = 724,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #22 (Westfall 55.77, 30.92)",
            } },
        },
    },
    [2543] = {
        p = "Cooking",
        skill = 75,
        item = 733,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #38 (Westfall 55.77, 30.92)",
            } },
        },
    },
    [2544] = {
        p = "Cooking",
        skill = 75,
        item = 2683,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2545] = {
        p = "Cooking",
        skill = 85,
        item = 2682,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "World Drop", d = {
                "Darkshore",
                "Westfall",
            } },
        },
    },
    [2546] = {
        p = "Cooking",
        skill = 80,
        item = 2687,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2547] = {
        p = "Cooking",
        skill = 100,
        item = 1082,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #92 (Redridge Mountains 22.7, 44)",
            } },
        },
    },
    [2548] = {
        p = "Cooking",
        skill = 110,
        item = 2685,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "World Drop", d = {
                "Loch Modan",
                "Redridge Mountains",
            } },
        },
    },
    [2549] = {
        p = "Cooking",
        skill = 100,
        item = 1017,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #90 (Duskwood 73.8, 43.7)",
            } },
        },
    },
    [2657] = {
        p = "Mining",
        skill = 1,
        item = 2840,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2658] = {
        p = "Mining",
        skill = 75,
        item = 2842,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2659] = {
        p = "Mining",
        skill = 65,
        item = 2841,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2660] = {
        p = "Blacksmithing",
        skill = 1,
        item = 2862,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2661] = {
        p = "Blacksmithing",
        skill = 35,
        item = 2851,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2662] = {
        p = "Blacksmithing",
        skill = 1,
        item = 2852,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2663] = {
        p = "Blacksmithing",
        skill = 1,
        item = 2853,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2664] = {
        p = "Blacksmithing",
        skill = 90,
        item = 2854,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2665] = {
        p = "Blacksmithing",
        skill = 65,
        item = 2863,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2666] = {
        p = "Blacksmithing",
        skill = 70,
        item = 2857,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2667] = {
        p = "Blacksmithing",
        skill = 80,
        item = 2864,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2668] = {
        p = "Blacksmithing",
        skill = 105,
        item = 2865,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2670] = {
        p = "Blacksmithing",
        skill = 105,
        item = 2866,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2672] = {
        p = "Blacksmithing",
        skill = 120,
        item = 2868,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2673] = {
        p = "Blacksmithing",
        skill = 130,
        item = 2869,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [2674] = {
        p = "Blacksmithing",
        skill = 125,
        item = 2871,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2675] = {
        p = "Blacksmithing",
        skill = 145,
        item = 2870,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2737] = {
        p = "Blacksmithing",
        skill = 15,
        item = 2844,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2738] = {
        p = "Blacksmithing",
        skill = 20,
        item = 2845,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2739] = {
        p = "Blacksmithing",
        skill = 25,
        item = 2847,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2740] = {
        p = "Blacksmithing",
        skill = 110,
        item = 2848,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2741] = {
        p = "Blacksmithing",
        skill = 115,
        item = 2849,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2742] = {
        p = "Blacksmithing",
        skill = 120,
        item = 2850,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [2795] = {
        p = "Cooking",
        skill = 10,
        item = 2888,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #384 (Dun Morogh 46.8, 52.5)",
            } },
        },
    },
    [2881] = {
        p = "Leatherworking",
        skill = 1,
        item = 2318,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2963] = {
        p = "Tailoring",
        skill = 1,
        item = 2996,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [2964] = {
        p = "Tailoring",
        skill = 75,
        item = 2997,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3115] = {
        p = "Blacksmithing",
        skill = 1,
        item = 3239,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3116] = {
        p = "Blacksmithing",
        skill = 65,
        item = 3240,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3117] = {
        p = "Blacksmithing",
        skill = 125,
        item = 3241,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3170] = {
        p = "Alchemy",
        skill = 15,
        item = 3382,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3171] = {
        p = "Alchemy",
        skill = 90,
        item = 3383,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3172] = {
        p = "Alchemy",
        skill = 110,
        item = 3384,
        q = "Common",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3173] = {
        p = "Alchemy",
        skill = 120,
        item = 3385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3174] = {
        p = "Alchemy",
        skill = 120,
        item = 3386,
        q = "Common",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3175] = {
        p = "Alchemy",
        skill = 250,
        item = 3387,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3176] = {
        p = "Alchemy",
        skill = 125,
        item = 3388,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3177] = {
        p = "Alchemy",
        skill = 130,
        item = 3389,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3188] = {
        p = "Alchemy",
        skill = 150,
        item = 3391,
        q = "Common",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3230] = {
        p = "Alchemy",
        skill = 50,
        item = 2457,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3275] = {
        p = "First Aid",
        skill = 1,
        item = 1251,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3276] = {
        p = "First Aid",
        skill = 40,
        item = 2581,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3277] = {
        p = "First Aid",
        skill = 80,
        item = 3530,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3278] = {
        p = "First Aid",
        skill = 115,
        item = 3531,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3292] = {
        p = "Blacksmithing",
        skill = 95,
        item = 3487,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3293] = {
        p = "Blacksmithing",
        skill = 35,
        item = 3488,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3294] = {
        p = "Blacksmithing",
        skill = 70,
        item = 3489,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3295] = {
        p = "Blacksmithing",
        skill = 125,
        item = 3490,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3296] = {
        p = "Blacksmithing",
        skill = 130,
        item = 3491,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3297] = {
        p = "Blacksmithing",
        skill = 145,
        item = 3492,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3304] = {
        p = "Mining",
        skill = 65,
        item = 3576,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3307] = {
        p = "Mining",
        skill = 125,
        item = 3575,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3308] = {
        p = "Mining",
        skill = 155,
        item = 3577,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3319] = {
        p = "Blacksmithing",
        skill = 20,
        item = 3469,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3320] = {
        p = "Blacksmithing",
        skill = 25,
        item = 3470,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3321] = {
        p = "Blacksmithing",
        skill = 35,
        item = 3471,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3323] = {
        p = "Blacksmithing",
        skill = 40,
        item = 3472,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3324] = {
        p = "Blacksmithing",
        skill = 45,
        item = 3473,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3325] = {
        p = "Blacksmithing",
        skill = 60,
        item = 3474,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3326] = {
        p = "Blacksmithing",
        skill = 75,
        item = 3478,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3328] = {
        p = "Blacksmithing",
        skill = 110,
        item = 3480,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3330] = {
        p = "Blacksmithing",
        skill = 125,
        item = 3481,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3331] = {
        p = "Blacksmithing",
        skill = 130,
        item = 3482,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3333] = {
        p = "Blacksmithing",
        skill = 135,
        item = 3483,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3334] = {
        p = "Blacksmithing",
        skill = 145,
        item = 3484,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3336] = {
        p = "Blacksmithing",
        skill = 150,
        item = 3485,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3337] = {
        p = "Blacksmithing",
        skill = 125,
        item = 3486,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3370] = {
        p = "Cooking",
        skill = 80,
        item = 3662,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #385 (Loch Modan 81.8, 61.7)",
            } },
        },
    },
    [3371] = {
        p = "Cooking",
        skill = 60,
        item = 3220,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #418 (Loch Modan 34.8, 49.1)",
            } },
        },
    },
    [3372] = {
        p = "Cooking",
        skill = 90,
        item = 3663,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #127 (Redridge Mountains 27.8, 47.3)",
            } },
        },
    },
    [3373] = {
        p = "Cooking",
        skill = 120,
        item = 3664,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #471 (Wetlands 8.6, 55.7)",
            } },
        },
    },
    [3376] = {
        p = "Cooking",
        skill = 130,
        item = 3665,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nerrist (Stranglethorn Vale 32.7, 29.2)",
                "Keena (Arathi Highlands 74, 32.7)",
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #296 (Wetlands 38, 49.9)",
            } },
        },
    },
    [3377] = {
        p = "Cooking",
        skill = 110,
        item = 3666,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kendor Kabonka (Stormwind City 77.5, 53.5)",
            } },
            { t = "Quest", d = {
                "Quest #93 (Duskwood 73.8, 43.7)",
            } },
        },
    },
    [3397] = {
        p = "Cooking",
        skill = 110,
        item = 3726,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ulthaan (Ashenvale 50, 66.7)",
            } },
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
            { t = "Quest", d = {
                "Quest #498 (Hillsbrad Foothills 63.2, 20.7)",
            } },
        },
    },
    [3398] = {
        p = "Cooking",
        skill = 125,
        item = 3727,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zargh (The Barrens 52.6, 29.9)",
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
            } },
            { t = "Quest", d = {
                "Quest #501 (Hillsbrad Foothills 61.5, 19.2)",
            } },
        },
    },
    [3399] = {
        p = "Cooking",
        skill = 150,
        item = 3728,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #564 (Hillsbrad Foothills 52.4, 56)",
            } },
        },
    },
    [3400] = {
        p = "Cooking",
        skill = 175,
        item = 3729,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #555 (Hillsbrad Foothills 51.8, 58.7)",
                "Quest #7321 (Hillsbrad Foothills 62.4, 19.1)",
            } },
        },
    },
    [3447] = {
        p = "Alchemy",
        skill = 110,
        item = 929,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3448] = {
        p = "Alchemy",
        skill = 165,
        item = 3823,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3449] = {
        p = "Alchemy",
        skill = 165,
        item = 3824,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Bliztik (Duskwood 18, 54.5)",
                "Montarr (Thousand Needles 45.2, 50.7)",
            } },
        },
    },
    [3450] = {
        p = "Alchemy",
        skill = 175,
        item = 3825,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3451] = {
        p = "Alchemy",
        skill = 180,
        item = 3826,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3452] = {
        p = "Alchemy",
        skill = 160,
        item = 3827,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3453] = {
        p = "Alchemy",
        skill = 195,
        item = 3828,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3454] = {
        p = "Alchemy",
        skill = 200,
        item = 3829,
        q = "Uncommon",
        sources = {
            { t = "Limited Vendor", d = {
                "Bro'kin (Alterac Mountains 38.3, 38.8)",
            } },
        },
    },
    [3491] = {
        p = "Blacksmithing",
        skill = 105,
        item = 3848,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3492] = {
        p = "Blacksmithing",
        skill = 160,
        item = 3849,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Jutak (Stranglethorn Vale 27.5, 77.5)",
                "Kaita Deepforge (Stormwind City 63.5, 37.6)",
            } },
        },
    },
    [3493] = {
        p = "Blacksmithing",
        skill = 175,
        item = 3850,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3494] = {
        p = "Blacksmithing",
        skill = 155,
        item = 3851,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Jazzrik (Badlands 42.5, 52.6)",
                "Muuran (Desolace 55.6, 56.5)",
                "Jannos Ironwill (Arathi Highlands 46, 47.7)",
                "High Admiral \"Shelly\" Jorrik (Dun Morogh 10.9, 76.1)",
            } },
        },
    },
    [3495] = {
        p = "Blacksmithing",
        skill = 170,
        item = 3852,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3496] = {
        p = "Blacksmithing",
        skill = 180,
        item = 3853,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zarena Cromwind (Stranglethorn Vale 28.4, 75.5)",
            } },
        },
    },
    [3497] = {
        p = "Blacksmithing",
        skill = 200,
        item = 3854,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3498] = {
        p = "Blacksmithing",
        skill = 185,
        item = 3855,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Jaquilina Dramet (Stranglethorn Vale 35.7, 10.7)",
                "Vharr (Stranglethorn Vale 32.3, 28)",
            } },
        },
    },
    [3500] = {
        p = "Blacksmithing",
        skill = 200,
        item = 3856,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3501] = {
        p = "Blacksmithing",
        skill = 165,
        item = 3835,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3502] = {
        p = "Blacksmithing",
        skill = 170,
        item = 3836,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3503] = {
        p = "Blacksmithing",
        skill = 190,
        item = 3837,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Krinkle Goodsteel (Tanaris 51.5, 28.8)",
            } },
        },
    },
    [3504] = {
        p = "Blacksmithing",
        skill = 160,
        item = 3840,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3505] = {
        p = "Blacksmithing",
        skill = 175,
        item = 3841,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3506] = {
        p = "Blacksmithing",
        skill = 155,
        item = 3842,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3507] = {
        p = "Blacksmithing",
        skill = 170,
        item = 3843,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3508] = {
        p = "Blacksmithing",
        skill = 180,
        item = 3844,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3511] = {
        p = "Blacksmithing",
        skill = 195,
        item = 3845,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3513] = {
        p = "Blacksmithing",
        skill = 185,
        item = 3846,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3515] = {
        p = "Blacksmithing",
        skill = 200,
        item = 3847,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3569] = {
        p = "Mining",
        skill = 165,
        item = 3859,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3753] = {
        p = "Leatherworking",
        skill = 25,
        item = 4237,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3755] = {
        p = "Tailoring",
        skill = 45,
        item = 4238,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3756] = {
        p = "Leatherworking",
        skill = 55,
        item = 4239,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3757] = {
        p = "Tailoring",
        skill = 80,
        item = 4240,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3758] = {
        p = "Tailoring",
        skill = 95,
        item = 4241,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3759] = {
        p = "Leatherworking",
        skill = 75,
        item = 4242,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3760] = {
        p = "Leatherworking",
        skill = 150,
        item = 3719,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3761] = {
        p = "Leatherworking",
        skill = 85,
        item = 4243,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3762] = {
        p = "Leatherworking",
        skill = 100,
        item = 4244,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3763] = {
        p = "Leatherworking",
        skill = 80,
        item = 4246,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3764] = {
        p = "Leatherworking",
        skill = 145,
        item = 4247,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3765] = {
        p = "Leatherworking",
        skill = 120,
        item = 4248,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3766] = {
        p = "Leatherworking",
        skill = 125,
        item = 4249,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3767] = {
        p = "Leatherworking",
        skill = 120,
        item = 4250,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3768] = {
        p = "Leatherworking",
        skill = 130,
        item = 4251,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3769] = {
        p = "Leatherworking",
        skill = 140,
        item = 4252,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3770] = {
        p = "Leatherworking",
        skill = 135,
        item = 4253,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3771] = {
        p = "Leatherworking",
        skill = 150,
        item = 4254,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3772] = {
        p = "Leatherworking",
        skill = 155,
        item = 4255,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Wenna Silkbeard (Wetlands 25.7, 25.8)",
                "George Candarte (Hillsbrad Foothills 92, 38.4)",
            } },
        },
    },
    [3773] = {
        p = "Leatherworking",
        skill = 175,
        item = 4256,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3774] = {
        p = "Leatherworking",
        skill = 160,
        item = 4257,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3775] = {
        p = "Leatherworking",
        skill = 170,
        item = 4258,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3776] = {
        p = "Leatherworking",
        skill = 180,
        item = 4259,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3777] = {
        p = "Leatherworking",
        skill = 195,
        item = 4260,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3778] = {
        p = "Leatherworking",
        skill = 185,
        item = 4262,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rikqiz (Stranglethorn Vale 28.5, 76)",
            } },
        },
    },
    [3779] = {
        p = "Leatherworking",
        skill = 200,
        item = 4264,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3780] = {
        p = "Leatherworking",
        skill = 150,
        item = 4265,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3813] = {
        p = "Tailoring",
        skill = 150,
        item = 4245,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3816] = {
        p = "Leatherworking",
        skill = 35,
        item = 4231,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3817] = {
        p = "Leatherworking",
        skill = 100,
        item = 4233,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3818] = {
        p = "Leatherworking",
        skill = 150,
        item = 4236,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3839] = {
        p = "Tailoring",
        skill = 125,
        item = 4305,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3840] = {
        p = "Tailoring",
        skill = 35,
        item = 4307,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3841] = {
        p = "Tailoring",
        skill = 60,
        item = 4308,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3842] = {
        p = "Tailoring",
        skill = 70,
        item = 4309,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3843] = {
        p = "Tailoring",
        skill = 85,
        item = 4310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3844] = {
        p = "Tailoring",
        skill = 100,
        item = 4311,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3845] = {
        p = "Tailoring",
        skill = 80,
        item = 4312,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3847] = {
        p = "Tailoring",
        skill = 95,
        item = 4313,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3848] = {
        p = "Tailoring",
        skill = 110,
        item = 4314,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3849] = {
        p = "Tailoring",
        skill = 120,
        item = 4315,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3850] = {
        p = "Tailoring",
        skill = 110,
        item = 4316,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3851] = {
        p = "Tailoring",
        skill = 125,
        item = 4317,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3852] = {
        p = "Tailoring",
        skill = 130,
        item = 4318,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3854] = {
        p = "Tailoring",
        skill = 145,
        item = 4319,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Wenna Silkbeard (Wetlands 25.7, 25.8)",
                "Kireena (Desolace 51, 53.5)",
            } },
        },
    },
    [3855] = {
        p = "Tailoring",
        skill = 125,
        item = 4320,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3856] = {
        p = "Tailoring",
        skill = 140,
        item = 4321,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3857] = {
        p = "Tailoring",
        skill = 165,
        item = 4322,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Xizk Goodstitch (Stranglethorn Vale 28.7, 76.8)",
            } },
        },
    },
    [3858] = {
        p = "Tailoring",
        skill = 170,
        item = 4323,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3859] = {
        p = "Tailoring",
        skill = 150,
        item = 4324,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3860] = {
        p = "Tailoring",
        skill = 175,
        item = 4325,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3861] = {
        p = "Tailoring",
        skill = 185,
        item = 4326,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3862] = {
        p = "Tailoring",
        skill = 200,
        item = 4327,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Ghok'kah (Dustwallow Marsh 35.2, 30.8)",
            } },
        },
    },
    [3863] = {
        p = "Tailoring",
        skill = 180,
        item = 4328,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3864] = {
        p = "Tailoring",
        skill = 200,
        item = 4329,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3865] = {
        p = "Tailoring",
        skill = 175,
        item = 4339,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3866] = {
        p = "Tailoring",
        skill = 110,
        item = 4330,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3868] = {
        p = "Tailoring",
        skill = 125,
        item = 4331,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3869] = {
        p = "Tailoring",
        skill = 135,
        item = 4332,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Danielle Zipstitch (Duskwood 75.8, 45.5)",
            } },
        },
    },
    [3870] = {
        p = "Tailoring",
        skill = 155,
        item = 4333,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Mallen Swain (Hillsbrad Foothills 62, 20.9)",
                "Sheri Zipstitch (Duskwood 75.7, 45.5)",
            } },
        },
    },
    [3871] = {
        p = "Tailoring",
        skill = 170,
        item = 4334,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3872] = {
        p = "Tailoring",
        skill = 185,
        item = 4335,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3873] = {
        p = "Tailoring",
        skill = 200,
        item = 4336,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Narkk (Stranglethorn Vale 28.2, 74.5)",
            } },
        },
    },
    [3914] = {
        p = "Tailoring",
        skill = 30,
        item = 4343,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3915] = {
        p = "Tailoring",
        skill = 1,
        item = 4344,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3918] = {
        p = "Engineering",
        skill = 1,
        item = 4357,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3919] = {
        p = "Engineering",
        skill = 1,
        item = 4358,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3920] = {
        p = "Engineering",
        skill = 1,
        item = 8067,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [3922] = {
        p = "Engineering",
        skill = 30,
        item = 4359,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3923] = {
        p = "Engineering",
        skill = 30,
        item = 4360,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3924] = {
        p = "Engineering",
        skill = 50,
        item = 4361,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3925] = {
        p = "Engineering",
        skill = 50,
        item = 4362,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3926] = {
        p = "Engineering",
        skill = 65,
        item = 4363,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3928] = {
        p = "Engineering",
        skill = 75,
        item = 4401,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3929] = {
        p = "Engineering",
        skill = 75,
        item = 4364,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3930] = {
        p = "Engineering",
        skill = 75,
        item = 8068,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3931] = {
        p = "Engineering",
        skill = 75,
        item = 4365,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3932] = {
        p = "Engineering",
        skill = 85,
        item = 4366,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3933] = {
        p = "Engineering",
        skill = 100,
        item = 4367,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3934] = {
        p = "Engineering",
        skill = 100,
        item = 4368,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3936] = {
        p = "Engineering",
        skill = 105,
        item = 4369,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3937] = {
        p = "Engineering",
        skill = 105,
        item = 4370,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3938] = {
        p = "Engineering",
        skill = 105,
        item = 4371,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3939] = {
        p = "Engineering",
        skill = 120,
        item = 4372,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Fradd Swiftgear (Wetlands 26.4, 25.8)",
                "Jinky Twizzlefixxit (Thousand Needles 77.7, 77.8)",
            } },
        },
    },
    [3940] = {
        p = "Engineering",
        skill = 120,
        item = 4373,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3941] = {
        p = "Engineering",
        skill = 120,
        item = 4374,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3942] = {
        p = "Engineering",
        skill = 125,
        item = 4375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3944] = {
        p = "Engineering",
        skill = 125,
        item = 4376,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
        },
    },
    [3945] = {
        p = "Engineering",
        skill = 125,
        item = 4377,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3946] = {
        p = "Engineering",
        skill = 125,
        item = 4378,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3947] = {
        p = "Engineering",
        skill = 125,
        item = 8069,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3949] = {
        p = "Engineering",
        skill = 130,
        item = 4379,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3950] = {
        p = "Engineering",
        skill = 140,
        item = 4380,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3952] = {
        p = "Engineering",
        skill = 140,
        item = 4381,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gagsprocket (The Barrens 62.7, 36.3)",
                "Namdo Bizzfizzle (Gnomeregan)",
                "Fradd Swiftgear (Wetlands 26.4, 25.8)",
            } },
        },
    },
    [3953] = {
        p = "Engineering",
        skill = 145,
        item = 4382,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3954] = {
        p = "Engineering",
        skill = 145,
        item = 4383,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3955] = {
        p = "Engineering",
        skill = 150,
        item = 4384,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3956] = {
        p = "Engineering",
        skill = 150,
        item = 4385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3957] = {
        p = "Engineering",
        skill = 155,
        item = 4386,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Rizz Loosebolt (Alterac Mountains 47.4, 35.3)",
            } },
        },
    },
    [3958] = {
        p = "Engineering",
        skill = 160,
        item = 4387,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3959] = {
        p = "Engineering",
        skill = 160,
        item = 4388,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
        },
    },
    [3960] = {
        p = "Engineering",
        skill = 165,
        item = 4403,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3961] = {
        p = "Engineering",
        skill = 170,
        item = 4389,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3962] = {
        p = "Engineering",
        skill = 175,
        item = 4390,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3963] = {
        p = "Engineering",
        skill = 175,
        item = 4391,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3965] = {
        p = "Engineering",
        skill = 185,
        item = 4392,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3966] = {
        p = "Engineering",
        skill = 185,
        item = 4393,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3967] = {
        p = "Engineering",
        skill = 190,
        item = 4394,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3968] = {
        p = "Engineering",
        skill = 195,
        item = 4395,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3969] = {
        p = "Engineering",
        skill = 200,
        item = 4396,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gnaz Blunderflame (Stranglethorn Vale 51, 35.3)",
            } },
        },
    },
    [3971] = {
        p = "Engineering",
        skill = 200,
        item = 4397,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
            { t = "Limited Vendor", d = {
                "Zan Shivsproket (Alterac Mountains 86, 80.1)",
            } },
        },
    },
    [3972] = {
        p = "Engineering",
        skill = 200,
        item = 4398,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [3973] = {
        p = "Engineering",
        skill = 90,
        item = 4404,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3977] = {
        p = "Engineering",
        skill = 60,
        item = 4405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3978] = {
        p = "Engineering",
        skill = 110,
        item = 4406,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [3979] = {
        p = "Engineering",
        skill = 180,
        item = 4407,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Mazk Snipeshot (Stranglethorn Vale 28.5, 75.1)",
            } },
        },
    },
    [4094] = {
        p = "Cooking",
        skill = 175,
        item = 4457,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Narj Deepslice (Arathi Highlands 45.6, 47.6)",
            } },
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
            { t = "Quest", d = {
                "Quest #703 (Badlands 42.4, 52.8)",
            } },
        },
    },
    [4096] = {
        p = "Leatherworking",
        skill = 165,
        item = 4455,
        q = "Uncommon",
        sources = {
            { t = "Limited Vendor", d = {
                "Tunkk (Arathi Highlands 74.8, 34.5)",
            } },
        },
    },
    [4097] = {
        p = "Leatherworking",
        skill = 165,
        item = 4456,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Androd Fadran (Arathi Highlands 45, 46.9)",
            } },
        },
    },
    [4508] = {
        p = "Alchemy",
        skill = 50,
        item = 4596,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #429 (Silverpine Forest 53.5, 13.5)",
            } },
        },
    },
    [4942] = {
        p = "Alchemy",
        skill = 215,
        item = 4623,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #715 (Badlands 25.8, 44.4)",
            } },
        },
    },
    [5244] = {
        p = "Leatherworking",
        skill = 40,
        item = 5081,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #769 (Thunder Bluff 44.1, 44.6)",
            } },
        },
    },
    [6412] = {
        p = "Cooking",
        skill = 10,
        item = 5472,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #4161 (Teldrassil 57.1, 61.3)",
            } },
        },
    },
    [6413] = {
        p = "Cooking",
        skill = 20,
        item = 5473,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Grimtak (Durotar 51.2, 42.6)",
            } },
        },
    },
    [6414] = {
        p = "Cooking",
        skill = 35,
        item = 5474,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Wunna Darkmane (Mulgore 46.1, 58.2)",
            } },
        },
    },
    [6415] = {
        p = "Cooking",
        skill = 50,
        item = 5476,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Laird (Darkshore 36.8, 44.3)",
            } },
        },
    },
    [6416] = {
        p = "Cooking",
        skill = 50,
        item = 5477,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Tari'qa (The Barrens 51.7, 30.1)",
            } },
            { t = "Quest", d = {
                "Quest #2178 (Darkshore 37.7, 40.7)",
            } },
        },
    },
    [6417] = {
        p = "Cooking",
        skill = 90,
        item = 44977,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Prospector Khazgorm (The Barrens 47.4, 84.8)",
            } },
            { t = "Quest", d = {
                "Quest #862 (The Barrens 55.3, 31.8)",
            } },
        },
    },
    [6418] = {
        p = "Cooking",
        skill = 100,
        item = 5479,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Tari'qa (The Barrens 51.7, 30.1)",
            } },
        },
    },
    [6419] = {
        p = "Cooking",
        skill = 110,
        item = 5480,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ulthaan (Ashenvale 50, 66.7)",
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
            } },
        },
    },
    [6458] = {
        p = "Engineering",
        skill = 135,
        item = 5507,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6499] = {
        p = "Cooking",
        skill = 50,
        item = 5525,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6500] = {
        p = "Cooking",
        skill = 125,
        item = 5527,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6501] = {
        p = "Cooking",
        skill = 90,
        item = 5526,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kriggon Talsone (Westfall 36.2, 90.1)",
                "Heldan Galesong (Darkshore 37, 56.3)",
            } },
        },
    },
    [6517] = {
        p = "Blacksmithing",
        skill = 110,
        item = 5540,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6518] = {
        p = "Blacksmithing",
        skill = 140,
        item = 5541,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [6521] = {
        p = "Tailoring",
        skill = 90,
        item = 5542,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6617] = {
        p = "Alchemy",
        skill = 60,
        item = 5631,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xandar Goodbeard (Loch Modan 82.5, 63.5)",
                "Hagrus (Orgrimmar 46, 45.9)",
                "Defias Profiteer (Westfall 43.5, 66.9)",
                "Ranik (The Barrens 61.9, 38.7)",
            } },
        },
    },
    [6618] = {
        p = "Alchemy",
        skill = 175,
        item = 5633,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Hagrus (Orgrimmar 46, 45.9)",
                "Ulthir (Darnassus 56, 24.6)",
            } },
        },
    },
    [6624] = {
        p = "Alchemy",
        skill = 150,
        item = 5634,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Soolie Berryfizz (Ironforge 66.6, 54.5)",
                "Ulthir (Darnassus 56, 24.6)",
                "Kor'geld (Orgrimmar 56.1, 35.8)",
            } },
        },
    },
    [6661] = {
        p = "Leatherworking",
        skill = 190,
        item = 5739,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6686] = {
        p = "Tailoring",
        skill = 70,
        item = 5762,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Moonrage Tailor (Silverpine Forest 45.5, 73.3)",
                "Pyrewood Tailor (Silverpine Forest 45.7, 71)",
                "Defias Looter (Westfall 37.5, 58.4)",
            } },
            { t = "Limited Vendor", d = {
                "Rathis Tomber (Ghostlands 47.2, 28.7)",
                "Gina MacGregor (Westfall 57.6, 54)",
                "Mahu (Thunder Bluff 43.8, 44.6)",
                "Valdaron (Darkshore 38.1, 40.6)",
                "Andrew Hilbert (Silverpine Forest 43.2, 40.7)",
            } },
        },
    },
    [6688] = {
        p = "Tailoring",
        skill = 115,
        item = 5763,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Defias Renegade Mage (Westfall 53, 78.8)",
                "Hillsbrad Tailor (Hillsbrad Foothills 36.6, 44.4)",
            } },
            { t = "Limited Vendor", d = {
                "Amy Davenport (Redridge Mountains 29.1, 47.5)",
                "Jennabink Powerseam (Wetlands 8.1, 55.9)",
                "Rann Flamespinner (Loch Modan 36, 46)",
                "Mahu (Thunder Bluff 43.8, 44.6)",
                "Borya (Orgrimmar 63, 51.2)",
                "Wrahk (The Barrens 52.2, 31.7)",
                "Zixil (Hillsbrad Foothills 53.5, 38.3)",
                "Kiknikle (The Barrens 41.8, 38.7)",
                "Valdaron (Darkshore 38.1, 40.6)",
                "Millie Gregorian (Undercity 70.8, 29.6)",
                "Yonada (The Barrens 45, 59.3)",
            } },
        },
    },
    [6690] = {
        p = "Tailoring",
        skill = 135,
        item = 5766,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [6692] = {
        p = "Tailoring",
        skill = 150,
        item = 5770,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Grimtotem Geomancer (Thousand Needles 33.1, 35.4)",
                "Defias Enchanter (Duskwood 49.5, 75.6)",
                "Dark Strand Voidcaller (Darkshore 56.2, 26)",
            } },
        },
    },
    [6693] = {
        p = "Tailoring",
        skill = 175,
        item = 5764,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [6695] = {
        p = "Tailoring",
        skill = 185,
        item = 5765,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Theramore Infiltrator (Dustwallow Marsh 44, 27.3)",
                "Shadowy Assassin (Hillsbrad Foothills 52.7, 52.8)",
                "Syndicate Spy (Alterac Mountains 63, 40.6)",
            } },
        },
    },
    [6702] = {
        p = "Leatherworking",
        skill = 90,
        item = 5780,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Defias Squallshaper (The Deadmines)",
                "Theramore Marine (The Barrens 61.2, 52.2)",
            } },
            { t = "Vendor", d = {
                "Gina MacGregor (Westfall 57.6, 54)",
                "Andrew Hilbert (Silverpine Forest 43.2, 40.7)",
                "Mavralyn (Darkshore 37, 41.2)",
            } },
        },
    },
    [6703] = {
        p = "Leatherworking",
        skill = 95,
        item = 5781,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Defias Pirate (The Deadmines)",
                "Theramore Preserver (The Barrens 63.1, 56.7)",
            } },
            { t = "Vendor", d = {
                "Gina MacGregor (Westfall 57.6, 54)",
                "Andrew Hilbert (Silverpine Forest 43.2, 40.7)",
                "Mavralyn (Darkshore 37, 41.2)",
            } },
        },
    },
    [6704] = {
        p = "Leatherworking",
        skill = 170,
        item = 5782,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Kurzen Commando (Stranglethorn Vale 47.2, 7.6)",
                "Captain Halyndor (Wetlands 15, 24)",
            } },
            { t = "Limited Vendor", d = {
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Christoph Jeffcoat (Hillsbrad Foothills 62.4, 19.1)",
                "Blixrez Goodstitch (Stranglethorn Vale 28.2, 77.5)",
            } },
        },
    },
    [6705] = {
        p = "Leatherworking",
        skill = 190,
        item = 5783,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackwater Deckhand (Arathi Highlands 33, 81.3)",
                "Bloodsail Raider (Stranglethorn Vale 27, 69.9)",
            } },
            { t = "Vendor", d = {
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
            } },
        },
    },
    [7126] = {
        p = "Leatherworking",
        skill = 1,
        item = 5957,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [7133] = {
        p = "Leatherworking",
        skill = 105,
        item = 5958,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7135] = {
        p = "Leatherworking",
        skill = 115,
        item = 5961,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7147] = {
        p = "Leatherworking",
        skill = 160,
        item = 5962,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7149] = {
        p = "Leatherworking",
        skill = 170,
        item = 5963,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lardan (Ashenvale 34.8, 49.8)",
                "Hammon Karwn (Arathi Highlands 46.5, 47.3)",
                "Jandia (Thousand Needles 46.1, 51.5)",
                "Keena (Arathi Highlands 74, 32.7)",
            } },
        },
    },
    [7151] = {
        p = "Leatherworking",
        skill = 175,
        item = 5964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7153] = {
        p = "Leatherworking",
        skill = 185,
        item = 5965,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7156] = {
        p = "Leatherworking",
        skill = 190,
        item = 5966,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7179] = {
        p = "Alchemy",
        skill = 90,
        item = 5996,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7181] = {
        p = "Alchemy",
        skill = 155,
        item = 1710,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7183] = {
        p = "Alchemy",
        skill = 1,
        item = 5997,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [7213] = {
        p = "Cooking",
        skill = 175,
        item = 6038,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
            } },
        },
    },
    [7221] = {
        p = "Blacksmithing",
        skill = 150,
        item = 6042,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7222] = {
        p = "Blacksmithing",
        skill = 165,
        item = 6043,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7223] = {
        p = "Blacksmithing",
        skill = 185,
        item = 6040,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7224] = {
        p = "Blacksmithing",
        skill = 190,
        item = 6041,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7255] = {
        p = "Alchemy",
        skill = 100,
        item = 6051,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Xandar Goodbeard (Loch Modan 82.5, 63.5)",
                "Kzixx (Duskwood 81.9, 19.9)",
                "Hula'mahi (The Barrens 51.4, 30.2)",
            } },
        },
    },
    [7256] = {
        p = "Alchemy",
        skill = 135,
        item = 6048,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Christoph Jeffcoat (Hillsbrad Foothills 62.4, 19.1)",
                "Harklan Moongrove (Ashenvale 50.8, 67)",
            } },
        },
    },
    [7257] = {
        p = "Alchemy",
        skill = 165,
        item = 6049,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Jeeda (Stonetalon Mountains 47.6, 61.7)",
                "Nandar Branson (Hillsbrad Foothills 50.9, 57.1)",
            } },
        },
    },
    [7258] = {
        p = "Alchemy",
        skill = 190,
        item = 6050,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Drovnar Strongbrew (Arathi Highlands 46.4, 47.1)",
                "Glyx Brewright (Stranglethorn Vale 28.1, 78)",
            } },
        },
    },
    [7259] = {
        p = "Alchemy",
        skill = 190,
        item = 6052,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Logannas (Feralas 32.7, 44)",
                "Bronk (Feralas 76.1, 43.3)",
                "Glyx Brewright (Stranglethorn Vale 28.1, 78)",
                "Alchemist Pestlezugg (Tanaris 50.9, 27)",
            } },
        },
    },
    [7408] = {
        p = "Blacksmithing",
        skill = 65,
        item = 6214,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7418] = {
        p = "Enchanting",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [7420] = {
        p = "Enchanting",
        skill = 15,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7421] = {
        p = "Enchanting",
        skill = 1,
        item = 6218,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [7426] = {
        p = "Enchanting",
        skill = 40,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7428] = {
        p = "Enchanting",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [7430] = {
        p = "Engineering",
        skill = 50,
        item = 6219,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7443] = {
        p = "Enchanting",
        skill = 20,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7454] = {
        p = "Enchanting",
        skill = 45,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7457] = {
        p = "Enchanting",
        skill = 50,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7623] = {
        p = "Tailoring",
        skill = 30,
        item = 6238,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7624] = {
        p = "Tailoring",
        skill = 30,
        item = 6241,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7629] = {
        p = "Tailoring",
        skill = 55,
        item = 6239,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7630] = {
        p = "Tailoring",
        skill = 55,
        item = 6240,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Tharynn Bouden (Elwynn Forest 41.9, 67.1)",
            } },
            { t = "Limited Vendor", d = {
                "Borya (Orgrimmar 63, 51.2)",
                "Valdaron (Darkshore 38.1, 40.6)",
                "Wrahk (The Barrens 52.2, 31.7)",
                "Constance Brisboise (Tirisfal Glades 52.6, 55.7)",
            } },
        },
    },
    [7633] = {
        p = "Tailoring",
        skill = 70,
        item = 6242,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Elynna (Darnassus 64.4, 21.6)",
                "Ranik (The Barrens 61.9, 38.7)",
                "Andrew Hilbert (Silverpine Forest 43.2, 40.7)",
                "Wrahk (The Barrens 52.2, 31.7)",
                "Drake Lindgren (Elwynn Forest 83.3, 66.7)",
            } },
        },
    },
    [7639] = {
        p = "Tailoring",
        skill = 100,
        item = 6263,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Gina MacGregor (Westfall 57.6, 54)",
                "Alexandra Bolero (Stormwind City 53.3, 81.7)",
                "Mallen Swain (Hillsbrad Foothills 62, 20.9)",
                "Borya (Orgrimmar 63, 51.2)",
                "Yonada (The Barrens 45, 59.3)",
            } },
        },
    },
    [7643] = {
        p = "Tailoring",
        skill = 115,
        item = 6264,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Rann Flamespinner (Loch Modan 36, 46)",
                "Ranik (The Barrens 61.9, 38.7)",
                "Jennabink Powerseam (Wetlands 8.1, 55.9)",
                "Sheri Zipstitch (Duskwood 75.7, 45.5)",
                "Millie Gregorian (Undercity 70.8, 29.6)",
                "Elynna (Darnassus 64.4, 21.6)",
            } },
        },
    },
    [7745] = {
        p = "Enchanting",
        skill = 100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7748] = {
        p = "Enchanting",
        skill = 60,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7751] = {
        p = "Cooking",
        skill = 1,
        item = 6290,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Harn Longcast (Mulgore 47.5, 55.1)",
                "Gretta Ganter (Dun Morogh 31.5, 44.7)",
                "Catherine Leland (Stormwind City 55.1, 69.5)",
                "Martine Tramblay (Tirisfal Glades 65.8, 59.7)",
                "Tharynn Bouden (Elwynn Forest 41.9, 67.1)",
                "Nyoma (Teldrassil 57.2, 61.2)",
                "Sewa Mistrunner (Thunder Bluff 56, 47.1)",
                "Lizbeth Cromwell (Undercity 81.2, 31)",
                "Khara Deepwater (Loch Modan 39.5, 39.3)",
            } },
        },
    },
    [7752] = {
        p = "Cooking",
        skill = 1,
        item = 787,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Tansy Puddlefizz (Ironforge 48, 6.3)",
                "Kriggon Talsone (Westfall 36.2, 90.1)",
                "Martine Tramblay (Tirisfal Glades 65.8, 59.7)",
                "Zansoa (Durotar 56.1, 73.4)",
                "Nessa Shadowsong (Teldrassil 56.3, 92.4)",
            } },
        },
    },
    [7753] = {
        p = "Cooking",
        skill = 50,
        item = 4592,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Killian Sanatha (Silverpine Forest 33, 17.8)",
                "Khara Deepwater (Loch Modan 39.5, 39.3)",
                "Lizbeth Cromwell (Undercity 81.2, 31)",
                "Tharynn Bouden (Elwynn Forest 41.9, 67.1)",
                "Nyoma (Teldrassil 57.2, 61.2)",
                "Harn Longcast (Mulgore 47.5, 55.1)",
                "Naal Mistrunner (Thunder Bluff 51.1, 52.2)",
                "Tansy Puddlefizz (Ironforge 48, 6.3)",
            } },
        },
    },
    [7754] = {
        p = "Cooking",
        skill = 50,
        item = 6316,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Khara Deepwater (Loch Modan 39.5, 39.3)",
            } },
        },
    },
    [7755] = {
        p = "Cooking",
        skill = 100,
        item = 4593,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kilxx (The Barrens 62.8, 38.2)",
                "Ronald Burch (Undercity 62.4, 43.4)",
                "Lindea Rabonne (Hillsbrad Foothills 50.6, 61)",
                "Naal Mistrunner (Thunder Bluff 51.1, 52.2)",
                "Derak Nightfall (Hillsbrad Foothills 63, 18.5)",
                "Catherine Leland (Stormwind City 55.1, 69.5)",
                "Sewa Mistrunner (Thunder Bluff 56, 47.1)",
            } },
        },
    },
    [7766] = {
        p = "Enchanting",
        skill = 60,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7771] = {
        p = "Enchanting",
        skill = 70,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7776] = {
        p = "Enchanting",
        skill = 80,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Kithas (Orgrimmar 53.7, 38)",
                "Lilly (Silverpine Forest 43.1, 50.8)",
            } },
        },
    },
    [7779] = {
        p = "Enchanting",
        skill = 80,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7782] = {
        p = "Enchanting",
        skill = 80,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7786] = {
        p = "Enchanting",
        skill = 90,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7788] = {
        p = "Enchanting",
        skill = 90,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7793] = {
        p = "Enchanting",
        skill = 100,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Tilli Thistlefuzz (Ironforge 60.7, 44.2)",
                "Kithas (Orgrimmar 53.7, 38)",
                "Leo Sarn (Silverpine Forest 53.9, 82.3)",
            } },
        },
    },
    [7795] = {
        p = "Enchanting",
        skill = 100,
        item = 6339,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7817] = {
        p = "Blacksmithing",
        skill = 95,
        item = 6350,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7818] = {
        p = "Blacksmithing",
        skill = 100,
        item = 6338,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7827] = {
        p = "Cooking",
        skill = 50,
        item = 5095,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kriggon Talsone (Westfall 36.2, 90.1)",
                "Heldan Galesong (Darkshore 37, 56.3)",
                "Killian Sanatha (Silverpine Forest 33, 17.8)",
                "Catherine Leland (Stormwind City 55.1, 69.5)",
                "Shankys (Orgrimmar 69.1, 31.4)",
                "Ronald Burch (Undercity 62.4, 43.4)",
                "Stuart Fleming (Wetlands 8.1, 58.4)",
                "Nessa Shadowsong (Teldrassil 56.3, 92.4)",
                "Kilxx (The Barrens 62.8, 38.2)",
                "Zansoa (Durotar 56.1, 73.4)",
            } },
        },
    },
    [7828] = {
        p = "Cooking",
        skill = 175,
        item = 4594,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Heldan Galesong (Darkshore 37, 56.3)",
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
                "Shankys (Orgrimmar 69.1, 31.4)",
                "Wik'Tar (Ashenvale 11.8, 34.1)",
                "Lindea Rabonne (Hillsbrad Foothills 50.6, 61)",
                "Wulan (Desolace 26.2, 69.7)",
                "Stuart Fleming (Wetlands 8.1, 58.4)",
                "Lizbeth Cromwell (Undercity 81.2, 31)",
                "Tansy Puddlefizz (Ironforge 48, 6.3)",
            } },
        },
    },
    [7836] = {
        p = "Alchemy",
        skill = 80,
        item = 6370,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7837] = {
        p = "Alchemy",
        skill = 130,
        item = 6371,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7841] = {
        p = "Alchemy",
        skill = 100,
        item = 6372,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7845] = {
        p = "Alchemy",
        skill = 140,
        item = 6373,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7857] = {
        p = "Enchanting",
        skill = 120,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7859] = {
        p = "Enchanting",
        skill = 120,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7861] = {
        p = "Enchanting",
        skill = 125,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7863] = {
        p = "Enchanting",
        skill = 125,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7867] = {
        p = "Enchanting",
        skill = 125,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Zixil (Hillsbrad Foothills 53.5, 38.3)",
            } },
        },
    },
    [7892] = {
        p = "Tailoring",
        skill = 120,
        item = 6384,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7893] = {
        p = "Tailoring",
        skill = 120,
        item = 6385,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7928] = {
        p = "First Aid",
        skill = 150,
        item = 6450,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7929] = {
        p = "First Aid",
        skill = 180,
        item = 6451,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7934] = {
        p = "First Aid",
        skill = 80,
        item = 6452,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [7935] = {
        p = "First Aid",
        skill = 130,
        item = 6453,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [7953] = {
        p = "Leatherworking",
        skill = 90,
        item = 6466,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Kalldan Felmoon (The Barrens 46.2, 36.5)",
            } },
        },
    },
    [7954] = {
        p = "Leatherworking",
        skill = 105,
        item = 6467,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Kalldan Felmoon (The Barrens 46.2, 36.5)",
            } },
        },
    },
    [7955] = {
        p = "Leatherworking",
        skill = 115,
        item = 6468,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #1487 (The Barrens 45.8, 36.3)",
            } },
        },
    },
    [8238] = {
        p = "Cooking",
        skill = 85,
        item = 6657,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "The Barrens",
            } },
        },
    },
    [8240] = {
        p = "Alchemy",
        skill = 90,
        item = 6662,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "The Barrens",
            } },
        },
    },
    [8243] = {
        p = "Engineering",
        skill = 185,
        item = 4852,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
            { t = "Quest", d = {
                "Quest #1559 (Badlands 42.4, 52.8)",
            } },
        },
    },
    [8322] = {
        p = "Leatherworking",
        skill = 90,
        item = 6709,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #1582 (Darnassus 64.3, 21.9)",
            } },
        },
    },
    [8334] = {
        p = "Engineering",
        skill = 100,
        item = 6712,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8339] = {
        p = "Engineering",
        skill = 100,
        item = 6714,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8367] = {
        p = "Blacksmithing",
        skill = 100,
        item = 6731,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #1618 (Ironforge 48.5, 43)",
            } },
        },
    },
    [8465] = {
        p = "Tailoring",
        skill = 40,
        item = 6786,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8467] = {
        p = "Tailoring",
        skill = 110,
        item = 6787,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8483] = {
        p = "Tailoring",
        skill = 160,
        item = 6795,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8489] = {
        p = "Tailoring",
        skill = 175,
        item = 6796,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8604] = {
        p = "Cooking",
        skill = 1,
        item = 6888,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [8607] = {
        p = "Cooking",
        skill = 40,
        item = 6890,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Drac Roughcut (Loch Modan 35.6, 49)",
                "Andrew Hilbert (Silverpine Forest 43.2, 40.7)",
            } },
        },
    },
    [8758] = {
        p = "Tailoring",
        skill = 140,
        item = 7046,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8760] = {
        p = "Tailoring",
        skill = 145,
        item = 7048,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8762] = {
        p = "Tailoring",
        skill = 160,
        item = 7050,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8764] = {
        p = "Tailoring",
        skill = 170,
        item = 7051,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8766] = {
        p = "Tailoring",
        skill = 175,
        item = 7052,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8768] = {
        p = "Blacksmithing",
        skill = 150,
        item = 7071,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8770] = {
        p = "Tailoring",
        skill = 190,
        item = 7054,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8772] = {
        p = "Tailoring",
        skill = 175,
        item = 7055,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8774] = {
        p = "Tailoring",
        skill = 180,
        item = 7057,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8776] = {
        p = "Tailoring",
        skill = 15,
        item = 7026,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8780] = {
        p = "Tailoring",
        skill = 145,
        item = 7047,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8782] = {
        p = "Tailoring",
        skill = 150,
        item = 7049,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8784] = {
        p = "Tailoring",
        skill = 165,
        item = 7065,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8786] = {
        p = "Tailoring",
        skill = 175,
        item = 7053,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Jun'ha (Arathi Highlands 72.7, 36.5)",
                "Brienna Starglow (Feralas 89, 45.9)",
            } },
        },
    },
    [8789] = {
        p = "Tailoring",
        skill = 180,
        item = 7056,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Xizk Goodstitch (Stranglethorn Vale 28.7, 76.8)",
            } },
        },
    },
    [8791] = {
        p = "Tailoring",
        skill = 185,
        item = 7058,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8793] = {
        p = "Tailoring",
        skill = 190,
        item = 7059,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8795] = {
        p = "Tailoring",
        skill = 190,
        item = 7060,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8797] = {
        p = "Tailoring",
        skill = 195,
        item = 7061,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [8799] = {
        p = "Tailoring",
        skill = 195,
        item = 7062,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8802] = {
        p = "Tailoring",
        skill = 205,
        item = 7063,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Vizzklick (Tanaris 51, 27.4)",
            } },
        },
    },
    [8804] = {
        p = "Tailoring",
        skill = 210,
        item = 7064,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8880] = {
        p = "Blacksmithing",
        skill = 30,
        item = 7166,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [8895] = {
        p = "Engineering",
        skill = 225,
        item = 7189,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9058] = {
        p = "Leatherworking",
        skill = 1,
        item = 7276,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [9059] = {
        p = "Leatherworking",
        skill = 1,
        item = 7277,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [9060] = {
        p = "Leatherworking",
        skill = 30,
        item = 7278,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9062] = {
        p = "Leatherworking",
        skill = 30,
        item = 7279,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9064] = {
        p = "Leatherworking",
        skill = 35,
        item = 7280,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9065] = {
        p = "Leatherworking",
        skill = 70,
        item = 7281,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9068] = {
        p = "Leatherworking",
        skill = 95,
        item = 7282,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9070] = {
        p = "Leatherworking",
        skill = 100,
        item = 7283,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Clyde Ranthal (Redridge Mountains 88.9, 70.9)",
            } },
        },
    },
    [9072] = {
        p = "Leatherworking",
        skill = 120,
        item = 7284,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Wenna Silkbeard (Wetlands 25.7, 25.8)",
            } },
        },
    },
    [9074] = {
        p = "Leatherworking",
        skill = 120,
        item = 7285,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9145] = {
        p = "Leatherworking",
        skill = 125,
        item = 7348,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9146] = {
        p = "Leatherworking",
        skill = 135,
        item = 7349,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Harlown Darkweave (Ashenvale 18.2, 60)",
            } },
        },
    },
    [9147] = {
        p = "Leatherworking",
        skill = 135,
        item = 7352,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zixil (Hillsbrad Foothills 53.5, 38.3)",
            } },
        },
    },
    [9148] = {
        p = "Leatherworking",
        skill = 140,
        item = 7358,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9149] = {
        p = "Leatherworking",
        skill = 145,
        item = 7359,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9193] = {
        p = "Leatherworking",
        skill = 150,
        item = 7371,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9194] = {
        p = "Leatherworking",
        skill = 150,
        item = 7372,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9195] = {
        p = "Leatherworking",
        skill = 165,
        item = 7373,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9196] = {
        p = "Leatherworking",
        skill = 175,
        item = 7374,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9197] = {
        p = "Leatherworking",
        skill = 175,
        item = 7375,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9198] = {
        p = "Leatherworking",
        skill = 180,
        item = 7377,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9201] = {
        p = "Leatherworking",
        skill = 185,
        item = 7378,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9202] = {
        p = "Leatherworking",
        skill = 190,
        item = 7386,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Jangdor Swiftstrider (Feralas 74.5, 42.9)",
                "Pratt McGrubben (Feralas 30.6, 42.7)",
                "Joseph Moore (Undercity 70.2, 57.8)",
                "Saenorion (Darnassus 63.8, 22.1)",
            } },
        },
    },
    [9206] = {
        p = "Leatherworking",
        skill = 195,
        item = 7387,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9207] = {
        p = "Leatherworking",
        skill = 200,
        item = 7390,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9208] = {
        p = "Leatherworking",
        skill = 200,
        item = 7391,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9269] = {
        p = "Engineering",
        skill = 125,
        item = 7506,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
            { t = "Vendor", d = {
                "Gearcutter Cogspinner (Ironforge 68, 43.1)",
                "Jinky Twizzlefixxit (Thousand Needles 77.7, 77.8)",
            } },
        },
    },
    [9271] = {
        p = "Engineering",
        skill = 150,
        item = 6533,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9273] = {
        p = "Engineering",
        skill = 165,
        item = 7148,
        q = "Common",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Thermaplugg (Gnomeregan)",
            } },
            { t = "Vendor", d = {
                "Veenix (Stonetalon Mountains 58.3, 51.7)",
                "Kzixx (Duskwood 81.9, 19.9)",
                "Zixil (Hillsbrad Foothills 53.5, 38.3)",
            } },
        },
    },
    [9513] = {
        p = "Cooking",
        skill = 60,
        item = 7676,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Smudge Thunderwood (Alterac Mountains 86.1, 79.7)",
            } },
            { t = "Quest", d = {
                "Quest #2359 (Westfall 68.4, 70)",
                "Quest #2478 (The Barrens 55.5, 5.6)",
            } },
        },
    },
    [9811] = {
        p = "Blacksmithing",
        skill = 160,
        item = 7913,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2752 (Orgrimmar 78, 21.4)",
            } },
        },
    },
    [9813] = {
        p = "Blacksmithing",
        skill = 160,
        item = 7914,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2751 (Orgrimmar 78, 21.4)",
            } },
        },
    },
    [9814] = {
        p = "Blacksmithing",
        skill = 175,
        item = 7915,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2754 (Orgrimmar 78, 21.4)",
            } },
        },
    },
    [9818] = {
        p = "Blacksmithing",
        skill = 180,
        item = 7916,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2753 (Orgrimmar 78, 21.4)",
            } },
        },
    },
    [9820] = {
        p = "Blacksmithing",
        skill = 185,
        item = 7917,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2755 (Orgrimmar 78, 21.4)",
            } },
        },
    },
    [9916] = {
        p = "Blacksmithing",
        skill = 200,
        item = 7963,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9918] = {
        p = "Blacksmithing",
        skill = 200,
        item = 7964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9920] = {
        p = "Blacksmithing",
        skill = 200,
        item = 7966,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9921] = {
        p = "Blacksmithing",
        skill = 200,
        item = 7965,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9926] = {
        p = "Blacksmithing",
        skill = 205,
        item = 7918,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9928] = {
        p = "Blacksmithing",
        skill = 205,
        item = 7919,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9931] = {
        p = "Blacksmithing",
        skill = 210,
        item = 7920,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9933] = {
        p = "Blacksmithing",
        skill = 210,
        item = 7921,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9935] = {
        p = "Blacksmithing",
        skill = 215,
        item = 7922,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9937] = {
        p = "Blacksmithing",
        skill = 215,
        item = 7924,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Harggan (The Hinterlands 13.4, 44)",
                "Gharash (Swamp of Sorrows 45.5, 51.6)",
            } },
        },
    },
    [9939] = {
        p = "Blacksmithing",
        skill = 215,
        item = 7967,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9945] = {
        p = "Blacksmithing",
        skill = 220,
        item = 7926,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2761 (Stranglethorn Vale 50.6, 20.5)",
            } },
        },
    },
    [9950] = {
        p = "Blacksmithing",
        skill = 220,
        item = 7927,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2762 (Stranglethorn Vale 50.6, 20.5)",
            } },
        },
    },
    [9952] = {
        p = "Blacksmithing",
        skill = 225,
        item = 7928,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2763 (Stranglethorn Vale 50.6, 20.5)",
            } },
        },
    },
    [9954] = {
        p = "Blacksmithing",
        skill = 225,
        item = 7938,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9957] = {
        p = "Blacksmithing",
        skill = 250,
        item = 7929,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #2756 (Orgrimmar 80.7, 23.4)",
            } },
        },
    },
    [9959] = {
        p = "Blacksmithing",
        skill = 230,
        item = 7930,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9961] = {
        p = "Blacksmithing",
        skill = 230,
        item = 7931,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9964] = {
        p = "Blacksmithing",
        skill = 235,
        item = 7969,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9966] = {
        p = "Blacksmithing",
        skill = 235,
        item = 7932,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9968] = {
        p = "Blacksmithing",
        skill = 235,
        item = 7933,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9970] = {
        p = "Blacksmithing",
        skill = 245,
        item = 7934,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9972] = {
        p = "Blacksmithing",
        skill = 260,
        item = 7935,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2773 (Tanaris 51.5, 28.7)",
            } },
        },
    },
    [9974] = {
        p = "Blacksmithing",
        skill = 245,
        item = 7939,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9979] = {
        p = "Blacksmithing",
        skill = 265,
        item = 7936,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2772 (Tanaris 51.5, 28.7)",
            } },
        },
    },
    [9980] = {
        p = "Blacksmithing",
        skill = 265,
        item = 7937,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2771 (Tanaris 51.5, 28.7)",
            } },
        },
    },
    [9983] = {
        p = "Blacksmithing",
        skill = 30,
        item = 7955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9985] = {
        p = "Blacksmithing",
        skill = 125,
        item = 7956,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9986] = {
        p = "Blacksmithing",
        skill = 130,
        item = 7957,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9987] = {
        p = "Blacksmithing",
        skill = 135,
        item = 7958,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9993] = {
        p = "Blacksmithing",
        skill = 210,
        item = 7941,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [9995] = {
        p = "Blacksmithing",
        skill = 220,
        item = 7942,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [9997] = {
        p = "Blacksmithing",
        skill = 225,
        item = 7943,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10001] = {
        p = "Blacksmithing",
        skill = 230,
        item = 7945,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10003] = {
        p = "Blacksmithing",
        skill = 235,
        item = 7954,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10005] = {
        p = "Blacksmithing",
        skill = 240,
        item = 7944,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10007] = {
        p = "Blacksmithing",
        skill = 245,
        item = 7961,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10009] = {
        p = "Blacksmithing",
        skill = 245,
        item = 7946,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10011] = {
        p = "Blacksmithing",
        skill = 250,
        item = 7959,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10013] = {
        p = "Blacksmithing",
        skill = 255,
        item = 7947,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
        },
    },
    [10015] = {
        p = "Blacksmithing",
        skill = 260,
        item = 7960,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10097] = {
        p = "Mining",
        skill = 175,
        item = 3860,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10098] = {
        p = "Mining",
        skill = 230,
        item = 6037,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10482] = {
        p = "Leatherworking",
        skill = 200,
        item = 8172,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10487] = {
        p = "Leatherworking",
        skill = 200,
        item = 8173,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10490] = {
        p = "Leatherworking",
        skill = 200,
        item = 8174,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10499] = {
        p = "Leatherworking",
        skill = 205,
        item = 8175,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10507] = {
        p = "Leatherworking",
        skill = 205,
        item = 8176,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10509] = {
        p = "Leatherworking",
        skill = 205,
        item = 8187,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Pratt McGrubben (Feralas 30.6, 42.7)",
                "Jangdor Swiftstrider (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10511] = {
        p = "Leatherworking",
        skill = 210,
        item = 8189,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10516] = {
        p = "Leatherworking",
        skill = 210,
        item = 8192,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Jangdor Swiftstrider (Feralas 74.5, 42.9)",
                "Nioma (The Hinterlands 13.4, 43.3)",
            } },
        },
    },
    [10518] = {
        p = "Leatherworking",
        skill = 210,
        item = 8198,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10520] = {
        p = "Leatherworking",
        skill = 215,
        item = 8200,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10525] = {
        p = "Leatherworking",
        skill = 220,
        item = 8203,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Bandit (Tanaris 63.6, 30.6)",
            } },
        },
    },
    [10529] = {
        p = "Leatherworking",
        skill = 220,
        item = 8210,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2848 (Feralas 30.6, 42.7)",
                "Quest #2855 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10531] = {
        p = "Leatherworking",
        skill = 220,
        item = 8201,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10533] = {
        p = "Leatherworking",
        skill = 220,
        item = 8205,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Shadow Mage (Tanaris 60, 37.4)",
            } },
        },
    },
    [10542] = {
        p = "Leatherworking",
        skill = 225,
        item = 8204,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Thief (Tanaris 63, 29.9)",
            } },
        },
    },
    [10544] = {
        p = "Leatherworking",
        skill = 225,
        item = 8211,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2849 (Feralas 30.6, 42.7)",
                "Quest #2856 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10546] = {
        p = "Leatherworking",
        skill = 225,
        item = 8214,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2850 (Feralas 30.6, 42.7)",
                "Quest #2857 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10548] = {
        p = "Leatherworking",
        skill = 230,
        item = 8193,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10552] = {
        p = "Leatherworking",
        skill = 230,
        item = 8191,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10554] = {
        p = "Leatherworking",
        skill = 235,
        item = 8209,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Rogue (Tanaris 60.4, 39.3)",
            } },
        },
    },
    [10556] = {
        p = "Leatherworking",
        skill = 235,
        item = 8185,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10558] = {
        p = "Leatherworking",
        skill = 235,
        item = 8197,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10560] = {
        p = "Leatherworking",
        skill = 240,
        item = 8202,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10562] = {
        p = "Leatherworking",
        skill = 240,
        item = 8216,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [10564] = {
        p = "Leatherworking",
        skill = 240,
        item = 8207,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Assassin (Tanaris 58.6, 36.1)",
                "Wastewander Scofflaw (Tanaris 66.1, 35)",
                "Andre Firebeard (Tanaris 73.4, 47.1)",
            } },
        },
    },
    [10566] = {
        p = "Leatherworking",
        skill = 245,
        item = 8213,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2851 (Feralas 30.6, 42.7)",
                "Quest #2858 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10568] = {
        p = "Leatherworking",
        skill = 245,
        item = 8206,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Rogue (Tanaris 60.4, 39.3)",
            } },
        },
    },
    [10570] = {
        p = "Leatherworking",
        skill = 250,
        item = 8208,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Assassin (Tanaris 58.6, 36.1)",
                "Wastewander Scofflaw (Tanaris 66.1, 35)",
                "Andre Firebeard (Tanaris 73.4, 47.1)",
            } },
        },
    },
    [10572] = {
        p = "Leatherworking",
        skill = 250,
        item = 8212,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2852 (Feralas 30.6, 42.7)",
                "Quest #2859 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10574] = {
        p = "Leatherworking",
        skill = 250,
        item = 8215,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2853 (Feralas 30.6, 42.7)",
                "Quest #2860 (Feralas 74.5, 42.9)",
            } },
        },
    },
    [10619] = {
        p = "Leatherworking",
        skill = 225,
        item = 8347,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10621] = {
        p = "Leatherworking",
        skill = 225,
        item = 8345,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10630] = {
        p = "Leatherworking",
        skill = 230,
        item = 8346,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10632] = {
        p = "Leatherworking",
        skill = 250,
        item = 8348,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10647] = {
        p = "Leatherworking",
        skill = 250,
        item = 8349,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10650] = {
        p = "Leatherworking",
        skill = 255,
        item = 8367,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10840] = {
        p = "First Aid",
        skill = 210,
        item = 8544,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [10841] = {
        p = "First Aid",
        skill = 240,
        item = 8545,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11448] = {
        p = "Alchemy",
        skill = 205,
        item = 6149,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11449] = {
        p = "Alchemy",
        skill = 185,
        item = 8949,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11450] = {
        p = "Alchemy",
        skill = 195,
        item = 8951,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11451] = {
        p = "Alchemy",
        skill = 205,
        item = 8956,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11452] = {
        p = "Alchemy",
        skill = 210,
        item = 9030,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #2203 (Badlands 2.5, 46.1)",
                "Quest #2501 (Loch Modan 37, 49.2)",
            } },
        },
    },
    [11453] = {
        p = "Alchemy",
        skill = 210,
        item = 9036,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [11454] = {
        p = "Blacksmithing",
        skill = 200,
        item = 9060,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Recipe is created by Engineers.",
            } },
        },
    },
    [11456] = {
        p = "Alchemy",
        skill = 210,
        item = 9061,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Recipe is created by Engineers.",
            } },
        },
    },
    [11457] = {
        p = "Alchemy",
        skill = 215,
        item = 3928,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11458] = {
        p = "Alchemy",
        skill = 225,
        item = 9144,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Eastern Kingdoms",
            } },
        },
    },
    [11459] = {
        p = "Alchemy",
        skill = 225,
        item = 9149,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Alchemist Pestlezugg (Tanaris 50.9, 27)",
            } },
        },
    },
    [11460] = {
        p = "Alchemy",
        skill = 230,
        item = 9154,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11461] = {
        p = "Alchemy",
        skill = 235,
        item = 9155,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11464] = {
        p = "Alchemy",
        skill = 235,
        item = 9172,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [11465] = {
        p = "Alchemy",
        skill = 235,
        item = 9179,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11466] = {
        p = "Alchemy",
        skill = 240,
        item = 9088,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Skeletal Flayer (Western Plaguelands 50.7, 80.5)",
                "Slavering Ghoul (Western Plaguelands 36, 56.5)",
            } },
        },
    },
    [11467] = {
        p = "Alchemy",
        skill = 240,
        item = 9187,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11468] = {
        p = "Alchemy",
        skill = 240,
        item = 9197,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [11472] = {
        p = "Alchemy",
        skill = 245,
        item = 9206,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [11473] = {
        p = "Alchemy",
        skill = 245,
        item = 9210,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Logannas (Feralas 32.7, 44)",
                "Bronk (Feralas 76.1, 43.3)",
            } },
        },
    },
    [11476] = {
        p = "Alchemy",
        skill = 250,
        item = 9264,
        q = "Uncommon",
        sources = {
            { t = "Limited Vendor", d = {
                "Maria Lumere (Stormwind City 55.7, 85.5)",
                "Algernon (Undercity 51.9, 74.4)",
            } },
        },
    },
    [11477] = {
        p = "Alchemy",
        skill = 250,
        item = 9224,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Rartar (Swamp of Sorrows 45.4, 57)",
                "Nina Lightbrew (Blasted Lands 66.9, 18.3)",
            } },
        },
    },
    [11478] = {
        p = "Alchemy",
        skill = 250,
        item = 9233,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [11479] = {
        p = "Alchemy",
        skill = 225,
        item = 3577,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Alchemist Pestlezugg (Tanaris 50.9, 27)",
            } },
        },
    },
    [11480] = {
        p = "Alchemy",
        skill = 225,
        item = 6037,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Alchemist Pestlezugg (Tanaris 50.9, 27)",
            } },
        },
    },
    [11643] = {
        p = "Blacksmithing",
        skill = 205,
        item = 9366,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #2758 (Stormwind City 63, 36.9)",
            } },
        },
    },
    [12044] = {
        p = "Tailoring",
        skill = 1,
        item = 10045,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [12045] = {
        p = "Tailoring",
        skill = 20,
        item = 10046,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12046] = {
        p = "Tailoring",
        skill = 75,
        item = 10047,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12047] = {
        p = "Tailoring",
        skill = 120,
        item = 10048,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12048] = {
        p = "Tailoring",
        skill = 205,
        item = 9998,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12049] = {
        p = "Tailoring",
        skill = 205,
        item = 9999,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12050] = {
        p = "Tailoring",
        skill = 210,
        item = 10001,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12052] = {
        p = "Tailoring",
        skill = 210,
        item = 10002,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12053] = {
        p = "Tailoring",
        skill = 215,
        item = 10003,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12055] = {
        p = "Tailoring",
        skill = 215,
        item = 10004,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12056] = {
        p = "Tailoring",
        skill = 215,
        item = 10007,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12059] = {
        p = "Tailoring",
        skill = 215,
        item = 10008,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12060] = {
        p = "Tailoring",
        skill = 215,
        item = 10009,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12061] = {
        p = "Tailoring",
        skill = 215,
        item = 10056,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12064] = {
        p = "Tailoring",
        skill = 220,
        item = 10052,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Mahu (Thunder Bluff 43.8, 44.6)",
                "Elynna (Darnassus 64.4, 21.6)",
            } },
        },
    },
    [12065] = {
        p = "Tailoring",
        skill = 225,
        item = 10050,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12066] = {
        p = "Tailoring",
        skill = 225,
        item = 10018,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12067] = {
        p = "Tailoring",
        skill = 225,
        item = 10019,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12069] = {
        p = "Tailoring",
        skill = 225,
        item = 10042,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12070] = {
        p = "Tailoring",
        skill = 225,
        item = 10021,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12071] = {
        p = "Tailoring",
        skill = 225,
        item = 10023,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12072] = {
        p = "Tailoring",
        skill = 230,
        item = 10024,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12073] = {
        p = "Tailoring",
        skill = 230,
        item = 10026,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12074] = {
        p = "Tailoring",
        skill = 230,
        item = 10027,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12075] = {
        p = "Tailoring",
        skill = 230,
        item = 10054,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Borya (Orgrimmar 63, 51.2)",
                "Outfitter Eric (Ironforge 43.2, 29.2)",
            } },
        },
    },
    [12076] = {
        p = "Tailoring",
        skill = 235,
        item = 10028,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12077] = {
        p = "Tailoring",
        skill = 235,
        item = 10053,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12078] = {
        p = "Tailoring",
        skill = 235,
        item = 10029,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12079] = {
        p = "Tailoring",
        skill = 235,
        item = 10051,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12080] = {
        p = "Tailoring",
        skill = 235,
        item = 10055,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Borya (Orgrimmar 63, 51.2)",
                "Outfitter Eric (Ironforge 43.2, 29.2)",
            } },
        },
    },
    [12081] = {
        p = "Tailoring",
        skill = 240,
        item = 10030,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Cowardly Crosby (Stranglethorn Vale 27, 82.5)",
            } },
        },
    },
    [12082] = {
        p = "Tailoring",
        skill = 240,
        item = 10031,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12084] = {
        p = "Tailoring",
        skill = 240,
        item = 10033,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12085] = {
        p = "Tailoring",
        skill = 240,
        item = 10034,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Millie Gregorian (Undercity 70.8, 29.6)",
                "Outfitter Eric (Ironforge 43.2, 29.2)",
            } },
        },
    },
    [12086] = {
        p = "Tailoring",
        skill = 245,
        item = 10025,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #3402 (Searing Gorge 41, 74.8)",
            } },
        },
    },
    [12088] = {
        p = "Tailoring",
        skill = 245,
        item = 10044,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12089] = {
        p = "Tailoring",
        skill = 245,
        item = 10035,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Millie Gregorian (Undercity 70.8, 29.6)",
                "Outfitter Eric (Ironforge 43.2, 29.2)",
            } },
        },
    },
    [12091] = {
        p = "Tailoring",
        skill = 250,
        item = 10040,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Alexandra Bolero (Stormwind City 53.3, 81.7)",
                "Mahu (Thunder Bluff 43.8, 44.6)",
            } },
        },
    },
    [12092] = {
        p = "Tailoring",
        skill = 250,
        item = 10041,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12093] = {
        p = "Tailoring",
        skill = 250,
        item = 10036,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Millie Gregorian (Undercity 70.8, 29.6)",
                "Outfitter Eric (Ironforge 43.2, 29.2)",
            } },
        },
    },
    [12259] = {
        p = "Blacksmithing",
        skill = 155,
        item = 10423,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12260] = {
        p = "Blacksmithing",
        skill = 1,
        item = 10421,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [12584] = {
        p = "Engineering",
        skill = 150,
        item = 10558,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12585] = {
        p = "Engineering",
        skill = 175,
        item = 10505,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12586] = {
        p = "Engineering",
        skill = 175,
        item = 10507,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12587] = {
        p = "Engineering",
        skill = 175,
        item = 10499,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12589] = {
        p = "Engineering",
        skill = 195,
        item = 10559,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12590] = {
        p = "Engineering",
        skill = 175,
        item = 10498,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12591] = {
        p = "Engineering",
        skill = 200,
        item = 10560,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12594] = {
        p = "Engineering",
        skill = 205,
        item = 10500,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12595] = {
        p = "Engineering",
        skill = 205,
        item = 10508,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12596] = {
        p = "Engineering",
        skill = 210,
        item = 10512,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12597] = {
        p = "Engineering",
        skill = 210,
        item = 10546,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Knaz Blunderflame (Stranglethorn Vale 51, 35.3)",
                "Yuka Screwspigot (Burning Steppes 66, 22)",
            } },
        },
    },
    [12599] = {
        p = "Engineering",
        skill = 215,
        item = 10561,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12603] = {
        p = "Engineering",
        skill = 215,
        item = 10514,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12607] = {
        p = "Engineering",
        skill = 220,
        item = 10501,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12609] = {
        p = "Alchemy",
        skill = 200,
        item = 10592,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12614] = {
        p = "Engineering",
        skill = 220,
        item = 10510,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12615] = {
        p = "Engineering",
        skill = 225,
        item = 10502,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12616] = {
        p = "Engineering",
        skill = 225,
        item = 10518,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12617] = {
        p = "Engineering",
        skill = 230,
        item = 10506,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Jubie Gadgetspring (Azshara 45.3, 90.9)",
            } },
        },
    },
    [12618] = {
        p = "Engineering",
        skill = 230,
        item = 10503,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12619] = {
        p = "Engineering",
        skill = 235,
        item = 10562,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12620] = {
        p = "Engineering",
        skill = 240,
        item = 10548,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [12621] = {
        p = "Engineering",
        skill = 245,
        item = 10513,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12622] = {
        p = "Engineering",
        skill = 245,
        item = 10504,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12624] = {
        p = "Engineering",
        skill = 250,
        item = 10576,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ruppo Zipcoil (The Hinterlands 34.3, 37.9)",
            } },
        },
    },
    [12715] = {
        p = "Engineering",
        skill = 205,
        item = 10644,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12716] = {
        p = "Engineering",
        skill = 205,
        item = 10577,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12717] = {
        p = "Engineering",
        skill = 205,
        item = 10542,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12718] = {
        p = "Engineering",
        skill = 205,
        item = 10543,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12754] = {
        p = "Engineering",
        skill = 235,
        item = 10586,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12755] = {
        p = "Engineering",
        skill = 230,
        item = 10587,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12758] = {
        p = "Engineering",
        skill = 245,
        item = 10588,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12759] = {
        p = "Engineering",
        skill = 240,
        item = 10645,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12760] = {
        p = "Engineering",
        skill = 205,
        item = 10646,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12895] = {
        p = "Engineering",
        skill = 205,
        item = 10713,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12897] = {
        p = "Engineering",
        skill = 210,
        item = 10545,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12899] = {
        p = "Engineering",
        skill = 205,
        item = 10716,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12902] = {
        p = "Engineering",
        skill = 210,
        item = 10720,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12903] = {
        p = "Engineering",
        skill = 215,
        item = 10721,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12905] = {
        p = "Engineering",
        skill = 225,
        item = 10724,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12906] = {
        p = "Engineering",
        skill = 230,
        item = 10725,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12907] = {
        p = "Engineering",
        skill = 235,
        item = 10726,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [12908] = {
        p = "Engineering",
        skill = 240,
        item = 10727,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13028] = {
        p = "Cooking",
        skill = 175,
        item = 10841,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained by talking to Henry Stern in Razorfen Downs. (Razorfen Downs)",
            } },
        },
    },
    [13240] = {
        p = "Engineering",
        skill = 205,
        item = 10577,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13378] = {
        p = "Enchanting",
        skill = 105,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13380] = {
        p = "Enchanting",
        skill = 110,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13419] = {
        p = "Enchanting",
        skill = 110,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Dalria (Ashenvale 35.1, 52.1)",
                "Kulwia (Stonetalon Mountains 45.4, 59.4)",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13421] = {
        p = "Enchanting",
        skill = 115,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13464] = {
        p = "Enchanting",
        skill = 115,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13485] = {
        p = "Enchanting",
        skill = 130,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13501] = {
        p = "Enchanting",
        skill = 130,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13503] = {
        p = "Enchanting",
        skill = 140,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13522] = {
        p = "Enchanting",
        skill = 135,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13529] = {
        p = "Enchanting",
        skill = 145,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13536] = {
        p = "Enchanting",
        skill = 140,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Dalria (Ashenvale 35.1, 52.1)",
                "Kulwia (Stonetalon Mountains 45.4, 59.4)",
            } },
        },
    },
    [13538] = {
        p = "Enchanting",
        skill = 140,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13607] = {
        p = "Enchanting",
        skill = 145,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13612] = {
        p = "Enchanting",
        skill = 145,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Dark Iron Demolitionist (Wetlands 59.5, 29.7)",
                "Dark Iron Dwarf (Wetlands 60.1, 25.7)",
                "Dark Iron Saboteur (Wetlands 58.5, 24.2)",
                "Balgaras the Foul (Wetlands 60, 28.7)",
                "Dark Iron Tunneler (Wetlands 61.4, 27.7)",
            } },
        },
    },
    [13617] = {
        p = "Enchanting",
        skill = 145,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackened Ancient (Stonetalon Mountains 33, 70.7)",
                "Crazed Ancient (Ashenvale 59.4, 43)",
                "Withered Ancient (Ashenvale 58.5, 36.1)",
                "Charred Ancient (Stonetalon Mountains 34, 66.1)",
                "Vengeful Ancient (Stonetalon Mountains 33, 72.4)",
            } },
        },
    },
    [13620] = {
        p = "Enchanting",
        skill = 145,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Torn Fin Tidehunter (Hillsbrad Foothills 39, 69)",
                "Torn Fin Muckdweller (Hillsbrad Foothills 31.5, 72.1)",
                "Torn Fin Coastrunner (Hillsbrad Foothills 25.1, 70.5)",
                "Torn Fin Oracle (Hillsbrad Foothills 42, 68)",
                "Scargil (Hillsbrad Foothills 26.6, 71.2)",
            } },
        },
    },
    [13622] = {
        p = "Enchanting",
        skill = 150,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13626] = {
        p = "Enchanting",
        skill = 150,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13628] = {
        p = "Enchanting",
        skill = 150,
        item = 11130,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13631] = {
        p = "Enchanting",
        skill = 155,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13635] = {
        p = "Enchanting",
        skill = 155,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13637] = {
        p = "Enchanting",
        skill = 160,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13640] = {
        p = "Enchanting",
        skill = 160,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13642] = {
        p = "Enchanting",
        skill = 165,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13644] = {
        p = "Enchanting",
        skill = 170,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13646] = {
        p = "Enchanting",
        skill = 170,
        q = "Uncommon",
        sources = {
            { t = "Limited Vendor", d = {
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Keena (Arathi Highlands 74, 32.7)",
            } },
        },
    },
    [13648] = {
        p = "Enchanting",
        skill = 170,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13653] = {
        p = "Enchanting",
        skill = 175,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13655] = {
        p = "Enchanting",
        skill = 175,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13657] = {
        p = "Enchanting",
        skill = 175,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13659] = {
        p = "Enchanting",
        skill = 180,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13661] = {
        p = "Enchanting",
        skill = 180,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13663] = {
        p = "Enchanting",
        skill = 185,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13687] = {
        p = "Enchanting",
        skill = 190,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13689] = {
        p = "Enchanting",
        skill = 195,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13693] = {
        p = "Enchanting",
        skill = 195,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13695] = {
        p = "Enchanting",
        skill = 200,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13698] = {
        p = "Enchanting",
        skill = 200,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Witherbark Headhunter (Arathi Highlands 70.5, 70.4)",
                "Witherbark Berserker (Arathi Highlands 24.2, 66.2)",
                "Witherbark Shadow Hunter (Arathi Highlands 70.3, 78.9)",
                "Nimar the Slayer (Arathi Highlands 66.6, 64)",
            } },
        },
    },
    [13700] = {
        p = "Enchanting",
        skill = 200,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13702] = {
        p = "Enchanting",
        skill = 200,
        item = 11145,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13746] = {
        p = "Enchanting",
        skill = 205,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13794] = {
        p = "Enchanting",
        skill = 205,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13815] = {
        p = "Enchanting",
        skill = 210,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13817] = {
        p = "Enchanting",
        skill = 210,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13822] = {
        p = "Enchanting",
        skill = 210,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13836] = {
        p = "Enchanting",
        skill = 215,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13841] = {
        p = "Enchanting",
        skill = 215,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Venture Co. Strip Miner (Stranglethorn Vale 40.5, 43.7)",
            } },
        },
    },
    [13846] = {
        p = "Enchanting",
        skill = 220,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13858] = {
        p = "Enchanting",
        skill = 220,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13868] = {
        p = "Enchanting",
        skill = 225,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Swampwalker (Swamp of Sorrows 51, 36.7)",
                "Tangled Horror (Swamp of Sorrows 12, 31.8)",
                "Molt Thorn (Swamp of Sorrows 30.4, 41.4)",
                "Mire Lord (Swamp of Sorrows 5.6, 31.4)",
                "Swampwalker Elder (Swamp of Sorrows 12, 33.2)",
            } },
        },
    },
    [13882] = {
        p = "Enchanting",
        skill = 225,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Wastewander Assassin (Tanaris 58.6, 36.1)",
                "Wastewander Scofflaw (Tanaris 66.1, 35)",
                "Syndicate Assassin (Alterac Mountains 40.6, 16.8)",
            } },
        },
    },
    [13887] = {
        p = "Enchanting",
        skill = 225,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13890] = {
        p = "Enchanting",
        skill = 225,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13898] = {
        p = "Enchanting",
        skill = 265,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Pyromancer Loregrain (Blackrock Depths)",
            } },
        },
    },
    [13905] = {
        p = "Enchanting",
        skill = 230,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13915] = {
        p = "Enchanting",
        skill = 230,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13917] = {
        p = "Enchanting",
        skill = 230,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13931] = {
        p = "Enchanting",
        skill = 235,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Banalash (Swamp of Sorrows 44.7, 56.7)",
                "Mythrin'dir (Darnassus 60, 19.1)",
            } },
        },
    },
    [13933] = {
        p = "Enchanting",
        skill = 235,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13935] = {
        p = "Enchanting",
        skill = 235,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13937] = {
        p = "Enchanting",
        skill = 240,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13939] = {
        p = "Enchanting",
        skill = 240,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13941] = {
        p = "Enchanting",
        skill = 245,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13943] = {
        p = "Enchanting",
        skill = 245,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [13945] = {
        p = "Enchanting",
        skill = 245,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13947] = {
        p = "Enchanting",
        skill = 250,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [13948] = {
        p = "Enchanting",
        skill = 250,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14293] = {
        p = "Enchanting",
        skill = 10,
        item = 11287,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14379] = {
        p = "Blacksmithing",
        skill = 150,
        item = 11128,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14380] = {
        p = "Blacksmithing",
        skill = 200,
        item = 11144,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14807] = {
        p = "Enchanting",
        skill = 70,
        item = 11288,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14809] = {
        p = "Enchanting",
        skill = 155,
        item = 11289,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14810] = {
        p = "Enchanting",
        skill = 175,
        item = 11290,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14891] = {
        p = "Mining",
        skill = 230,
        item = 11371,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #4083 (Blackrock Depths)",
            } },
        },
    },
    [14930] = {
        p = "Leatherworking",
        skill = 225,
        item = 8217,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [14932] = {
        p = "Leatherworking",
        skill = 225,
        item = 8218,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [15255] = {
        p = "Engineering",
        skill = 200,
        item = 11590,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [15292] = {
        p = "Blacksmithing",
        skill = 265,
        item = 11608,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Grizzle (Blackrock Depths)",
            } },
        },
    },
    [15293] = {
        p = "Blacksmithing",
        skill = 270,
        item = 11606,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "There is a chance that you will find it in 5 different rooms in blackrock depths, it is a random spawn though, and sometimes it doesn't even spawn at all. (Blackrock Depths)",
            } },
        },
    },
    [15294] = {
        p = "Blacksmithing",
        skill = 275,
        item = 11607,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Hammered Patron (Blackrock Depths)",
                "Ribbly's Crony (Blackrock Depths)",
            } },
        },
    },
    [15295] = {
        p = "Blacksmithing",
        skill = 280,
        item = 11605,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "There is a chance that you will find it in 5 different rooms in blackrock depths, it is a random spawn though, and sometimes it doesn't even spawn at all. (Blackrock Depths)",
            } },
        },
    },
    [15296] = {
        p = "Blacksmithing",
        skill = 285,
        item = 11604,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Ribbly Screwspigot (Blackrock Depths)",
            } },
        },
    },
    [15596] = {
        p = "Enchanting",
        skill = 265,
        item = 45050,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Lord Roccor (Blackrock Depths)",
            } },
        },
    },
    [15628] = {
        p = "Engineering",
        skill = 205,
        item = 11825,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Dropped from mobs in Gnomeregan. (Gnomeregan)",
            } },
        },
    },
    [15633] = {
        p = "Engineering",
        skill = 205,
        item = 11826,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Dropped from mobs in Gnomeregan. (Gnomeregan)",
            } },
        },
    },
    [15833] = {
        p = "Alchemy",
        skill = 230,
        item = 12190,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [15853] = {
        p = "Cooking",
        skill = 125,
        item = 12209,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
        },
    },
    [15855] = {
        p = "Cooking",
        skill = 175,
        item = 12210,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nerrist (Stranglethorn Vale 32.7, 29.2)",
                "Corporal Bluth (Stranglethorn Vale 38, 3)",
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
                "Keena (Arathi Highlands 74, 32.7)",
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
                "Hammon Karwn (Arathi Highlands 46.5, 47.3)",
                "Ogg'marr (Dustwallow Marsh 36.7, 31)",
            } },
        },
    },
    [15856] = {
        p = "Cooking",
        skill = 175,
        item = 13851,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Sheendra Tallgrass (Feralas 74.5, 42.8)",
                "Vivianna (Feralas 31.3, 43.5)",
            } },
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
        },
    },
    [15861] = {
        p = "Cooking",
        skill = 175,
        item = 12212,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nerrist (Stranglethorn Vale 32.7, 29.2)",
                "Corporal Bluth (Stranglethorn Vale 38, 3)",
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
            } },
        },
    },
    [15863] = {
        p = "Cooking",
        skill = 175,
        item = 12213,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
                "Ogg'marr (Dustwallow Marsh 36.7, 31)",
                "Banalash (Swamp of Sorrows 44.7, 56.7)",
                "Kireena (Desolace 51, 53.5)",
            } },
        },
    },
    [15865] = {
        p = "Cooking",
        skill = 175,
        item = 12214,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
                "Janet Hommers (Desolace 66.2, 6.7)",
            } },
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
        },
    },
    [15906] = {
        p = "Cooking",
        skill = 200,
        item = 12217,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
                "Ogg'marr (Dustwallow Marsh 36.7, 31)",
            } },
            { t = "Limited Vendor", d = {
                "Super-Seller 680 (Desolace 40.5, 79.3)",
            } },
        },
    },
    [15910] = {
        p = "Cooking",
        skill = 200,
        item = 12215,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vendor-Tron 1000 (Desolace 60.3, 38.1)",
                "Kireena (Desolace 51, 53.5)",
                "Janet Hommers (Desolace 66.2, 6.7)",
            } },
        },
    },
    [15915] = {
        p = "Cooking",
        skill = 225,
        item = 12216,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kriggon Talsone (Westfall 36.2, 90.1)",
                "Uthok (Stranglethorn Vale 31.6, 28)",
                "Banalash (Swamp of Sorrows 44.7, 56.7)",
            } },
        },
    },
    [15933] = {
        p = "Cooking",
        skill = 225,
        item = 12218,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Malygen (Felwood 62.3, 25.6)",
                "Bale (Felwood 34.8, 53.1)",
                "Himmik (Winterspring 61.3, 39.1)",
            } },
        },
    },
    [15935] = {
        p = "Cooking",
        skill = 1,
        item = 12224,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Abigail Shiel (Tirisfal Glades 61, 52.5)",
            } },
        },
    },
    [15972] = {
        p = "Blacksmithing",
        skill = 180,
        item = 12259,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [15973] = {
        p = "Blacksmithing",
        skill = 190,
        item = 12260,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16153] = {
        p = "Mining",
        skill = 230,
        item = 12359,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [16639] = {
        p = "Blacksmithing",
        skill = 250,
        item = 12644,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [16640] = {
        p = "Blacksmithing",
        skill = 250,
        item = 12643,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [16641] = {
        p = "Blacksmithing",
        skill = 250,
        item = 12404,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [16642] = {
        p = "Blacksmithing",
        skill = 250,
        item = 12405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16643] = {
        p = "Blacksmithing",
        skill = 250,
        item = 12406,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16644] = {
        p = "Blacksmithing",
        skill = 255,
        item = 12408,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16645] = {
        p = "Blacksmithing",
        skill = 260,
        item = 12416,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16646] = {
        p = "Blacksmithing",
        skill = 265,
        item = 12428,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7659 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16647] = {
        p = "Blacksmithing",
        skill = 265,
        item = 12424,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7653 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16648] = {
        p = "Blacksmithing",
        skill = 270,
        item = 12415,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16649] = {
        p = "Blacksmithing",
        skill = 270,
        item = 12425,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7655 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16650] = {
        p = "Blacksmithing",
        skill = 270,
        item = 12624,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16651] = {
        p = "Blacksmithing",
        skill = 275,
        item = 12645,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16652] = {
        p = "Blacksmithing",
        skill = 280,
        item = 12409,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16653] = {
        p = "Blacksmithing",
        skill = 280,
        item = 12410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16654] = {
        p = "Blacksmithing",
        skill = 285,
        item = 12418,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16655] = {
        p = "Blacksmithing",
        skill = 290,
        item = 12631,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #5124 (Winterspring 61, 38.7)",
            } },
        },
    },
    [16656] = {
        p = "Blacksmithing",
        skill = 290,
        item = 12419,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16657] = {
        p = "Blacksmithing",
        skill = 295,
        item = 12426,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7654 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16658] = {
        p = "Blacksmithing",
        skill = 295,
        item = 12427,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7657 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16659] = {
        p = "Blacksmithing",
        skill = 295,
        item = 12417,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16660] = {
        p = "Blacksmithing",
        skill = 290,
        item = 12625,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16661] = {
        p = "Blacksmithing",
        skill = 295,
        item = 12632,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16662] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12414,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16663] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12422,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7656 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16664] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12610,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Strashaz Serpent Guard (Dustwallow Marsh 74.1, 18.2)",
            } },
        },
    },
    [16665] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12611,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Scarlet Cavalier (Western Plaguelands 42.5, 16)",
            } },
        },
    },
    [16667] = {
        p = "Blacksmithing",
        skill = 285,
        item = 12628,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #5127 (Winterspring 63.8, 73.8)",
            } },
        },
    },
    [16724] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12633,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16725] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12420,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16726] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12612,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Strashaz Warrior (Dustwallow Marsh 76.5, 22.3)",
            } },
        },
    },
    [16728] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12636,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16729] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12640,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16730] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12429,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #7658 (Tanaris 51.4, 28.7)",
            } },
        },
    },
    [16731] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12613,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Strashaz Myrmidon (Dustwallow Marsh 75.1, 14.2)",
                "Tidelord Rrurgaz (Dustwallow Marsh 76.7, 19.5)",
            } },
        },
    },
    [16732] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12614,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Scarlet Smith (Western Plaguelands 45.4, 14.5)",
            } },
        },
    },
    [16741] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12639,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16742] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12620,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #7651 (Dire Maul)",
            } },
        },
    },
    [16744] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12619,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #7650 (Dire Maul)",
            } },
        },
    },
    [16745] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12618,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #7649 (Dire Maul)",
            } },
        },
    },
    [16746] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12641,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [16969] = {
        p = "Blacksmithing",
        skill = 275,
        item = 12773,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
        },
    },
    [16970] = {
        p = "Blacksmithing",
        skill = 275,
        item = 12774,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #5306 (Winterspring 61.3, 37.1)",
            } },
        },
    },
    [16971] = {
        p = "Blacksmithing",
        skill = 280,
        item = 12775,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
        },
    },
    [16973] = {
        p = "Blacksmithing",
        skill = 280,
        item = 12776,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #5305 (Winterspring 61.3, 37.1)",
            } },
        },
    },
    [16978] = {
        p = "Blacksmithing",
        skill = 280,
        item = 12777,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #5307 (Winterspring 61.3, 37.2)",
            } },
        },
    },
    [16983] = {
        p = "Blacksmithing",
        skill = 285,
        item = 12781,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Blacksmith plans in Stratholme (Stratholme)",
            } },
        },
    },
    [16984] = {
        p = "Blacksmithing",
        skill = 290,
        item = 12792,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Volchan (Burning Steppes 73, 49.3)",
            } },
        },
    },
    [16985] = {
        p = "Blacksmithing",
        skill = 290,
        item = 12782,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Blacksmith plans in Stratholme (Stratholme)",
            } },
        },
    },
    [16988] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12796,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Maleki the Pallid (Stratholme)",
            } },
        },
    },
    [16990] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12790,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Goraluk Anvilcrack (Blackrock Spire)",
            } },
        },
    },
    [16991] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12798,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Quartermaster Zigris (Blackrock Spire)",
            } },
        },
    },
    [16992] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12797,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Foreman Marcrid (Western Plaguelands 47.7, 35.4)",
            } },
        },
    },
    [16993] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12794,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Goraluk Anvilcrack (Blackrock Spire)",
            } },
        },
    },
    [16994] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12784,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Bannok Grimaxe (Blackrock Spire)",
            } },
        },
    },
    [16995] = {
        p = "Blacksmithing",
        skill = 300,
        item = 12783,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cannon Master Willey (Stratholme)",
            } },
        },
    },
    [17180] = {
        p = "Enchanting",
        skill = 250,
        item = 12655,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17181] = {
        p = "Enchanting",
        skill = 250,
        item = 12810,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17187] = {
        p = "Alchemy",
        skill = 275,
        item = 12360,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Alchemist Pestlezugg (Tanaris 50.9, 27)",
            } },
        },
    },
    [17551] = {
        p = "Alchemy",
        skill = 250,
        item = 13423,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17552] = {
        p = "Alchemy",
        skill = 255,
        item = 13442,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17553] = {
        p = "Alchemy",
        skill = 260,
        item = 13443,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17554] = {
        p = "Alchemy",
        skill = 265,
        item = 13445,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Soolie Berryfizz (Ironforge 66.6, 54.5)",
                "Kor'geld (Orgrimmar 56.1, 35.8)",
            } },
        },
    },
    [17555] = {
        p = "Alchemy",
        skill = 270,
        item = 13447,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17556] = {
        p = "Alchemy",
        skill = 275,
        item = 13446,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17557] = {
        p = "Alchemy",
        skill = 275,
        item = 13453,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17559] = {
        p = "Alchemy",
        skill = 275,
        item = 7078,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [17560] = {
        p = "Alchemy",
        skill = 275,
        item = 7076,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Plugger Spazzring (Blackrock Depths)",
            } },
        },
    },
    [17561] = {
        p = "Alchemy",
        skill = 275,
        item = 7080,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Friendly: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [17562] = {
        p = "Alchemy",
        skill = 275,
        item = 7082,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
        },
    },
    [17563] = {
        p = "Alchemy",
        skill = 275,
        item = 7080,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17564] = {
        p = "Alchemy",
        skill = 275,
        item = 12808,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17565] = {
        p = "Alchemy",
        skill = 275,
        item = 7076,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17566] = {
        p = "Alchemy",
        skill = 275,
        item = 12803,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17570] = {
        p = "Alchemy",
        skill = 280,
        item = 13455,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17571] = {
        p = "Alchemy",
        skill = 280,
        item = 13452,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Legashi Rogue (Azshara 50.1, 19.6)",
                "Jadefire Rogue (Felwood 37.5, 66.5)",
            } },
        },
    },
    [17572] = {
        p = "Alchemy",
        skill = 285,
        item = 13462,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17573] = {
        p = "Alchemy",
        skill = 285,
        item = 13454,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [17574] = {
        p = "Alchemy",
        skill = 290,
        item = 13457,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Firebrand Invoker (Blackrock Spire)",
                "Firebrand Pyromancer (Blackrock Spire)",
            } },
        },
    },
    [17575] = {
        p = "Alchemy",
        skill = 290,
        item = 13456,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Frostmaul Giant (Winterspring 58.5, 70)",
            } },
        },
    },
    [17576] = {
        p = "Alchemy",
        skill = 290,
        item = 13458,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Rotting Behemoth (Western Plaguelands 64.5, 36.6)",
                "Decaying Horror (Western Plaguelands 62, 37.6)",
            } },
        },
    },
    [17577] = {
        p = "Alchemy",
        skill = 290,
        item = 13461,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cobalt Mageweaver (Winterspring 59.5, 49.2)",
            } },
        },
    },
    [17578] = {
        p = "Alchemy",
        skill = 290,
        item = 13459,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Dark Adept (Eastern Plaguelands 65.8, 37.9)",
                "Shadowmage (Eastern Plaguelands 78.5, 35.3)",
            } },
        },
    },
    [17580] = {
        p = "Alchemy",
        skill = 295,
        item = 13444,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Darkmaster Gandling (Scholomance)",
            } },
            { t = "Vendor", d = {
                "Magnus Frostwake (Western Plaguelands 68.1, 77.6)",
            } },
        },
    },
    [17632] = {
        p = "Alchemy",
        skill = 350,
        item = 13503,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [17634] = {
        p = "Alchemy",
        skill = 300,
        item = 13506,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [17635] = {
        p = "Alchemy",
        skill = 300,
        item = 13510,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "General Drakkisath (Blackrock Spire)",
            } },
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Exalted: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [17636] = {
        p = "Alchemy",
        skill = 300,
        item = 13511,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
            { t = "Mob Drop", d = {
                "Balnazzar (Stratholme)",
            } },
        },
    },
    [17637] = {
        p = "Alchemy",
        skill = 300,
        item = 13512,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Ras Frostwhisper (Scholomance)",
            } },
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Exalted: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [17638] = {
        p = "Alchemy",
        skill = 300,
        item = 13513,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Gyth (Blackrock Spire)",
            } },
            { t = "Reputation Vendor", d = {
                "Lower City - Exalted: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [18238] = {
        p = "Cooking",
        skill = 225,
        item = 6887,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gikkix (Tanaris 66.6, 22.1)",
            } },
        },
    },
    [18239] = {
        p = "Cooking",
        skill = 225,
        item = 13927,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
            } },
        },
    },
    [18240] = {
        p = "Cooking",
        skill = 240,
        item = 13928,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gikkix (Tanaris 66.6, 22.1)",
            } },
        },
    },
    [18241] = {
        p = "Cooking",
        skill = 225,
        item = 13930,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
            } },
        },
    },
    [18242] = {
        p = "Cooking",
        skill = 240,
        item = 13929,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
            } },
        },
    },
    [18243] = {
        p = "Cooking",
        skill = 250,
        item = 13931,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gikkix (Tanaris 66.6, 22.1)",
            } },
        },
    },
    [18244] = {
        p = "Cooking",
        skill = 250,
        item = 13932,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gikkix (Tanaris 66.6, 22.1)",
            } },
        },
    },
    [18245] = {
        p = "Cooking",
        skill = 275,
        item = 13933,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vivianna (Feralas 31.3, 43.5)",
                "Sheendra Tallgrass (Feralas 74.5, 42.8)",
            } },
        },
    },
    [18246] = {
        p = "Cooking",
        skill = 275,
        item = 13934,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vivianna (Feralas 31.3, 43.5)",
                "Sheendra Tallgrass (Feralas 74.5, 42.8)",
            } },
        },
    },
    [18247] = {
        p = "Cooking",
        skill = 275,
        item = 13935,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vivianna (Feralas 31.3, 43.5)",
                "Sheendra Tallgrass (Feralas 74.5, 42.8)",
            } },
        },
    },
    [18401] = {
        p = "Tailoring",
        skill = 250,
        item = 14048,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18402] = {
        p = "Tailoring",
        skill = 255,
        item = 13856,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18403] = {
        p = "Tailoring",
        skill = 255,
        item = 13869,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18404] = {
        p = "Tailoring",
        skill = 255,
        item = 13868,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18405] = {
        p = "Tailoring",
        skill = 260,
        item = 14046,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Qia (Winterspring 61.2, 37.2)",
            } },
        },
    },
    [18406] = {
        p = "Tailoring",
        skill = 260,
        item = 13858,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Darnall (Moonglade 51.6, 33.3)",
            } },
        },
    },
    [18407] = {
        p = "Tailoring",
        skill = 260,
        item = 13857,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18408] = {
        p = "Tailoring",
        skill = 260,
        item = 14042,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Twilight Fire Guard (Searing Gorge 25.5, 33.8)",
            } },
        },
    },
    [18409] = {
        p = "Tailoring",
        skill = 265,
        item = 13860,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Darnall (Moonglade 51.6, 33.3)",
            } },
        },
    },
    [18410] = {
        p = "Tailoring",
        skill = 265,
        item = 14143,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18411] = {
        p = "Tailoring",
        skill = 265,
        item = 13870,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18412] = {
        p = "Tailoring",
        skill = 270,
        item = 14043,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Twilight Fire Guard (Searing Gorge 25.5, 33.8)",
            } },
        },
    },
    [18413] = {
        p = "Tailoring",
        skill = 270,
        item = 14142,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18414] = {
        p = "Tailoring",
        skill = 270,
        item = 14100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18415] = {
        p = "Tailoring",
        skill = 270,
        item = 14101,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18416] = {
        p = "Tailoring",
        skill = 275,
        item = 14141,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18417] = {
        p = "Tailoring",
        skill = 275,
        item = 13863,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18418] = {
        p = "Tailoring",
        skill = 275,
        item = 14044,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Thaurissan Firewalker (Burning Steppes 61.1, 42)",
            } },
        },
    },
    [18419] = {
        p = "Tailoring",
        skill = 275,
        item = 14107,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Lorelae Wintersong (Moonglade 48.3, 40.1)",
            } },
        },
    },
    [18420] = {
        p = "Tailoring",
        skill = 275,
        item = 14103,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18421] = {
        p = "Tailoring",
        skill = 275,
        item = 14132,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18422] = {
        p = "Tailoring",
        skill = 275,
        item = 14134,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Overmaster Pyron (Searing Gorge 26.2, 74.9)",
            } },
        },
    },
    [18423] = {
        p = "Tailoring",
        skill = 280,
        item = 13864,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18424] = {
        p = "Tailoring",
        skill = 280,
        item = 13871,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18434] = {
        p = "Tailoring",
        skill = 280,
        item = 14045,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Thaurissan Firewalker (Burning Steppes 61.1, 42)",
            } },
        },
    },
    [18436] = {
        p = "Tailoring",
        skill = 285,
        item = 14136,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cobalt Mageweaver (Winterspring 59.5, 49.2)",
            } },
        },
    },
    [18437] = {
        p = "Tailoring",
        skill = 285,
        item = 14108,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18438] = {
        p = "Tailoring",
        skill = 285,
        item = 13865,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18439] = {
        p = "Tailoring",
        skill = 290,
        item = 14104,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18440] = {
        p = "Tailoring",
        skill = 290,
        item = 14137,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18441] = {
        p = "Tailoring",
        skill = 290,
        item = 14144,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18442] = {
        p = "Tailoring",
        skill = 290,
        item = 14111,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18444] = {
        p = "Tailoring",
        skill = 295,
        item = 13866,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18445] = {
        p = "Tailoring",
        skill = 300,
        item = 14155,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18446] = {
        p = "Tailoring",
        skill = 300,
        item = 14128,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18447] = {
        p = "Tailoring",
        skill = 300,
        item = 14138,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18448] = {
        p = "Tailoring",
        skill = 300,
        item = 14139,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18449] = {
        p = "Tailoring",
        skill = 300,
        item = 13867,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18450] = {
        p = "Tailoring",
        skill = 300,
        item = 14130,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18451] = {
        p = "Tailoring",
        skill = 300,
        item = 14106,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18452] = {
        p = "Tailoring",
        skill = 300,
        item = 14140,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18453] = {
        p = "Tailoring",
        skill = 300,
        item = 14112,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18454] = {
        p = "Tailoring",
        skill = 300,
        item = 14146,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18455] = {
        p = "Tailoring",
        skill = 300,
        item = 14156,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [18456] = {
        p = "Tailoring",
        skill = 300,
        item = 14154,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Balnazzar (Stratholme)",
            } },
        },
    },
    [18457] = {
        p = "Tailoring",
        skill = 300,
        item = 14152,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Firebrand Pyromancer (Blackrock Spire)",
            } },
        },
    },
    [18458] = {
        p = "Tailoring",
        skill = 300,
        item = 14153,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Darkmaster Gandling (Scholomance)",
            } },
        },
    },
    [18560] = {
        p = "Tailoring",
        skill = 250,
        item = 14342,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Qia (Winterspring 61.2, 37.2)",
            } },
        },
    },
    [18629] = {
        p = "First Aid",
        skill = 260,
        item = 14529,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [18630] = {
        p = "First Aid",
        skill = 290,
        item = 14530,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19047] = {
        p = "Leatherworking",
        skill = 250,
        item = 15407,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19048] = {
        p = "Leatherworking",
        skill = 255,
        item = 15077,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zannok Hidepiercer (Silithus 81.9, 17.8)",
            } },
        },
    },
    [19049] = {
        p = "Leatherworking",
        skill = 260,
        item = 15083,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Leonard Porter (Western Plaguelands 43, 84.3)",
                "Werg Thickblade (Tirisfal Glades 83.2, 69.7)",
            } },
        },
    },
    [19050] = {
        p = "Leatherworking",
        skill = 260,
        item = 15045,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Masat T'andr (Swamp of Sorrows 26.3, 31.6)",
            } },
        },
    },
    [19051] = {
        p = "Leatherworking",
        skill = 265,
        item = 15076,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Portal Seeker (Blasted Lands 51.1, 34)",
                "Shadowsworn Thug (Blasted Lands 63.8, 32)",
            } },
        },
    },
    [19052] = {
        p = "Leatherworking",
        skill = 265,
        item = 15084,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19053] = {
        p = "Leatherworking",
        skill = 265,
        item = 15074,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Blimo Gadgetspring (Azshara 45.3, 90.9)",
            } },
        },
    },
    [19054] = {
        p = "Leatherworking",
        skill = 300,
        item = 15047,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "General Drakkisath (Blackrock Spire)",
            } },
        },
    },
    [19055] = {
        p = "Leatherworking",
        skill = 270,
        item = 15091,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19058] = {
        p = "Leatherworking",
        skill = 250,
        item = 15564,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19059] = {
        p = "Leatherworking",
        skill = 270,
        item = 15054,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Firegut Brute (Burning Steppes 82.5, 48.1)",
            } },
        },
    },
    [19060] = {
        p = "Leatherworking",
        skill = 270,
        item = 15046,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Murk Worm (The Temple of Atal'Hakkar)",
            } },
        },
    },
    [19061] = {
        p = "Leatherworking",
        skill = 270,
        item = 15061,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Pratt McGrubben (Feralas 30.6, 42.7)",
                "Jangdor Swiftstrider (Feralas 74.5, 42.9)",
            } },
        },
    },
    [19062] = {
        p = "Leatherworking",
        skill = 270,
        item = 15067,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gigget Zipcoil (The Hinterlands 34.5, 38.5)",
            } },
        },
    },
    [19063] = {
        p = "Leatherworking",
        skill = 275,
        item = 15073,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19064] = {
        p = "Leatherworking",
        skill = 275,
        item = 15078,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackrock Soldier (Burning Steppes 44, 52.8)",
            } },
        },
    },
    [19065] = {
        p = "Leatherworking",
        skill = 275,
        item = 15092,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19066] = {
        p = "Leatherworking",
        skill = 275,
        item = 15071,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Qia (Winterspring 61.2, 37.2)",
            } },
        },
    },
    [19067] = {
        p = "Leatherworking",
        skill = 275,
        item = 15057,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Leonard Porter (Western Plaguelands 43, 84.3)",
                "Werg Thickblade (Tirisfal Glades 83.2, 69.7)",
            } },
        },
    },
    [19068] = {
        p = "Leatherworking",
        skill = 275,
        item = 15064,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Friendly: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [19070] = {
        p = "Leatherworking",
        skill = 280,
        item = 15082,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19071] = {
        p = "Leatherworking",
        skill = 280,
        item = 15086,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19072] = {
        p = "Leatherworking",
        skill = 280,
        item = 15093,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19073] = {
        p = "Leatherworking",
        skill = 280,
        item = 15072,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19074] = {
        p = "Leatherworking",
        skill = 285,
        item = 15069,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Winterfall Den Watcher (Winterspring 68, 35.5)",
            } },
        },
    },
    [19075] = {
        p = "Leatherworking",
        skill = 285,
        item = 15079,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackrock Slayer (Burning Steppes 44.4, 50.7)",
            } },
        },
    },
    [19076] = {
        p = "Leatherworking",
        skill = 285,
        item = 15053,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Firebrand Grunt (Blackrock Spire)",
            } },
        },
    },
    [19077] = {
        p = "Leatherworking",
        skill = 285,
        item = 15048,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Blimo Gadgetspring (Azshara 45.3, 90.9)",
            } },
        },
    },
    [19078] = {
        p = "Leatherworking",
        skill = 285,
        item = 15060,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Deadwood Shaman (Felwood 62.5, 10.3)",
            } },
        },
    },
    [19079] = {
        p = "Leatherworking",
        skill = 285,
        item = 15056,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Arkkoran Oracle (Azshara 78, 41.8)",
            } },
        },
    },
    [19080] = {
        p = "Leatherworking",
        skill = 285,
        item = 15065,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Friendly: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [19081] = {
        p = "Leatherworking",
        skill = 290,
        item = 15075,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19082] = {
        p = "Leatherworking",
        skill = 290,
        item = 15094,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19083] = {
        p = "Leatherworking",
        skill = 290,
        item = 15087,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19084] = {
        p = "Leatherworking",
        skill = 290,
        item = 15063,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nergal (Un'Goro Crater 43.3, 7.7)",
            } },
        },
    },
    [19085] = {
        p = "Leatherworking",
        skill = 290,
        item = 15050,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Plugger Spazzring (Blackrock Depths)",
            } },
        },
    },
    [19086] = {
        p = "Leatherworking",
        skill = 290,
        item = 15066,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Vilebranch Hideskinner (The Hinterlands 62.2, 69.2)",
            } },
        },
    },
    [19087] = {
        p = "Leatherworking",
        skill = 295,
        item = 15070,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Winterfall Totemic (Felwood 41.5, 42.7)",
            } },
        },
    },
    [19088] = {
        p = "Leatherworking",
        skill = 295,
        item = 15080,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zannok Hidepiercer (Silithus 81.9, 17.8)",
            } },
        },
    },
    [19089] = {
        p = "Leatherworking",
        skill = 295,
        item = 15049,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cliff Breaker (Azshara 66, 13.2)",
            } },
        },
    },
    [19090] = {
        p = "Leatherworking",
        skill = 295,
        item = 15058,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Son of Arkkoroc (Azshara 65.5, 54.4)",
            } },
        },
    },
    [19091] = {
        p = "Leatherworking",
        skill = 300,
        item = 15095,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19092] = {
        p = "Leatherworking",
        skill = 300,
        item = 15088,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19093] = {
        p = "Leatherworking",
        skill = 300,
        item = 15138,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #7493 (Orgrimmar 51, 76.5)",
                "Quest #7497 (Stormwind City 67.2, 85.5)",
            } },
            { t = "Special", d = {
                "Quest to obtain the recipe opens up after turning in the Head of Onyxia. (Onyxia's Lair)",
            } },
        },
    },
    [19094] = {
        p = "Leatherworking",
        skill = 300,
        item = 15051,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Anvilrage Marshal (Blackrock Depths)",
            } },
        },
    },
    [19095] = {
        p = "Leatherworking",
        skill = 300,
        item = 15059,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Decaying Horror (Western Plaguelands 62, 37.6)",
            } },
        },
    },
    [19097] = {
        p = "Leatherworking",
        skill = 300,
        item = 15062,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Glutinous Ooze (Un'Goro Crater 39, 37.7)",
                "Muculent Ooze (Un'Goro Crater 62.2, 25.4)",
                "Cloned Ooze (Un'Goro Crater 45.5, 22.7)",
                "Primal Ooze (Un'Goro Crater 51.8, 34.9)",
            } },
        },
    },
    [19098] = {
        p = "Leatherworking",
        skill = 300,
        item = 15085,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19100] = {
        p = "Leatherworking",
        skill = 300,
        item = 15081,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackrock Battlemaster (Burning Steppes 40.5, 35.8)",
            } },
        },
    },
    [19101] = {
        p = "Leatherworking",
        skill = 300,
        item = 15055,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Firebrand Legionnaire (Blackrock Spire)",
            } },
        },
    },
    [19102] = {
        p = "Leatherworking",
        skill = 300,
        item = 15090,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19103] = {
        p = "Leatherworking",
        skill = 300,
        item = 15096,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19104] = {
        p = "Leatherworking",
        skill = 300,
        item = 15068,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Winterfall Ursa (Winterspring 67.5, 36.3)",
            } },
        },
    },
    [19107] = {
        p = "Leatherworking",
        skill = 300,
        item = 15052,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Anvilrage Captain (Blackrock Depths)",
            } },
        },
    },
    [19435] = {
        p = "Tailoring",
        skill = 290,
        item = 15802,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #6032 (Felwood 65.7, 2.9)",
            } },
        },
    },
    [19567] = {
        p = "Engineering",
        skill = 250,
        item = 15846,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19666] = {
        p = "Blacksmithing",
        skill = 100,
        item = 15869,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19667] = {
        p = "Blacksmithing",
        skill = 150,
        item = 15870,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19668] = {
        p = "Blacksmithing",
        skill = 200,
        item = 15871,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19669] = {
        p = "Blacksmithing",
        skill = 275,
        item = 15872,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19788] = {
        p = "Engineering",
        skill = 250,
        item = 15992,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19790] = {
        p = "Engineering",
        skill = 260,
        item = 15993,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19791] = {
        p = "Engineering",
        skill = 260,
        item = 15994,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19792] = {
        p = "Engineering",
        skill = 260,
        item = 15995,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19793] = {
        p = "Engineering",
        skill = 265,
        item = 15996,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19794] = {
        p = "Engineering",
        skill = 270,
        item = 15999,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19795] = {
        p = "Engineering",
        skill = 275,
        item = 16000,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19796] = {
        p = "Engineering",
        skill = 275,
        item = 16004,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Doomforge Craftsman (Blackrock Depths)",
            } },
        },
    },
    [19799] = {
        p = "Engineering",
        skill = 285,
        item = 16005,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Weapon Technician (Blackrock Depths)",
            } },
        },
    },
    [19800] = {
        p = "Engineering",
        skill = 285,
        item = 15997,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19814] = {
        p = "Engineering",
        skill = 275,
        item = 16023,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xizzer Fizzbolt (Winterspring 60.8, 38.6)",
            } },
        },
    },
    [19815] = {
        p = "Engineering",
        skill = 285,
        item = 16006,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xizzer Fizzbolt (Winterspring 60.8, 38.6)",
            } },
        },
    },
    [19819] = {
        p = "Engineering",
        skill = 290,
        item = 16009,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Crimson Inquisitor (Stratholme)",
            } },
        },
    },
    [19825] = {
        p = "Engineering",
        skill = 290,
        item = 16008,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [19830] = {
        p = "Engineering",
        skill = 300,
        item = 16022,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cobalt Mageweaver (Winterspring 59.5, 49.2)",
            } },
        },
    },
    [19831] = {
        p = "Engineering",
        skill = 300,
        item = 16040,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [19833] = {
        p = "Engineering",
        skill = 300,
        item = 16007,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Mossflayer Shadowhunter (Eastern Plaguelands 60.9, 21.5)",
            } },
        },
    },
    [20008] = {
        p = "Enchanting",
        skill = 255,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20009] = {
        p = "Enchanting",
        skill = 270,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [20010] = {
        p = "Enchanting",
        skill = 295,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Deadwind Warlock (Deadwind Pass 59.8, 74.4)",
            } },
        },
    },
    [20011] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [20012] = {
        p = "Enchanting",
        skill = 270,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20013] = {
        p = "Enchanting",
        skill = 295,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20014] = {
        p = "Enchanting",
        skill = 265,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20015] = {
        p = "Enchanting",
        skill = 285,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lorelae Wintersong (Moonglade 48.3, 40.1)",
            } },
        },
    },
    [20016] = {
        p = "Enchanting",
        skill = 280,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20017] = {
        p = "Enchanting",
        skill = 265,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Mythrin'dir (Darnassus 60, 19.1)",
                "Daniel Bartlett (Undercity 64.2, 37.7)",
            } },
        },
    },
    [20020] = {
        p = "Enchanting",
        skill = 260,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [20023] = {
        p = "Enchanting",
        skill = 295,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20024] = {
        p = "Enchanting",
        skill = 275,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [20025] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [20026] = {
        p = "Enchanting",
        skill = 275,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Qia (Winterspring 61.2, 37.2)",
            } },
        },
    },
    [20028] = {
        p = "Enchanting",
        skill = 290,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20029] = {
        p = "Enchanting",
        skill = 285,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Anguished Highborne (Winterspring 50.7, 41.9)",
            } },
        },
    },
    [20030] = {
        p = "Enchanting",
        skill = 295,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Blackhand Elite (Blackrock Spire)",
            } },
        },
    },
    [20031] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Spirestone Warlord (Blackrock Spire)",
            } },
        },
    },
    [20032] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Spectral Researcher (Scholomance)",
            } },
        },
    },
    [20033] = {
        p = "Enchanting",
        skill = 295,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Thuzadin Shadowcaster (Stratholme)",
                "Bonechewer Backbreaker (Terokkar Forest 66, 55.2)",
            } },
        },
    },
    [20034] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Scarlet Spellbinder (Western Plaguelands 52.7, 38.4)",
                "Scarlet Archmage (Eastern Plaguelands 81.5, 75.4)",
            } },
        },
    },
    [20035] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Scholomance Adept (Scholomance)",
            } },
        },
    },
    [20036] = {
        p = "Enchanting",
        skill = 300,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Crimson Sorcerer (Stratholme)",
            } },
        },
    },
    [20051] = {
        p = "Enchanting",
        skill = 290,
        item = 16207,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lorelae Wintersong (Moonglade 48.3, 40.1)",
            } },
        },
    },
    [20201] = {
        p = "Blacksmithing",
        skill = 275,
        item = 16206,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20626] = {
        p = "Cooking",
        skill = 225,
        item = 16766,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Jabbey (Tanaris 67, 22)",
            } },
        },
    },
    [20648] = {
        p = "Leatherworking",
        skill = 100,
        item = 2319,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20649] = {
        p = "Leatherworking",
        skill = 150,
        item = 4234,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20650] = {
        p = "Leatherworking",
        skill = 200,
        item = 4304,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [20848] = {
        p = "Tailoring",
        skill = 300,
        item = 16980,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20849] = {
        p = "Tailoring",
        skill = 300,
        item = 16979,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Friendly: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20853] = {
        p = "Leatherworking",
        skill = 295,
        item = 16982,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20854] = {
        p = "Leatherworking",
        skill = 300,
        item = 16983,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20855] = {
        p = "Leatherworking",
        skill = 300,
        item = 16984,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20872] = {
        p = "Blacksmithing",
        skill = 295,
        item = 16989,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20873] = {
        p = "Blacksmithing",
        skill = 300,
        item = 16988,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20874] = {
        p = "Blacksmithing",
        skill = 295,
        item = 17014,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Friendly: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20876] = {
        p = "Blacksmithing",
        skill = 300,
        item = 17013,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20890] = {
        p = "Blacksmithing",
        skill = 300,
        item = 17015,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20897] = {
        p = "Blacksmithing",
        skill = 300,
        item = 17016,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [20916] = {
        p = "Cooking",
        skill = 175,
        item = 8364,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Heldan Galesong (Darkshore 37, 56.3)",
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
                "Shankys (Orgrimmar 69.1, 31.4)",
                "Wik'Tar (Ashenvale 11.8, 34.1)",
                "Lindea Rabonne (Hillsbrad Foothills 50.6, 61)",
                "Wulan (Desolace 26.2, 69.7)",
                "Stuart Fleming (Wetlands 8.1, 58.4)",
                "Lizbeth Cromwell (Undercity 81.2, 31)",
                "Tansy Puddlefizz (Ironforge 48, 6.3)",
            } },
        },
    },
    [21143] = {
        p = "Cooking",
        skill = 1,
        item = 17197,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eebee Jinglepocket (Shattrath City 51, 31.3)",
                "Wolgren Jinglepocket (The Exodar 54.5, 47.2)",
                "Khole Jinglepocket (Stormwind City 62.2, 70.6)",
                "Seersa Copperpinch (Thunder Bluff 42, 55.1)",
                "Nardstrum Copperpinch (Undercity 67.5, 38.7)",
                "Wulmort Jinglepocket (Ironforge 33, 67.6)",
                "Hotoppik Copperpinch (Silvermoon City 63.5, 79.1)",
                "Penney Copperpinch (Orgrimmar 53.5, 66.1)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21144] = {
        p = "Cooking",
        skill = 35,
        item = 17198,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eebee Jinglepocket (Shattrath City 51, 31.3)",
                "Wolgren Jinglepocket (The Exodar 54.5, 47.2)",
                "Khole Jinglepocket (Stormwind City 62.2, 70.6)",
                "Seersa Copperpinch (Thunder Bluff 42, 55.1)",
                "Nardstrum Copperpinch (Undercity 67.5, 38.7)",
                "Wulmort Jinglepocket (Ironforge 33, 67.6)",
                "Hotoppik Copperpinch (Silvermoon City 63.5, 79.1)",
                "Penney Copperpinch (Orgrimmar 53.5, 66.1)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21161] = {
        p = "Blacksmithing",
        skill = 300,
        item = 17193,
        q = "Epic",
        sources = {
            { t = "Quest", d = {
                "Quest #7604 (Blackrock Depths)",
            } },
        },
    },
    [21175] = {
        p = "Cooking",
        skill = 200,
        item = 17222,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [21913] = {
        p = "Blacksmithing",
        skill = 190,
        item = 17704,
        q = "Uncommon",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21923] = {
        p = "Alchemy",
        skill = 190,
        item = 17708,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21931] = {
        p = "Enchanting",
        skill = 190,
        q = "Uncommon",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21940] = {
        p = "Engineering",
        skill = 190,
        item = 17716,
        q = "Uncommon",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21943] = {
        p = "Leatherworking",
        skill = 190,
        item = 17721,
        q = "Uncommon",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [21945] = {
        p = "Tailoring",
        skill = 190,
        item = 17723,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [22331] = {
        p = "Leatherworking",
        skill = 250,
        item = 8170,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [22480] = {
        p = "Cooking",
        skill = 225,
        item = 18045,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Truk Wildbeard (The Hinterlands 14.4, 42.5)",
                "Dirge Quikcleave (Tanaris 52.6, 28.1)",
                "Innkeeper Fizzgrimble (Tanaris 52.5, 27.9)",
            } },
        },
    },
    [22704] = {
        p = "Engineering",
        skill = 300,
        item = 18232,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "The schematic can be found on the floor near Golem Lord Argelmach in Blackrock Depths. Only engineers with 300 skill may learn the schematic after clicking on it. (Blackrock Depths)",
            } },
        },
    },
    [22711] = {
        p = "Leatherworking",
        skill = 200,
        item = 18238,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rikqiz (Stranglethorn Vale 28.5, 76)",
            } },
        },
    },
    [22727] = {
        p = "Leatherworking",
        skill = 300,
        item = 18251,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22732] = {
        p = "Alchemy",
        skill = 300,
        item = 18253,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22749] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22750] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22757] = {
        p = "Blacksmithing",
        skill = 300,
        item = 18262,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22759] = {
        p = "Tailoring",
        skill = 300,
        item = 18263,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22761] = {
        p = "Cooking",
        skill = 275,
        item = 18254,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Pusillin (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22793] = {
        p = "Engineering",
        skill = 300,
        item = 18283,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22795] = {
        p = "Engineering",
        skill = 300,
        item = 18282,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22797] = {
        p = "Engineering",
        skill = 300,
        item = 18168,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [22808] = {
        p = "Alchemy",
        skill = 215,
        item = 18294,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [22813] = {
        p = "Tailoring",
        skill = 275,
        item = 18258,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #5518 (Dire Maul)",
            } },
        },
    },
    [22815] = {
        p = "Leatherworking",
        skill = 275,
        item = 18258,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #5518 (Dire Maul)",
            } },
        },
    },
    [22866] = {
        p = "Tailoring",
        skill = 300,
        item = 18405,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22867] = {
        p = "Tailoring",
        skill = 300,
        item = 18407,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22868] = {
        p = "Tailoring",
        skill = 300,
        item = 18408,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22869] = {
        p = "Tailoring",
        skill = 300,
        item = 18409,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22870] = {
        p = "Tailoring",
        skill = 300,
        item = 18413,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22902] = {
        p = "Tailoring",
        skill = 300,
        item = 18486,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Shen'dralar Provisioner (Dire Maul)",
            } },
        },
    },
    [22921] = {
        p = "Leatherworking",
        skill = 300,
        item = 18504,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22922] = {
        p = "Leatherworking",
        skill = 300,
        item = 18506,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22923] = {
        p = "Leatherworking",
        skill = 300,
        item = 18508,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22926] = {
        p = "Leatherworking",
        skill = 300,
        item = 18509,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22927] = {
        p = "Leatherworking",
        skill = 300,
        item = 18510,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22928] = {
        p = "Leatherworking",
        skill = 300,
        item = 18511,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Randomly obtained in Dire Maul (North) in Knot Thimblejack's cache. (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [22967] = {
        p = "Mining",
        skill = 300,
        item = 17771,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Master Elemental Shaper Krixix (Blackwing Lair)",
            } },
        },
    },
    [23066] = {
        p = "Engineering",
        skill = 150,
        item = 9318,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Sovik (Orgrimmar 75.6, 25.2)",
            } },
        },
    },
    [23067] = {
        p = "Engineering",
        skill = 150,
        item = 9312,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gearcutter Cogspinner (Ironforge 68, 43.1)",
            } },
        },
    },
    [23068] = {
        p = "Engineering",
        skill = 150,
        item = 9313,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Crazk Sparks (Stranglethorn Vale 28.3, 76.7)",
                "Gagsprocket (The Barrens 62.7, 36.3)",
            } },
        },
    },
    [23069] = {
        p = "Engineering",
        skill = 200,
        item = 18588,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Blizrik Buckshot (Tanaris 50.8, 27.6)",
            } },
        },
    },
    [23070] = {
        p = "Engineering",
        skill = 250,
        item = 18641,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [23071] = {
        p = "Engineering",
        skill = 260,
        item = 18631,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [23077] = {
        p = "Engineering",
        skill = 260,
        item = 18634,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xizzer Fizzbolt (Winterspring 60.8, 38.6)",
            } },
        },
    },
    [23078] = {
        p = "Engineering",
        skill = 265,
        item = 18587,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Plugger Spazzring (Blackrock Depths)",
            } },
        },
    },
    [23079] = {
        p = "Engineering",
        skill = 275,
        item = 18637,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "DM Tribute Run - Chest (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [23080] = {
        p = "Engineering",
        skill = 275,
        item = 18594,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xizzer Fizzbolt (Winterspring 60.8, 38.6)",
            } },
        },
    },
    [23081] = {
        p = "Engineering",
        skill = 290,
        item = 18638,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Solakar Flamewreath (Blackrock Spire)",
            } },
        },
    },
    [23082] = {
        p = "Engineering",
        skill = 300,
        item = 18639,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Crimson Inquisitor (Stratholme)",
            } },
        },
    },
    [23096] = {
        p = "Engineering",
        skill = 265,
        item = 18645,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Weapon Technician (Blackrock Depths)",
            } },
        },
    },
    [23129] = {
        p = "Engineering",
        skill = 260,
        item = 18660,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Weapon Technician (Blackrock Depths)",
            } },
        },
    },
    [23190] = {
        p = "Leatherworking",
        skill = 150,
        item = 18662,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Bombus Finespindle (Ironforge 39.6, 34.1)",
                "Tamar (Orgrimmar 63, 45.3)",
            } },
        },
    },
    [23399] = {
        p = "Leatherworking",
        skill = 155,
        item = 18948,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Saenorion (Darnassus 63.8, 22.1)",
                "Joseph Moore (Undercity 70.2, 57.8)",
            } },
        },
    },
    [23486] = {
        p = "Engineering",
        skill = 260,
        item = 18984,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [23489] = {
        p = "Engineering",
        skill = 260,
        item = 18986,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [23507] = {
        p = "Engineering",
        skill = 250,
        item = 19026,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zorbin Fandazzle (Feralas 44.8, 43.4)",
            } },
        },
    },
    [23628] = {
        p = "Blacksmithing",
        skill = 290,
        item = 19043,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Honored: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23629] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19048,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Revered: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23632] = {
        p = "Blacksmithing",
        skill = 290,
        item = 19051,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23633] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19057,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Revered: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Revered: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23636] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19148,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23637] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19164,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23638] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19166,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23639] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19167,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23650] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19170,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Exalted: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23652] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19168,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Exalted: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23653] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19169,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Exalted: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23662] = {
        p = "Tailoring",
        skill = 290,
        item = 19047,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Honored: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23663] = {
        p = "Tailoring",
        skill = 300,
        item = 19050,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Revered: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23664] = {
        p = "Tailoring",
        skill = 290,
        item = 19056,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23665] = {
        p = "Tailoring",
        skill = 300,
        item = 19059,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Revered: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Revered: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23666] = {
        p = "Tailoring",
        skill = 300,
        item = 19156,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23667] = {
        p = "Tailoring",
        skill = 300,
        item = 19165,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23703] = {
        p = "Leatherworking",
        skill = 290,
        item = 19044,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Honored: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23704] = {
        p = "Leatherworking",
        skill = 300,
        item = 19049,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Revered: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23705] = {
        p = "Leatherworking",
        skill = 290,
        item = 19052,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23706] = {
        p = "Leatherworking",
        skill = 300,
        item = 19058,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Revered: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Revered: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23707] = {
        p = "Leatherworking",
        skill = 300,
        item = 19149,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23708] = {
        p = "Leatherworking",
        skill = 300,
        item = 19157,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23709] = {
        p = "Leatherworking",
        skill = 300,
        item = 19162,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23710] = {
        p = "Leatherworking",
        skill = 300,
        item = 19163,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23787] = {
        p = "First Aid",
        skill = 300,
        item = 19440,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23799] = {
        p = "Enchanting",
        skill = 290,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Friendly: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23800] = {
        p = "Enchanting",
        skill = 290,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Honored: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [23801] = {
        p = "Enchanting",
        skill = 290,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Honored: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Honored: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23802] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Argent Quartermaster Hasana (Tirisfal Glades 83.2, 68.1)",
                "Argent Dawn - Revered: Quartermaster Miranda Breechlock (Eastern Plaguelands 75.8, 54.1)",
                "Argent Dawn - Revered: Argent Quartermaster Lightspark (Western Plaguelands 42.8, 83.8)",
            } },
        },
    },
    [23803] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Honored: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [23804] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Revered: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [24091] = {
        p = "Tailoring",
        skill = 300,
        item = 19682,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24092] = {
        p = "Tailoring",
        skill = 300,
        item = 19683,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24093] = {
        p = "Tailoring",
        skill = 300,
        item = 19684,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24121] = {
        p = "Leatherworking",
        skill = 300,
        item = 19685,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24122] = {
        p = "Leatherworking",
        skill = 300,
        item = 19686,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24123] = {
        p = "Leatherworking",
        skill = 300,
        item = 19687,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24124] = {
        p = "Leatherworking",
        skill = 300,
        item = 19688,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24125] = {
        p = "Leatherworking",
        skill = 300,
        item = 19689,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24136] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19690,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24137] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19691,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24138] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19692,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24139] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19693,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24140] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19694,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24141] = {
        p = "Blacksmithing",
        skill = 300,
        item = 19695,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24266] = {
        p = "Alchemy",
        skill = 300,
        item = 19931,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Obtained by clicking on a tablet in Zul'Gurub in the Edge of Madness. (Zul'Gurub)",
            } },
        },
    },
    [24356] = {
        p = "Engineering",
        skill = 300,
        item = 19999,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24357] = {
        p = "Engineering",
        skill = 300,
        item = 19998,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24365] = {
        p = "Alchemy",
        skill = 275,
        item = 20007,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Revered: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24366] = {
        p = "Alchemy",
        skill = 275,
        item = 20002,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24367] = {
        p = "Alchemy",
        skill = 285,
        item = 20008,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Exalted: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24368] = {
        p = "Alchemy",
        skill = 290,
        item = 20004,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [24399] = {
        p = "Blacksmithing",
        skill = 300,
        item = 20039,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Exalted: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [24418] = {
        p = "Cooking",
        skill = 150,
        item = 20074,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ogg'marr (Dustwallow Marsh 36.7, 31)",
            } },
        },
    },
    [24654] = {
        p = "Leatherworking",
        skill = 300,
        item = 20295,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [24655] = {
        p = "Leatherworking",
        skill = 260,
        item = 20296,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [24703] = {
        p = "Leatherworking",
        skill = 300,
        item = 20380,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Exalted: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24801] = {
        p = "Cooking",
        skill = 285,
        item = 20452,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #8313 (Silithus 38, 45.3)",
            } },
        },
    },
    [24846] = {
        p = "Leatherworking",
        skill = 300,
        item = 20481,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24847] = {
        p = "Leatherworking",
        skill = 300,
        item = 20480,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24848] = {
        p = "Leatherworking",
        skill = 300,
        item = 20479,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24849] = {
        p = "Leatherworking",
        skill = 300,
        item = 20476,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24850] = {
        p = "Leatherworking",
        skill = 300,
        item = 20477,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24851] = {
        p = "Leatherworking",
        skill = 300,
        item = 20478,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [24901] = {
        p = "Tailoring",
        skill = 300,
        item = 20538,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24902] = {
        p = "Tailoring",
        skill = 300,
        item = 20539,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24903] = {
        p = "Tailoring",
        skill = 300,
        item = 20537,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24912] = {
        p = "Blacksmithing",
        skill = 300,
        item = 20549,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24913] = {
        p = "Blacksmithing",
        skill = 300,
        item = 20551,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24914] = {
        p = "Blacksmithing",
        skill = 300,
        item = 20550,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #8323 (Silithus 67.1, 69.7)",
            } },
        },
    },
    [24940] = {
        p = "Leatherworking",
        skill = 100,
        item = 20575,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Amy Davenport (Redridge Mountains 29.1, 47.5)",
            } },
        },
    },
    [25072] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Emperor Vek'nilash (Temple of Ahn'Qiraj)",
            } },
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Exalted: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [25073] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25074] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25078] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25079] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25080] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Exalted: Alurmi (Tanaris 63.6, 57.6)",
            } },
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25081] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Kania (Silithus 52, 39.6)",
            } },
        },
    },
    [25082] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Kania (Silithus 52, 39.6)",
            } },
        },
    },
    [25083] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25084] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Emperor Vek'lor (Temple of Ahn'Qiraj)",
            } },
            { t = "Reputation Vendor", d = {
                "Honor Hold - Exalted: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Exalted: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [25086] = {
        p = "Enchanting",
        skill = 300,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Exalted: Nakodu (Shattrath City 62.1, 69)",
            } },
            { t = "Special", d = {
                "Random BoP drop off of bosses in AQ40. (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [25124] = {
        p = "Enchanting",
        skill = 45,
        item = 20744,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ildine Sorrowspear (Dalaran 39.1, 41.5)",
                "Kania (Silithus 52, 39.6)",
                "Thaddeus Webb (Undercity 62, 60.7)",
                "Erilia (Eversong Woods 55.5, 54)",
                "Lilly (Silverpine Forest 43.1, 50.8)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Bradley Towns (Dragonblight 76.9, 62.2)",
                "Yurial Soulwater (Shattrath City 43.5, 96.9)",
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Leo Sarn (Silverpine Forest 53.9, 82.3)",
                "Alys Vol'tyr (Dragonblight 36.3, 46.5)",
                "Johan Barnes (Hellfire Peninsula 53.7, 66.1)",
                "Vaean (Darnassus 58.5, 14.4)",
                "Tilli Thistlefuzz (Ironforge 60.7, 44.2)",
                "Lyna (Silvermoon City 69.1, 24.4)",
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Kithas (Orgrimmar 53.7, 38)",
                "Jessara Cordell (Stormwind City 53, 74.2)",
                "Modoru (Dragonblight 28.9, 55.9)",
                "Librarian Erickson (Borean Tundra 46.7, 32.5)",
                "Dealer Malij (Netherstorm 44.2, 34)",
                "Felannia (Hellfire Peninsula 52.3, 36.1)",
                "Asarnan (Netherstorm 44.2, 33.7)",
            } },
        },
    },
    [25125] = {
        p = "Enchanting",
        skill = 150,
        item = 20745,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ildine Sorrowspear (Dalaran 39.1, 41.5)",
                "Kania (Silithus 52, 39.6)",
                "Thaddeus Webb (Undercity 62, 60.7)",
                "Erilia (Eversong Woods 55.5, 54)",
                "Lilly (Silverpine Forest 43.1, 50.8)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Bradley Towns (Dragonblight 76.9, 62.2)",
                "Yurial Soulwater (Shattrath City 43.5, 96.9)",
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Leo Sarn (Silverpine Forest 53.9, 82.3)",
                "Alys Vol'tyr (Dragonblight 36.3, 46.5)",
                "Johan Barnes (Hellfire Peninsula 53.7, 66.1)",
                "Vaean (Darnassus 58.5, 14.4)",
                "Tilli Thistlefuzz (Ironforge 60.7, 44.2)",
                "Lyna (Silvermoon City 69.1, 24.4)",
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Kithas (Orgrimmar 53.7, 38)",
                "Jessara Cordell (Stormwind City 53, 74.2)",
                "Modoru (Dragonblight 28.9, 55.9)",
                "Librarian Erickson (Borean Tundra 46.7, 32.5)",
                "Dealer Malij (Netherstorm 44.2, 34)",
                "Felannia (Hellfire Peninsula 52.3, 36.1)",
                "Asarnan (Netherstorm 44.2, 33.7)",
            } },
        },
    },
    [25126] = {
        p = "Enchanting",
        skill = 200,
        item = 20746,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ildine Sorrowspear (Dalaran 39.1, 41.5)",
                "Kania (Silithus 52, 39.6)",
                "Thaddeus Webb (Undercity 62, 60.7)",
                "Erilia (Eversong Woods 55.5, 54)",
                "Lilly (Silverpine Forest 43.1, 50.8)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Bradley Towns (Dragonblight 76.9, 62.2)",
                "Yurial Soulwater (Shattrath City 43.5, 96.9)",
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Leo Sarn (Silverpine Forest 53.9, 82.3)",
                "Alys Vol'tyr (Dragonblight 36.3, 46.5)",
                "Johan Barnes (Hellfire Peninsula 53.7, 66.1)",
                "Vaean (Darnassus 58.5, 14.4)",
                "Tilli Thistlefuzz (Ironforge 60.7, 44.2)",
                "Lyna (Silvermoon City 69.1, 24.4)",
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Kithas (Orgrimmar 53.7, 38)",
                "Jessara Cordell (Stormwind City 53, 74.2)",
                "Modoru (Dragonblight 28.9, 55.9)",
                "Librarian Erickson (Borean Tundra 46.7, 32.5)",
                "Dealer Malij (Netherstorm 44.2, 34)",
                "Felannia (Hellfire Peninsula 52.3, 36.1)",
                "Asarnan (Netherstorm 44.2, 33.7)",
            } },
        },
    },
    [25127] = {
        p = "Enchanting",
        skill = 250,
        item = 20747,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kania (Silithus 52, 39.6)",
            } },
        },
    },
    [25128] = {
        p = "Enchanting",
        skill = 275,
        item = 20750,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kania (Silithus 52, 39.6)",
            } },
        },
    },
    [25129] = {
        p = "Enchanting",
        skill = 300,
        item = 20749,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Honored: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [25130] = {
        p = "Enchanting",
        skill = 300,
        item = 20748,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Zandalar Tribe - Friendly: Rin'wosho the Trader (Stranglethorn Vale 15.1, 16)",
            } },
        },
    },
    [25146] = {
        p = "Alchemy",
        skill = 300,
        item = 7068,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thorium Brotherhood - Friendly: Lokhtos Darkbargainer (Blackrock Depths)",
            } },
        },
    },
    [25255] = {
        p = "Jewelcrafting",
        skill = 1,
        item = 20816,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [25278] = {
        p = "Jewelcrafting",
        skill = 50,
        item = 20817,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25280] = {
        p = "Jewelcrafting",
        skill = 50,
        item = 20818,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25283] = {
        p = "Jewelcrafting",
        skill = 30,
        item = 20821,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25284] = {
        p = "Jewelcrafting",
        skill = 60,
        item = 20820,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25287] = {
        p = "Jewelcrafting",
        skill = 70,
        item = 20823,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25305] = {
        p = "Jewelcrafting",
        skill = 90,
        item = 20826,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25317] = {
        p = "Jewelcrafting",
        skill = 80,
        item = 20827,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25318] = {
        p = "Jewelcrafting",
        skill = 100,
        item = 20828,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25320] = {
        p = "Jewelcrafting",
        skill = 150,
        item = 20856,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Arred (The Exodar 45, 26)",
                "Gelanthis (Silvermoon City 90.8, 73.6)",
                "Felika (Orgrimmar 60.5, 50.7)",
                "Edna Mullby (Stormwind City 64.6, 71.5)",
            } },
        },
    },
    [25321] = {
        p = "Jewelcrafting",
        skill = 120,
        item = 20832,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25323] = {
        p = "Jewelcrafting",
        skill = 125,
        item = 20833,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Ranik (The Barrens 61.9, 38.7)",
                "Dalria (Ashenvale 35.1, 52.1)",
            } },
        },
    },
    [25339] = {
        p = "Jewelcrafting",
        skill = 110,
        item = 20830,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Gelanthis (Silvermoon City 90.8, 73.6)",
                "Daniel Bartlett (Undercity 64.2, 37.7)",
                "Mythrin'dir (Darnassus 60, 19.1)",
                "Arred (The Exodar 45, 26)",
            } },
        },
    },
    [25490] = {
        p = "Jewelcrafting",
        skill = 50,
        item = 20907,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25493] = {
        p = "Jewelcrafting",
        skill = 1,
        item = 20906,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [25498] = {
        p = "Jewelcrafting",
        skill = 110,
        item = 20909,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25610] = {
        p = "Jewelcrafting",
        skill = 120,
        item = 20950,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Neal Allen (Wetlands 10.7, 56.8)",
                "Jandia (Thousand Needles 46.1, 51.5)",
            } },
        },
    },
    [25612] = {
        p = "Jewelcrafting",
        skill = 125,
        item = 20954,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Christoph Jeffcoat (Hillsbrad Foothills 62.4, 19.1)",
            } },
        },
    },
    [25613] = {
        p = "Jewelcrafting",
        skill = 135,
        item = 20955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25615] = {
        p = "Jewelcrafting",
        skill = 150,
        item = 20963,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25617] = {
        p = "Jewelcrafting",
        skill = 150,
        item = 20958,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Kireena (Desolace 51, 53.5)",
            } },
        },
    },
    [25618] = {
        p = "Jewelcrafting",
        skill = 160,
        item = 20966,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [25619] = {
        p = "Jewelcrafting",
        skill = 170,
        item = 20959,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Arred (The Exodar 45, 26)",
                "Gelanthis (Silvermoon City 90.8, 73.6)",
                "Felicia Doan (Undercity 64.3, 50.2)",
                "Burbik Gearspanner (Ironforge 46.5, 27.1)",
            } },
        },
    },
    [25620] = {
        p = "Jewelcrafting",
        skill = 170,
        item = 20960,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25621] = {
        p = "Jewelcrafting",
        skill = 180,
        item = 20961,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [25622] = {
        p = "Jewelcrafting",
        skill = 190,
        item = 20967,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [25659] = {
        p = "Cooking",
        skill = 300,
        item = 21023,
        q = "Epic",
        sources = {
            { t = "Quest", d = {
                "Quest #8586 (Tanaris 52.6, 28.1)",
            } },
        },
    },
    [25704] = {
        p = "Cooking",
        skill = 80,
        item = 21072,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Derak Nightfall (Hillsbrad Foothills 63, 18.5)",
                "Phea (The Exodar 54.7, 26.5)",
                "Gloria Femmel (Redridge Mountains 26.7, 43.5)",
                "\"Cookie\" McWeaksauce (Azuremyst Isle 46.7, 70.5)",
                "Naal Mistrunner (Thunder Bluff 51.1, 52.2)",
                "Otho Moji'ko (The Hinterlands 79.3, 79.1)",
                "Emrul Riknussun (Ironforge 59.9, 37.7)",
                "Nyoma (Teldrassil 57.2, 61.2)",
                "Tarban Hearthgrain (The Barrens 55.1, 32.1)",
                "Fyldan (Darnassus 48.6, 21.4)",
                "Erika Tate (Stormwind City 78.5, 53)",
                "Xen'to (Orgrimmar 57.5, 53.2)",
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
                "Ronald Burch (Undercity 62.4, 43.4)",
                "Jim Saltit (Shattrath City 63.6, 68.6)",
                "Provisioner Lorkran (Grizzly Hills 22.6, 66.1)",
                "Master Chef Mouldier (Ghostlands 48.3, 30.9)",
                "Wulan (Desolace 26.2, 69.7)",
                "Quelis (Silvermoon City 69.3, 70.7)",
            } },
        },
    },
    [25954] = {
        p = "Cooking",
        skill = 175,
        item = 21217,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Derak Nightfall (Hillsbrad Foothills 63, 18.5)",
                "Phea (The Exodar 54.7, 26.5)",
                "Gloria Femmel (Redridge Mountains 26.7, 43.5)",
                "\"Cookie\" McWeaksauce (Azuremyst Isle 46.7, 70.5)",
                "Naal Mistrunner (Thunder Bluff 51.1, 52.2)",
                "Otho Moji'ko (The Hinterlands 79.3, 79.1)",
                "Emrul Riknussun (Ironforge 59.9, 37.7)",
                "Nyoma (Teldrassil 57.2, 61.2)",
                "Tarban Hearthgrain (The Barrens 55.1, 32.1)",
                "Fyldan (Darnassus 48.6, 21.4)",
                "Erika Tate (Stormwind City 78.5, 53)",
                "Xen'to (Orgrimmar 57.5, 53.2)",
                "Micha Yance (Hillsbrad Foothills 49, 55.1)",
                "Kelsey Yance (Stranglethorn Vale 28.2, 74.4)",
                "Ronald Burch (Undercity 62.4, 43.4)",
                "Jim Saltit (Shattrath City 63.6, 68.6)",
                "Provisioner Lorkran (Grizzly Hills 22.6, 66.1)",
                "Master Chef Mouldier (Ghostlands 48.3, 30.9)",
                "Wulan (Desolace 26.2, 69.7)",
                "Quelis (Silvermoon City 69.3, 70.7)",
            } },
        },
    },
    [26011] = {
        p = "Engineering",
        skill = 250,
        item = 21277,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #8798 (Winterspring 60.9, 37.7)",
            } },
        },
    },
    [26085] = {
        p = "Tailoring",
        skill = 260,
        item = 21340,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Vizzklick (Tanaris 51, 27.4)",
            } },
        },
    },
    [26086] = {
        p = "Tailoring",
        skill = 280,
        item = 21341,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Jandice Barov (Scholomance)",
            } },
            { t = "Special", d = {
                "After you kill Jandice Barov in Scholomance, a book spawns that let's you learn this recipe (Scholomance)",
            } },
        },
    },
    [26087] = {
        p = "Tailoring",
        skill = 300,
        item = 21342,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Molten Core bosses. (Molten Core)",
            } },
        },
    },
    [26277] = {
        p = "Alchemy",
        skill = 250,
        item = 21546,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Dark Iron Slaver (Searing Gorge 43.8, 33.8)",
                "Dark Iron Taskmaster (Searing Gorge 44.4, 41.1)",
                "Dark Iron Watchman (Searing Gorge 69.3, 34.8)",
            } },
        },
    },
    [26279] = {
        p = "Leatherworking",
        skill = 300,
        item = 21278,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "The Windreaver (Silithus 27, 26.8)",
                "Princess Tempestria (Winterspring 52.7, 41.9)",
            } },
        },
    },
    [26403] = {
        p = "Tailoring",
        skill = 250,
        item = 21154,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26407] = {
        p = "Tailoring",
        skill = 250,
        item = 21542,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26416] = {
        p = "Engineering",
        skill = 125,
        item = 21558,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26417] = {
        p = "Engineering",
        skill = 125,
        item = 21559,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26418] = {
        p = "Engineering",
        skill = 125,
        item = 21557,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26420] = {
        p = "Engineering",
        skill = 175,
        item = 21589,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26421] = {
        p = "Engineering",
        skill = 175,
        item = 21590,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26422] = {
        p = "Engineering",
        skill = 175,
        item = 21592,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26423] = {
        p = "Engineering",
        skill = 225,
        item = 21571,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26424] = {
        p = "Engineering",
        skill = 225,
        item = 21574,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26425] = {
        p = "Engineering",
        skill = 225,
        item = 21576,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26426] = {
        p = "Engineering",
        skill = 275,
        item = 21714,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26427] = {
        p = "Engineering",
        skill = 275,
        item = 21716,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26428] = {
        p = "Engineering",
        skill = 275,
        item = 21718,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26442] = {
        p = "Engineering",
        skill = 225,
        item = 21569,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26443] = {
        p = "Engineering",
        skill = 275,
        item = 21570,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Fariel Starsong (Moonglade 54, 35.4)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [26745] = {
        p = "Tailoring",
        skill = 300,
        item = 21840,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26746] = {
        p = "Tailoring",
        skill = 315,
        item = 21841,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26747] = {
        p = "Tailoring",
        skill = 325,
        item = 21842,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eiin (Shattrath City 66.2, 68.7)",
                "Neii (The Exodar 64.5, 68.5)",
                "Deynna (Silvermoon City 55.8, 51)",
            } },
        },
    },
    [26749] = {
        p = "Tailoring",
        skill = 340,
        item = 21843,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Mathar G'ochar (Nagrand 57, 39.6)",
                "Eiin (Shattrath City 66.2, 68.7)",
            } },
        },
    },
    [26750] = {
        p = "Tailoring",
        skill = 345,
        item = 21844,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Mathar G'ochar (Nagrand 57, 39.6)",
                "Deynna (Silvermoon City 55.8, 51)",
                "Borto (Nagrand 53.3, 71.9)",
                "Neii (The Exodar 64.5, 68.5)",
            } },
        },
    },
    [26751] = {
        p = "Tailoring",
        skill = 350,
        item = 21845,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nasmara Moonsong (Shattrath City 66, 69)",
                "Ainderu Summerleaf (Dalaran 36.5, 34)",
            } },
        },
    },
    [26752] = {
        p = "Tailoring",
        skill = 355,
        item = 21846,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gidge Spellweaver (Shattrath City 66, 67.9)",
                "Lalla Brightweave (Dalaran 36.5, 33.5)",
            } },
        },
    },
    [26753] = {
        p = "Tailoring",
        skill = 365,
        item = 21847,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gidge Spellweaver (Shattrath City 66, 67.9)",
                "Lalla Brightweave (Dalaran 36.5, 33.5)",
            } },
        },
    },
    [26754] = {
        p = "Tailoring",
        skill = 375,
        item = 21848,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gidge Spellweaver (Shattrath City 66, 67.9)",
                "Lalla Brightweave (Dalaran 36.5, 33.5)",
            } },
        },
    },
    [26755] = {
        p = "Tailoring",
        skill = 375,
        item = 21858,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Sunfury Arcanist (Netherstorm 51, 82.5)",
                "Sunfury Arch Mage (Netherstorm 46.5, 81)",
            } },
            { t = "Vendor", d = {
                "Gidge Spellweaver (Shattrath City 66, 67.9)",
                "Lalla Brightweave (Dalaran 36.5, 33.5)",
            } },
        },
    },
    [26756] = {
        p = "Tailoring",
        skill = 355,
        item = 21869,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Andrion Darkspinner (Shattrath City 66, 67.8)",
                "Linna Bruder (Dalaran 34.6, 34.5)",
            } },
        },
    },
    [26757] = {
        p = "Tailoring",
        skill = 365,
        item = 21870,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Andrion Darkspinner (Shattrath City 66, 67.8)",
                "Linna Bruder (Dalaran 34.6, 34.5)",
            } },
        },
    },
    [26758] = {
        p = "Tailoring",
        skill = 375,
        item = 21871,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Andrion Darkspinner (Shattrath City 66, 67.8)",
                "Linna Bruder (Dalaran 34.6, 34.5)",
            } },
        },
    },
    [26759] = {
        p = "Tailoring",
        skill = 375,
        item = 21872,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Andrion Darkspinner (Shattrath City 66, 67.8)",
                "Linna Bruder (Dalaran 34.6, 34.5)",
            } },
        },
    },
    [26760] = {
        p = "Tailoring",
        skill = 355,
        item = 21873,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nasmara Moonsong (Shattrath City 66, 69)",
                "Ainderu Summerleaf (Dalaran 36.5, 34)",
            } },
        },
    },
    [26761] = {
        p = "Tailoring",
        skill = 365,
        item = 21874,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nasmara Moonsong (Shattrath City 66, 69)",
                "Ainderu Summerleaf (Dalaran 36.5, 34)",
            } },
        },
    },
    [26762] = {
        p = "Tailoring",
        skill = 375,
        item = 21875,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Nasmara Moonsong (Shattrath City 66, 69)",
                "Ainderu Summerleaf (Dalaran 36.5, 34)",
            } },
        },
    },
    [26763] = {
        p = "Tailoring",
        skill = 375,
        item = 21876,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Disembodied Vindicator (Netherstorm 36, 55.5)",
            } },
            { t = "Vendor", d = {
                "Nasmara Moonsong (Shattrath City 66, 69)",
                "Ainderu Summerleaf (Dalaran 36.5, 34)",
            } },
        },
    },
    [26764] = {
        p = "Tailoring",
        skill = 310,
        item = 21849,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26765] = {
        p = "Tailoring",
        skill = 310,
        item = 21850,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26770] = {
        p = "Tailoring",
        skill = 320,
        item = 21851,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26771] = {
        p = "Tailoring",
        skill = 325,
        item = 21852,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26772] = {
        p = "Tailoring",
        skill = 335,
        item = 21853,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26773] = {
        p = "Tailoring",
        skill = 340,
        item = 21854,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eiin (Shattrath City 66.2, 68.7)",
                "Neii (The Exodar 64.5, 68.5)",
                "Deynna (Silvermoon City 55.8, 51)",
            } },
        },
    },
    [26774] = {
        p = "Tailoring",
        skill = 345,
        item = 21855,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eiin (Shattrath City 66.2, 68.7)",
                "Neii (The Exodar 64.5, 68.5)",
                "Deynna (Silvermoon City 55.8, 51)",
            } },
        },
    },
    [26775] = {
        p = "Tailoring",
        skill = 340,
        item = 21859,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Zurai (Zangarmarsh 85.2, 54.7)",
                "Muheru the Weaver (Zangarmarsh 40.6, 28.2)",
            } },
        },
    },
    [26776] = {
        p = "Tailoring",
        skill = 350,
        item = 21860,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Zurai (Zangarmarsh 85.2, 54.7)",
                "Muheru the Weaver (Zangarmarsh 40.6, 28.2)",
            } },
        },
    },
    [26777] = {
        p = "Tailoring",
        skill = 360,
        item = 21861,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Arrond (Shadowmoon Valley 55.9, 58.2)",
            } },
        },
    },
    [26778] = {
        p = "Tailoring",
        skill = 360,
        item = 21862,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Arrond (Shadowmoon Valley 55.9, 58.2)",
            } },
        },
    },
    [26779] = {
        p = "Tailoring",
        skill = 355,
        item = 21863,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Mathar G'ochar (Nagrand 57, 39.6)",
                "Borto (Nagrand 53.3, 71.9)",
            } },
        },
    },
    [26780] = {
        p = "Tailoring",
        skill = 365,
        item = 21864,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Phantom Attendant (Karazhan)",
            } },
        },
    },
    [26781] = {
        p = "Tailoring",
        skill = 375,
        item = 21865,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Phantom Valet (Karazhan)",
            } },
        },
    },
    [26782] = {
        p = "Tailoring",
        skill = 350,
        item = 21866,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Arcatraz Sentinel (The Arcatraz)",
            } },
        },
    },
    [26783] = {
        p = "Tailoring",
        skill = 360,
        item = 21867,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Sunseeker Astromage (The Mechanar)",
            } },
        },
    },
    [26784] = {
        p = "Tailoring",
        skill = 370,
        item = 21868,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Pathaleon the Calculator (The Mechanar)",
            } },
        },
    },
    [26872] = {
        p = "Jewelcrafting",
        skill = 200,
        item = 21748,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26873] = {
        p = "Jewelcrafting",
        skill = 200,
        item = 21756,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26874] = {
        p = "Jewelcrafting",
        skill = 210,
        item = 20964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26875] = {
        p = "Jewelcrafting",
        skill = 215,
        item = 21758,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Banalash (Swamp of Sorrows 44.7, 56.7)",
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
            } },
        },
    },
    [26876] = {
        p = "Jewelcrafting",
        skill = 220,
        item = 21755,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26878] = {
        p = "Jewelcrafting",
        skill = 225,
        item = 20969,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Hammon Karwn (Arathi Highlands 46.5, 47.3)",
                "Keena (Arathi Highlands 74, 32.7)",
            } },
        },
    },
    [26880] = {
        p = "Jewelcrafting",
        skill = 225,
        item = 21752,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26881] = {
        p = "Jewelcrafting",
        skill = 225,
        item = 21760,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Nerrist (Stranglethorn Vale 32.7, 29.2)",
                "Helenia Olden (Dustwallow Marsh 66.4, 51.5)",
            } },
        },
    },
    [26882] = {
        p = "Jewelcrafting",
        skill = 235,
        item = 21763,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26883] = {
        p = "Jewelcrafting",
        skill = 235,
        item = 21764,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26885] = {
        p = "Jewelcrafting",
        skill = 240,
        item = 21765,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26887] = {
        p = "Jewelcrafting",
        skill = 245,
        item = 21754,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26896] = {
        p = "Jewelcrafting",
        skill = 250,
        item = 21753,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26897] = {
        p = "Jewelcrafting",
        skill = 250,
        item = 21766,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Arred (The Exodar 45, 26)",
                "Burbik Gearspanner (Ironforge 46.5, 27.1)",
                "Gelanthis (Silvermoon City 90.8, 73.6)",
                "Shadi Mistrunner (Thunder Bluff 40.4, 63.6)",
            } },
        },
    },
    [26900] = {
        p = "Jewelcrafting",
        skill = 260,
        item = 21769,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26902] = {
        p = "Jewelcrafting",
        skill = 260,
        item = 21767,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26903] = {
        p = "Jewelcrafting",
        skill = 275,
        item = 21768,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26906] = {
        p = "Jewelcrafting",
        skill = 275,
        item = 21774,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [26907] = {
        p = "Jewelcrafting",
        skill = 280,
        item = 21775,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26908] = {
        p = "Jewelcrafting",
        skill = 280,
        item = 21790,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26909] = {
        p = "Jewelcrafting",
        skill = 285,
        item = 21777,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [26910] = {
        p = "Jewelcrafting",
        skill = 285,
        item = 21778,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Jase Farlane (Eastern Plaguelands 74.8, 51.8)",
            } },
        },
    },
    [26911] = {
        p = "Jewelcrafting",
        skill = 290,
        item = 21791,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26912] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 21784,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Quartermaster Zigris (Blackrock Spire)",
            } },
        },
    },
    [26914] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 21789,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Golem Lord Argelmach (Blackrock Depths)",
            } },
        },
    },
    [26915] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 21792,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Qia (Winterspring 61.2, 37.2)",
            } },
        },
    },
    [26916] = {
        p = "Jewelcrafting",
        skill = 310,
        item = 21779,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26925] = {
        p = "Jewelcrafting",
        skill = 1,
        item = 21931,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [26926] = {
        p = "Jewelcrafting",
        skill = 5,
        item = 21932,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26927] = {
        p = "Jewelcrafting",
        skill = 50,
        item = 21933,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [26928] = {
        p = "Jewelcrafting",
        skill = 30,
        item = 21934,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27032] = {
        p = "First Aid",
        skill = 300,
        item = 21990,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27033] = {
        p = "First Aid",
        skill = 330,
        item = 21991,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27585] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22197,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Vargus (Silithus 51.2, 38.8)",
            } },
        },
    },
    [27586] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22198,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Lieutenant General Andorov (Ruins of Ahn'Qiraj)",
            } },
        },
    },
    [27587] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22196,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "The Prophet Skeram (Temple of Ahn'Qiraj)",
            } },
        },
    },
    [27588] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22195,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Vargus (Silithus 51.2, 38.8)",
            } },
        },
    },
    [27589] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22194,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Moam (Ruins of Ahn'Qiraj)",
            } },
        },
    },
    [27590] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22191,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Exalted: Lieutenant General Andorov (Ruins of Ahn'Qiraj)",
            } },
        },
    },
    [27658] = {
        p = "Tailoring",
        skill = 225,
        item = 22246,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Ildine Sorrowspear (Dalaran 39.1, 41.5)",
                "Kania (Silithus 52, 39.6)",
                "Thaddeus Webb (Undercity 62, 60.7)",
                "Erilia (Eversong Woods 55.5, 54)",
                "Lilly (Silverpine Forest 43.1, 50.8)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Bradley Towns (Dragonblight 76.9, 62.2)",
                "Yurial Soulwater (Shattrath City 43.5, 96.9)",
                "Nata Dawnstrider (Thunder Bluff 46.5, 38.8)",
                "Leo Sarn (Silverpine Forest 53.9, 82.3)",
                "Alys Vol'tyr (Dragonblight 36.3, 46.5)",
                "Johan Barnes (Hellfire Peninsula 53.7, 66.1)",
                "Vaean (Darnassus 58.5, 14.4)",
                "Tilli Thistlefuzz (Ironforge 60.7, 44.2)",
                "Lyna (Silvermoon City 69.1, 24.4)",
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Kithas (Orgrimmar 53.7, 38)",
                "Jessara Cordell (Stormwind City 53, 74.2)",
                "Modoru (Dragonblight 28.9, 55.9)",
                "Librarian Erickson (Borean Tundra 46.7, 32.5)",
                "Dealer Malij (Netherstorm 44.2, 34)",
                "Felannia (Hellfire Peninsula 52.3, 36.1)",
                "Asarnan (Netherstorm 44.2, 33.7)",
            } },
        },
    },
    [27659] = {
        p = "Tailoring",
        skill = 275,
        item = 22248,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Kania (Silithus 52, 39.6)",
            } },
        },
    },
    [27660] = {
        p = "Tailoring",
        skill = 300,
        item = 22249,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Magister Kalendris (Dire Maul 59.04, 48.82)",
            } },
        },
    },
    [27724] = {
        p = "Tailoring",
        skill = 275,
        item = 22251,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [27725] = {
        p = "Tailoring",
        skill = 300,
        item = 22252,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [27829] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22385,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [27830] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22384,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [27832] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22383,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Kalimdor",
                "Eastern Kingdoms",
            } },
        },
    },
    [27837] = {
        p = "Enchanting",
        skill = 290,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Timbermaw Hold - Friendly: Meilosh (Felwood 65.7, 2.9)",
            } },
        },
    },
    [27899] = {
        p = "Enchanting",
        skill = 305,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27905] = {
        p = "Enchanting",
        skill = 315,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27906] = {
        p = "Enchanting",
        skill = 320,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Ethereum Nullifier (Netherstorm 66, 49.5)",
                "Ethereum Jailor (Netherstorm 58.8, 35.6)",
            } },
        },
    },
    [27911] = {
        p = "Enchanting",
        skill = 325,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Friendly: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Friendly: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [27913] = {
        p = "Enchanting",
        skill = 335,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [27914] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Coilfang Oracle (The Steamvault)",
            } },
        },
    },
    [27917] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Bloodmaul Geomancer (Blade's Edge Mountains 45, 68.5)",
            } },
        },
    },
    [27920] = {
        p = "Enchanting",
        skill = 360,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Ythyar (Karazhan)",
            } },
        },
    },
    [27924] = {
        p = "Enchanting",
        skill = 360,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Honored: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [27926] = {
        p = "Enchanting",
        skill = 370,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [27927] = {
        p = "Enchanting",
        skill = 375,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Honored: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [27944] = {
        p = "Enchanting",
        skill = 310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27945] = {
        p = "Enchanting",
        skill = 325,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Aged Dalaran Wizard (Old Hillsbrad Foothills)",
            } },
        },
    },
    [27946] = {
        p = "Enchanting",
        skill = 340,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [27947] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [27948] = {
        p = "Enchanting",
        skill = 305,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [27950] = {
        p = "Enchanting",
        skill = 320,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Ethereal Priest (Mana-Tombs)",
            } },
        },
    },
    [27951] = {
        p = "Enchanting",
        skill = 340,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Raging Skeleton (Auchenai Crypts)",
            } },
        },
    },
    [27954] = {
        p = "Enchanting",
        skill = 370,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Phantom Stagehand (Karazhan)",
            } },
        },
    },
    [27957] = {
        p = "Enchanting",
        skill = 315,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27958] = {
        p = "Enchanting",
        skill = 350,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27960] = {
        p = "Enchanting",
        skill = 345,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Revered: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Revered: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [27961] = {
        p = "Enchanting",
        skill = 310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [27962] = {
        p = "Enchanting",
        skill = 330,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [27967] = {
        p = "Enchanting",
        skill = 340,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [27968] = {
        p = "Enchanting",
        skill = 340,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Sunfury Researcher (Netherstorm 48.2, 82.5)",
            } },
        },
    },
    [27971] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Shattered Hand Centurion (The Shattered Halls)",
            } },
        },
    },
    [27972] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [27975] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Bash'ir Spell-Thief (Blade's Edge Mountains 51, 16.5)",
            } },
        },
    },
    [27977] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Eredar Deathbringer (The Arcatraz)",
            } },
        },
    },
    [27981] = {
        p = "Enchanting",
        skill = 375,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Shade of Aran (Karazhan)",
            } },
        },
    },
    [27982] = {
        p = "Enchanting",
        skill = 375,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Terestian Illhoof (Karazhan)",
            } },
        },
    },
    [27984] = {
        p = "Enchanting",
        skill = 375,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Moroes (Karazhan)",
            } },
        },
    },
    [28003] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28004] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28016] = {
        p = "Enchanting",
        skill = 310,
        item = 22521,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Lyna (Silvermoon City 69.1, 24.4)",
            } },
        },
    },
    [28019] = {
        p = "Enchanting",
        skill = 340,
        item = 22522,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Lyna (Silvermoon City 69.1, 24.4)",
            } },
        },
    },
    [28022] = {
        p = "Enchanting",
        skill = 335,
        item = 22449,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Madame Ruby (Shattrath City 63.1, 69.3)",
                "Egomis (The Exodar 39.1, 39.4)",
                "Lyna (Silvermoon City 69.1, 24.4)",
            } },
        },
    },
    [28027] = {
        p = "Enchanting",
        skill = 325,
        item = 22460,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28028] = {
        p = "Enchanting",
        skill = 350,
        item = 22459,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28205] = {
        p = "Tailoring",
        skill = 300,
        item = 22654,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28207] = {
        p = "Tailoring",
        skill = 300,
        item = 22652,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Exalted: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28208] = {
        p = "Tailoring",
        skill = 300,
        item = 22658,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Honored: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28209] = {
        p = "Tailoring",
        skill = 300,
        item = 22655,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28210] = {
        p = "Tailoring",
        skill = 300,
        item = 22660,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [28219] = {
        p = "Leatherworking",
        skill = 300,
        item = 22661,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Exalted: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28220] = {
        p = "Leatherworking",
        skill = 300,
        item = 22662,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28221] = {
        p = "Leatherworking",
        skill = 300,
        item = 22663,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28222] = {
        p = "Leatherworking",
        skill = 300,
        item = 22664,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Exalted: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28223] = {
        p = "Leatherworking",
        skill = 300,
        item = 22666,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28224] = {
        p = "Leatherworking",
        skill = 300,
        item = 22665,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28242] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22669,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Exalted: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28243] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22670,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28244] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22671,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Dawn - Revered: Master Craftsman Omarion (BZ[\"Naxxramas\"]..\" (40)\")",
            } },
            { t = "Special", d = {
                "Removed from the game when Naxx 40 was taken out.",
            } },
        },
    },
    [28267] = {
        p = "Cooking",
        skill = 60,
        item = 22645,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Master Chef Mouldier (Ghostlands 48.3, 30.9)",
                "Fazu (Bloodmyst Isle 53.5, 56.5)",
            } },
            { t = "Quest", d = {
                "Quest #9171 (Ghostlands 48.3, 30.9)",
            } },
        },
    },
    [28327] = {
        p = "Engineering",
        skill = 275,
        item = 22728,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Sovik (Orgrimmar 75.6, 25.2)",
                "Gearcutter Cogspinner (Ironforge 68, 43.1)",
            } },
            { t = "Quest", d = {
                "Quest #9249 (Darkmoon Faire)",
            } },
        },
    },
    [28461] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22762,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Vargus (Silithus 51.2, 38.8)",
            } },
        },
    },
    [28462] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22763,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Vargus (Silithus 51.2, 38.8)",
            } },
        },
    },
    [28463] = {
        p = "Blacksmithing",
        skill = 300,
        item = 22764,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Vargus (Silithus 51.2, 38.8)",
            } },
        },
    },
    [28472] = {
        p = "Leatherworking",
        skill = 300,
        item = 22759,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [28473] = {
        p = "Leatherworking",
        skill = 300,
        item = 22760,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [28474] = {
        p = "Leatherworking",
        skill = 300,
        item = 22761,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Aendel Windspear (Silithus 62.6, 49.8)",
            } },
        },
    },
    [28480] = {
        p = "Tailoring",
        skill = 300,
        item = 22756,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Revered: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [28481] = {
        p = "Tailoring",
        skill = 300,
        item = 22757,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Honored: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [28482] = {
        p = "Tailoring",
        skill = 300,
        item = 22758,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Circle - Friendly: Mishta (Silithus 49.9, 36.5)",
            } },
        },
    },
    [28543] = {
        p = "Alchemy",
        skill = 305,
        item = 22823,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Alchemist Gribble (Hellfire Peninsula 53.8, 65.8)",
                "Altaa (The Exodar 27.5, 62.1)",
                "Melaris (Silvermoon City 66, 20.6)",
                "Apothecary Antonivich (Hellfire Peninsula 52.4, 36.5)",
            } },
        },
    },
    [28544] = {
        p = "Alchemy",
        skill = 305,
        item = 22824,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28545] = {
        p = "Alchemy",
        skill = 310,
        item = 22825,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28546] = {
        p = "Alchemy",
        skill = 315,
        item = 22826,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Seer Janidi (Zangarmarsh 32.4, 51.9)",
                "Leeli Longhaggle (Terokkar Forest 57.7, 53.4)",
            } },
        },
    },
    [28549] = {
        p = "Alchemy",
        skill = 320,
        item = 22827,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Haalrun (Zangarmarsh 67.8, 48)",
                "Seer Janidi (Zangarmarsh 32.4, 51.9)",
            } },
        },
    },
    [28550] = {
        p = "Alchemy",
        skill = 320,
        item = 22828,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28551] = {
        p = "Alchemy",
        skill = 325,
        item = 22829,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28552] = {
        p = "Alchemy",
        skill = 325,
        item = 22830,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28553] = {
        p = "Alchemy",
        skill = 330,
        item = 22831,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Honored: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Honored: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [28554] = {
        p = "Alchemy",
        skill = 335,
        item = 22871,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Sporeggar - Exalted: Mycah (Zangarmarsh 17.9, 51.2)",
            } },
        },
    },
    [28555] = {
        p = "Alchemy",
        skill = 340,
        item = 22832,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Haalrun (Zangarmarsh 67.8, 48)",
                "Daga Ramba (Blade's Edge Mountains 51.1, 57.7)",
            } },
        },
    },
    [28556] = {
        p = "Alchemy",
        skill = 345,
        item = 22833,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [28557] = {
        p = "Alchemy",
        skill = 345,
        item = 22834,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Haalrun (Zangarmarsh 67.8, 48)",
                "Daga Ramba (Blade's Edge Mountains 51.1, 57.7)",
            } },
        },
    },
    [28558] = {
        p = "Alchemy",
        skill = 350,
        item = 22835,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Revered: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [28562] = {
        p = "Alchemy",
        skill = 350,
        item = 22836,
        q = "Common",
        sources = {
            { t = "Limited Vendor", d = {
                "Leeli Longhaggle (Terokkar Forest 57.7, 53.4)",
                "Daga Ramba (Blade's Edge Mountains 51.1, 57.7)",
            } },
        },
    },
    [28563] = {
        p = "Alchemy",
        skill = 350,
        item = 22837,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28564] = {
        p = "Alchemy",
        skill = 350,
        item = 22838,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [28565] = {
        p = "Alchemy",
        skill = 350,
        item = 22839,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28566] = {
        p = "Alchemy",
        skill = 350,
        item = 21884,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [28567] = {
        p = "Alchemy",
        skill = 350,
        item = 21885,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Sporeggar - Revered: Mycah (Zangarmarsh 17.9, 51.2)",
            } },
        },
    },
    [28568] = {
        p = "Alchemy",
        skill = 350,
        item = 22452,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Revered: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [28569] = {
        p = "Alchemy",
        skill = 350,
        item = 22451,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Revered: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [28570] = {
        p = "Alchemy",
        skill = 355,
        item = 22840,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28571] = {
        p = "Alchemy",
        skill = 360,
        item = 22841,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Sunseeker Astromage (The Mechanar)",
                "Nethermancer Sepethrea (The Mechanar)",
            } },
        },
    },
    [28572] = {
        p = "Alchemy",
        skill = 360,
        item = 22842,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Nexus-Prince Shaffar (Mana-Tombs)",
            } },
        },
    },
    [28573] = {
        p = "Alchemy",
        skill = 360,
        item = 22844,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [28575] = {
        p = "Alchemy",
        skill = 360,
        item = 22845,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Vir'aani Arcanist (Nagrand 40.5, 69.6)",
            } },
        },
    },
    [28576] = {
        p = "Alchemy",
        skill = 360,
        item = 22846,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Shadow Council Warlock (Shadowmoon Valley 22.9, 38.2)",
            } },
        },
    },
    [28577] = {
        p = "Alchemy",
        skill = 360,
        item = 22847,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Abyssal Flamebringer (Blade's Edge Mountains 30, 81)",
            } },
        },
    },
    [28578] = {
        p = "Alchemy",
        skill = 365,
        item = 22848,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28579] = {
        p = "Alchemy",
        skill = 365,
        item = 22849,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Captain Skarloc (Old Hillsbrad Foothills)",
            } },
        },
    },
    [28580] = {
        p = "Alchemy",
        skill = 375,
        item = 21885,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28581] = {
        p = "Alchemy",
        skill = 375,
        item = 22456,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28582] = {
        p = "Alchemy",
        skill = 375,
        item = 21884,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28583] = {
        p = "Alchemy",
        skill = 375,
        item = 22457,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28584] = {
        p = "Alchemy",
        skill = 375,
        item = 22452,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28585] = {
        p = "Alchemy",
        skill = 375,
        item = 21886,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28586] = {
        p = "Alchemy",
        skill = 375,
        item = 22850,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28587] = {
        p = "Alchemy",
        skill = 375,
        item = 22851,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making elixirs or flasks using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28588] = {
        p = "Alchemy",
        skill = 375,
        item = 22853,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making elixirs or flasks using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28589] = {
        p = "Alchemy",
        skill = 375,
        item = 22854,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making elixirs or flasks using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28590] = {
        p = "Alchemy",
        skill = 375,
        item = 22861,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making elixirs or flasks using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28591] = {
        p = "Alchemy",
        skill = 375,
        item = 22866,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by making elixirs or flasks using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [28903] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23094,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28905] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23095,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28906] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23096,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Friendly: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [28907] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23097,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [28910] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23098,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28912] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23099,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Friendly: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Friendly: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [28914] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28915] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23101,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Friendly: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [28916] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23103,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28917] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23104,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28918] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23105,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Friendly: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Friendly: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [28924] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23106,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Honored: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [28925] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23108,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28927] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23109,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [28933] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23110,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Friendly: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Friendly: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [28936] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23111,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28938] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23113,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28944] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23114,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Friendly: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [28947] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23115,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [28948] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23116,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28950] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 23118,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28953] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 23119,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [28955] = {
        p = "Jewelcrafting",
        skill = 315,
        item = 23120,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [28957] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 23121,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [29356] = {
        p = "Mining",
        skill = 275,
        item = 23445,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29358] = {
        p = "Mining",
        skill = 325,
        item = 23446,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29359] = {
        p = "Mining",
        skill = 350,
        item = 23447,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29360] = {
        p = "Mining",
        skill = 350,
        item = 23448,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29361] = {
        p = "Mining",
        skill = 375,
        item = 23449,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29545] = {
        p = "Blacksmithing",
        skill = 300,
        item = 23482,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29547] = {
        p = "Blacksmithing",
        skill = 305,
        item = 23484,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29548] = {
        p = "Blacksmithing",
        skill = 315,
        item = 23487,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29549] = {
        p = "Blacksmithing",
        skill = 315,
        item = 23488,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29550] = {
        p = "Blacksmithing",
        skill = 325,
        item = 23489,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29551] = {
        p = "Blacksmithing",
        skill = 300,
        item = 23493,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29552] = {
        p = "Blacksmithing",
        skill = 310,
        item = 23491,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29553] = {
        p = "Blacksmithing",
        skill = 315,
        item = 23494,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29556] = {
        p = "Blacksmithing",
        skill = 320,
        item = 23490,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29557] = {
        p = "Blacksmithing",
        skill = 310,
        item = 23497,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29558] = {
        p = "Blacksmithing",
        skill = 315,
        item = 23498,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29565] = {
        p = "Blacksmithing",
        skill = 320,
        item = 23499,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29566] = {
        p = "Blacksmithing",
        skill = 325,
        item = 23502,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eriden (Silvermoon City 79.5, 36.2)",
                "Arras (The Exodar 60, 89.5)",
                "Aaron Hollman (Shattrath City 63.1, 71.1)",
            } },
        },
    },
    [29568] = {
        p = "Blacksmithing",
        skill = 330,
        item = 23503,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eriden (Silvermoon City 79.5, 36.2)",
                "Arras (The Exodar 60, 89.5)",
                "Aaron Hollman (Shattrath City 63.1, 71.1)",
            } },
        },
    },
    [29569] = {
        p = "Blacksmithing",
        skill = 330,
        item = 23504,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eriden (Silvermoon City 79.5, 36.2)",
                "Arras (The Exodar 60, 89.5)",
                "Aaron Hollman (Shattrath City 63.1, 71.1)",
            } },
        },
    },
    [29571] = {
        p = "Blacksmithing",
        skill = 335,
        item = 23505,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Eriden (Silvermoon City 79.5, 36.2)",
                "Arras (The Exodar 60, 89.5)",
                "Aaron Hollman (Shattrath City 63.1, 71.1)",
            } },
        },
    },
    [29603] = {
        p = "Blacksmithing",
        skill = 335,
        item = 23506,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Krek Cragcrush (Shadowmoon Valley 28.9, 30.8)",
                "Loolruna (Zangarmarsh 68.5, 50.1)",
            } },
        },
    },
    [29605] = {
        p = "Blacksmithing",
        skill = 335,
        item = 23508,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Krek Cragcrush (Shadowmoon Valley 28.9, 30.8)",
                "Loolruna (Zangarmarsh 68.5, 50.1)",
            } },
        },
    },
    [29606] = {
        p = "Blacksmithing",
        skill = 340,
        item = 23507,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Krek Cragcrush (Shadowmoon Valley 28.9, 30.8)",
                "Loolruna (Zangarmarsh 68.5, 50.1)",
            } },
        },
    },
    [29608] = {
        p = "Blacksmithing",
        skill = 355,
        item = 23510,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Friendly: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [29610] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23509,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [29611] = {
        p = "Blacksmithing",
        skill = 355,
        item = 23511,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Honored: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [29613] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23512,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Exalted: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [29614] = {
        p = "Blacksmithing",
        skill = 350,
        item = 23515,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Friendly: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [29615] = {
        p = "Blacksmithing",
        skill = 355,
        item = 23516,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Exalted: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [29616] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23514,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [29617] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23513,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Revered: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [29619] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23517,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Auchenai Monk (Auchenai Crypts)",
            } },
        },
    },
    [29620] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23518,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Unchained Doombringer (The Arcatraz)",
            } },
        },
    },
    [29621] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23519,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cabal Fanatic (Shadow Labyrinth)",
            } },
        },
    },
    [29622] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23532,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29628] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23524,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Murkblood Raider (Nagrand 31.5, 43.5)",
            } },
        },
    },
    [29629] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23523,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Deathforge Guardian (Shadowmoon Valley 39, 47)",
            } },
        },
    },
    [29630] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23525,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Disembodied Protector (Netherstorm 31.8, 52.7)",
            } },
        },
    },
    [29642] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23520,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Boulderfist Warrior (Nagrand 51, 57)",
            } },
        },
    },
    [29643] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23521,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Anger Guard (Blade's Edge Mountains 72, 40.5)",
            } },
        },
    },
    [29645] = {
        p = "Blacksmithing",
        skill = 370,
        item = 23522,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Crazed Murkblood Foreman (Shadowmoon Valley 72.3, 90)",
                "Crazed Murkblood Miner (Shadowmoon Valley 73.5, 88.5)",
                "Ashtongue Warrior (Shadowmoon Valley 57, 36)",
            } },
        },
    },
    [29648] = {
        p = "Blacksmithing",
        skill = 370,
        item = 23526,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Nexus Stalker (Mana-Tombs)",
            } },
        },
    },
    [29649] = {
        p = "Blacksmithing",
        skill = 370,
        item = 23527,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "High Botanist Freywinn (The Botanica)",
            } },
        },
    },
    [29654] = {
        p = "Blacksmithing",
        skill = 300,
        item = 23528,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29656] = {
        p = "Blacksmithing",
        skill = 350,
        item = 23529,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [29657] = {
        p = "Blacksmithing",
        skill = 360,
        item = 23530,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Exalted: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Exalted: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [29658] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23531,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29662] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23533,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29663] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23534,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29664] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23535,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29668] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23536,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29669] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23537,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29671] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23538,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29672] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23539,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29686] = {
        p = "Mining",
        skill = 375,
        item = 23573,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [29688] = {
        p = "Alchemy",
        skill = 350,
        item = 23571,
        q = "Uncommon",
        sources = {
            { t = "Limited Vendor", d = {
                "Altaa (The Exodar 27.5, 62.1)",
                "Melaris (Silvermoon City 66, 20.6)",
                "Skreah (Shattrath City 46, 20.1)",
            } },
        },
    },
    [29692] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23540,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29693] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23541,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29694] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23542,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29695] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23543,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29696] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23544,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29697] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23546,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29698] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23554,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29699] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23555,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29700] = {
        p = "Blacksmithing",
        skill = 365,
        item = 23556,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [29728] = {
        p = "Blacksmithing",
        skill = 340,
        item = 23575,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rohok (Hellfire Peninsula 53.2, 38.2)",
                "Mari Stonehand (Shadowmoon Valley 36.8, 55.1)",
            } },
        },
    },
    [29729] = {
        p = "Blacksmithing",
        skill = 375,
        item = 23576,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Sunfury Bloodwarder (Netherstorm 27, 72)",
            } },
        },
    },
    [30303] = {
        p = "Engineering",
        skill = 300,
        item = 23781,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30304] = {
        p = "Engineering",
        skill = 300,
        item = 23782,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30305] = {
        p = "Engineering",
        skill = 300,
        item = 23783,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30306] = {
        p = "Engineering",
        skill = 325,
        item = 23784,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30307] = {
        p = "Engineering",
        skill = 340,
        item = 23785,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30308] = {
        p = "Engineering",
        skill = 340,
        item = 23786,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30309] = {
        p = "Engineering",
        skill = 340,
        item = 23787,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30310] = {
        p = "Engineering",
        skill = 300,
        item = 23736,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30311] = {
        p = "Engineering",
        skill = 325,
        item = 23737,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30312] = {
        p = "Engineering",
        skill = 320,
        item = 23742,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30313] = {
        p = "Engineering",
        skill = 350,
        item = 23746,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Feera (The Exodar 54, 90.5)",
                "Viggz Shinesparked (Shattrath City 64.9, 69.1)",
                "Yatheon (Silvermoon City 76, 37.7)",
            } },
        },
    },
    [30314] = {
        p = "Engineering",
        skill = 360,
        item = 23747,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Doomforge Engineer (Blade's Edge Mountains 75.1, 39.8)",
            } },
        },
    },
    [30315] = {
        p = "Engineering",
        skill = 375,
        item = 23748,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [30316] = {
        p = "Engineering",
        skill = 340,
        item = 23758,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lebowski (Hellfire Peninsula 55.7, 65.5)",
                "Mixie Farshot (Hellfire Peninsula 61.1, 81.5)",
            } },
        },
    },
    [30317] = {
        p = "Engineering",
        skill = 340,
        item = 23761,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [30318] = {
        p = "Engineering",
        skill = 350,
        item = 23762,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Lebowski (Hellfire Peninsula 55.7, 65.5)",
                "Captured Gnome (Zangarmarsh 32.5, 48.1)",
            } },
        },
    },
    [30325] = {
        p = "Engineering",
        skill = 360,
        item = 23763,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Mo'arg Weaponsmith (Shadowmoon Valley 25.5, 31.5)",
            } },
        },
    },
    [30329] = {
        p = "Engineering",
        skill = 335,
        item = 23764,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Daggle Ironshaper (Shadowmoon Valley 36.8, 54.4)",
                "Mixie Farshot (Hellfire Peninsula 61.1, 81.5)",
            } },
        },
    },
    [30332] = {
        p = "Engineering",
        skill = 360,
        item = 23765,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Sunfury Bowman (Netherstorm 61.5, 67.5)",
            } },
        },
    },
    [30334] = {
        p = "Engineering",
        skill = 375,
        item = 23766,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Attumen the Huntsman (Karazhan)",
            } },
        },
    },
    [30337] = {
        p = "Engineering",
        skill = 325,
        item = 23767,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [30341] = {
        p = "Engineering",
        skill = 335,
        item = 23768,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Feera (The Exodar 54, 90.5)",
                "Wind Trader Lathrai (Shattrath City 72.3, 31)",
                "Captured Gnome (Zangarmarsh 32.5, 48.1)",
                "Yatheon (Silvermoon City 76, 37.7)",
            } },
        },
    },
    [30344] = {
        p = "Engineering",
        skill = 335,
        item = 23771,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Friendly: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [30346] = {
        p = "Engineering",
        skill = 310,
        item = 23772,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30347] = {
        p = "Engineering",
        skill = 335,
        item = 34504,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Feera (The Exodar 54, 90.5)",
                "Yatheon (Silvermoon City 76, 37.7)",
                "Wind Trader Lathrai (Shattrath City 72.3, 31)",
            } },
        },
    },
    [30348] = {
        p = "Engineering",
        skill = 325,
        item = 23774,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Feera (The Exodar 54, 90.5)",
                "Yatheon (Silvermoon City 76, 37.7)",
                "Wind Trader Lathrai (Shattrath City 72.3, 31)",
            } },
        },
    },
    [30349] = {
        p = "Engineering",
        skill = 405,
        item = 23775,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Bryan Landers (Dalaran 39.1, 26.5)",
            } },
        },
    },
    [30547] = {
        p = "Engineering",
        skill = 350,
        item = 23819,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Revered: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [30548] = {
        p = "Engineering",
        skill = 305,
        item = 23821,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #9635 (Zangarmarsh 33.7, 50.2)",
                "Quest #9636 (Zangarmarsh 68.6, 50.2)",
            } },
        },
    },
    [30551] = {
        p = "Engineering",
        skill = 330,
        item = 33092,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [30552] = {
        p = "Engineering",
        skill = 345,
        item = 33093,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [30556] = {
        p = "Engineering",
        skill = 355,
        item = 23824,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Mekgineer Steamrigger (The Steamvault)",
            } },
        },
    },
    [30558] = {
        p = "Engineering",
        skill = 325,
        item = 23826,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30560] = {
        p = "Engineering",
        skill = 340,
        item = 23827,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30563] = {
        p = "Engineering",
        skill = 350,
        item = 23836,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30565] = {
        p = "Engineering",
        skill = 375,
        item = 23838,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30566] = {
        p = "Engineering",
        skill = 375,
        item = 23839,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30568] = {
        p = "Engineering",
        skill = 325,
        item = 23841,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30569] = {
        p = "Engineering",
        skill = 340,
        item = 23835,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30570] = {
        p = "Engineering",
        skill = 350,
        item = 23825,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30574] = {
        p = "Engineering",
        skill = 375,
        item = 23828,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [30575] = {
        p = "Engineering",
        skill = 375,
        item = 23829,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31048] = {
        p = "Jewelcrafting",
        skill = 310,
        item = 24074,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31049] = {
        p = "Jewelcrafting",
        skill = 310,
        item = 24075,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31050] = {
        p = "Jewelcrafting",
        skill = 320,
        item = 24076,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31051] = {
        p = "Jewelcrafting",
        skill = 335,
        item = 24077,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31052] = {
        p = "Jewelcrafting",
        skill = 335,
        item = 24078,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [31053] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24079,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Dark Conclave Shadowmancer (Shadowmoon Valley 37.5, 29)",
            } },
        },
    },
    [31054] = {
        p = "Jewelcrafting",
        skill = 355,
        item = 24080,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Coilfang Sorceress (The Steamvault)",
            } },
        },
    },
    [31055] = {
        p = "Jewelcrafting",
        skill = 355,
        item = 24082,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Darkweaver Syth (Sethekk Halls)",
            } },
        },
    },
    [31056] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24085,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Vekh'nir Dreadhawk (Blade's Edge Mountains 78, 74.3)",
            } },
        },
    },
    [31057] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 24086,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Mageslayer (Netherstorm 55.5, 85.5)",
            } },
        },
    },
    [31058] = {
        p = "Jewelcrafting",
        skill = 345,
        item = 24087,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31060] = {
        p = "Jewelcrafting",
        skill = 355,
        item = 24088,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31061] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 24089,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31062] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24092,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Revered: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [31063] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24093,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Revered: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [31064] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24095,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [31065] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24097,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Revered: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [31066] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24098,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Revered: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [31067] = {
        p = "Jewelcrafting",
        skill = 355,
        item = 24106,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31068] = {
        p = "Jewelcrafting",
        skill = 355,
        item = 24110,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31070] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24114,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31071] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 24116,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31072] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 24117,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31076] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 24121,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31077] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24122,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Sunseeker Botanist (The Botanica)",
            } },
        },
    },
    [31078] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24123,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Epoch Hunter (Old Hillsbrad Foothills)",
            } },
        },
    },
    [31079] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24124,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Revered: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [31080] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24125,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Revered: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Revered: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [31081] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24126,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Revered: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [31082] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24127,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [31083] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 24128,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Revered: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [31084] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24027,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31085] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24028,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31087] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24029,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31088] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24030,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31089] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24031,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31090] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24032,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31091] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24036,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31092] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24033,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31094] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24037,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31095] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24039,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31096] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24047,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31097] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24048,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31098] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24051,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31099] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24050,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31100] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24052,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31101] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24053,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Coreiel (Nagrand 42.8, 42.6)",
                "Aldraan (Nagrand 42.9, 42.5)",
            } },
        },
    },
    [31102] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24054,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31103] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24055,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31104] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24056,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31105] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24057,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31106] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24058,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31107] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24059,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31108] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24060,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31109] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24061,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31110] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24062,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31111] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24066,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31112] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24065,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31113] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24067,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31149] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 24035,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31373] = {
        p = "Tailoring",
        skill = 350,
        item = 24271,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gidge Spellweaver (Shattrath City 66, 67.9)",
                "Lalla Brightweave (Dalaran 36.5, 33.5)",
            } },
        },
    },
    [31430] = {
        p = "Tailoring",
        skill = 335,
        item = 24273,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Honored: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [31431] = {
        p = "Tailoring",
        skill = 335,
        item = 24275,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [31432] = {
        p = "Tailoring",
        skill = 375,
        item = 24274,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Exalted: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [31433] = {
        p = "Tailoring",
        skill = 375,
        item = 24276,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Exalted: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [31434] = {
        p = "Tailoring",
        skill = 350,
        item = 24249,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [31435] = {
        p = "Tailoring",
        skill = 350,
        item = 24250,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31437] = {
        p = "Tailoring",
        skill = 350,
        item = 24251,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31438] = {
        p = "Tailoring",
        skill = 350,
        item = 24252,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31440] = {
        p = "Tailoring",
        skill = 350,
        item = 24253,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31441] = {
        p = "Tailoring",
        skill = 350,
        item = 24254,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31442] = {
        p = "Tailoring",
        skill = 365,
        item = 24255,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [31443] = {
        p = "Tailoring",
        skill = 365,
        item = 24256,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31444] = {
        p = "Tailoring",
        skill = 365,
        item = 24257,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31448] = {
        p = "Tailoring",
        skill = 365,
        item = 24258,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31449] = {
        p = "Tailoring",
        skill = 365,
        item = 24259,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31450] = {
        p = "Tailoring",
        skill = 365,
        item = 24260,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [31451] = {
        p = "Tailoring",
        skill = 375,
        item = 24261,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Dalliah the Doomsayer (The Arcatraz)",
            } },
        },
    },
    [31452] = {
        p = "Tailoring",
        skill = 375,
        item = 24262,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Murmur (Shadow Labyrinth)",
            } },
        },
    },
    [31453] = {
        p = "Tailoring",
        skill = 375,
        item = 24263,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Thorngrin the Tender (The Botanica)",
            } },
        },
    },
    [31454] = {
        p = "Tailoring",
        skill = 375,
        item = 24264,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Warp Splinter (The Botanica)",
            } },
        },
    },
    [31455] = {
        p = "Tailoring",
        skill = 375,
        item = 24266,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Grand Warlock Nethekurse (The Shattered Halls)",
            } },
        },
    },
    [31456] = {
        p = "Tailoring",
        skill = 375,
        item = 24267,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Warlord Kalithresh (The Steamvault)",
            } },
        },
    },
    [31459] = {
        p = "Tailoring",
        skill = 340,
        item = 24270,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [31460] = {
        p = "Tailoring",
        skill = 300,
        item = 24268,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32178] = {
        p = "Jewelcrafting",
        skill = 20,
        item = 25438,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32179] = {
        p = "Jewelcrafting",
        skill = 20,
        item = 25439,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32259] = {
        p = "Jewelcrafting",
        skill = 1,
        item = 25498,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [32284] = {
        p = "Blacksmithing",
        skill = 325,
        item = 23559,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32285] = {
        p = "Blacksmithing",
        skill = 350,
        item = 25521,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [32454] = {
        p = "Leatherworking",
        skill = 300,
        item = 21887,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32455] = {
        p = "Leatherworking",
        skill = 325,
        item = 23793,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Haferet (The Exodar 66, 74.6)",
                "Zaralda (Silvermoon City 84, 78.8)",
                "Cro Threadstrong (Shattrath City 66.1, 68.7)",
            } },
        },
    },
    [32456] = {
        p = "Leatherworking",
        skill = 300,
        item = 25650,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32457] = {
        p = "Leatherworking",
        skill = 325,
        item = 25651,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Revered: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [32458] = {
        p = "Leatherworking",
        skill = 325,
        item = 25652,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [32461] = {
        p = "Leatherworking",
        skill = 350,
        item = 25653,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Thomas Yance (Old Hillsbrad Foothills)",
            } },
        },
    },
    [32462] = {
        p = "Leatherworking",
        skill = 300,
        item = 25654,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32463] = {
        p = "Leatherworking",
        skill = 310,
        item = 25655,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32464] = {
        p = "Leatherworking",
        skill = 320,
        item = 25656,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32465] = {
        p = "Leatherworking",
        skill = 335,
        item = 25657,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32466] = {
        p = "Leatherworking",
        skill = 300,
        item = 25662,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32467] = {
        p = "Leatherworking",
        skill = 310,
        item = 25661,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32468] = {
        p = "Leatherworking",
        skill = 325,
        item = 25660,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32469] = {
        p = "Leatherworking",
        skill = 335,
        item = 25659,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32470] = {
        p = "Leatherworking",
        skill = 300,
        item = 25669,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32471] = {
        p = "Leatherworking",
        skill = 315,
        item = 25670,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32472] = {
        p = "Leatherworking",
        skill = 320,
        item = 25668,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32473] = {
        p = "Leatherworking",
        skill = 330,
        item = 25671,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32478] = {
        p = "Leatherworking",
        skill = 300,
        item = 25673,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32479] = {
        p = "Leatherworking",
        skill = 310,
        item = 25674,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32480] = {
        p = "Leatherworking",
        skill = 320,
        item = 25675,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32481] = {
        p = "Leatherworking",
        skill = 330,
        item = 25676,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32482] = {
        p = "Leatherworking",
        skill = 300,
        item = 25679,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zaralda (Silvermoon City 84, 78.8)",
                "Haferet (The Exodar 66, 74.6)",
            } },
        },
    },
    [32485] = {
        p = "Leatherworking",
        skill = 350,
        item = 25680,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Blackheart the Inciter (Shadow Labyrinth)",
            } },
        },
    },
    [32487] = {
        p = "Leatherworking",
        skill = 350,
        item = 25681,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Durnholde Rifleman (Old Hillsbrad Foothills)",
                "Don Carlos (Old Hillsbrad Foothills)",
            } },
        },
    },
    [32488] = {
        p = "Leatherworking",
        skill = 350,
        item = 25683,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Sethekk Ravenguard (Sethekk Halls)",
            } },
        },
    },
    [32489] = {
        p = "Leatherworking",
        skill = 350,
        item = 25682,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Rift Lord (The Black Morass)",
                "Rift Keeper (The Black Morass)",
            } },
        },
    },
    [32490] = {
        p = "Leatherworking",
        skill = 340,
        item = 25685,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Friendly: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Friendly: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [32493] = {
        p = "Leatherworking",
        skill = 350,
        item = 25686,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [32494] = {
        p = "Leatherworking",
        skill = 350,
        item = 25687,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Revered: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [32495] = {
        p = "Leatherworking",
        skill = 360,
        item = 25689,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [32496] = {
        p = "Leatherworking",
        skill = 355,
        item = 25690,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [32497] = {
        p = "Leatherworking",
        skill = 355,
        item = 25691,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Friendly: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [32498] = {
        p = "Leatherworking",
        skill = 350,
        item = 25695,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Friendly: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Friendly: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [32499] = {
        p = "Leatherworking",
        skill = 360,
        item = 25697,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Honored: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Honored: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [32500] = {
        p = "Leatherworking",
        skill = 360,
        item = 25696,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Honored: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Honored: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [32501] = {
        p = "Leatherworking",
        skill = 340,
        item = 25694,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Friendly: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [32502] = {
        p = "Leatherworking",
        skill = 340,
        item = 25692,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Honored: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [32503] = {
        p = "Leatherworking",
        skill = 350,
        item = 25693,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Revered: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [32655] = {
        p = "Blacksmithing",
        skill = 300,
        item = 25843,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32656] = {
        p = "Blacksmithing",
        skill = 350,
        item = 25844,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Aaron Hollman (Shattrath City 63.1, 71.1)",
            } },
        },
    },
    [32657] = {
        p = "Blacksmithing",
        skill = 360,
        item = 25845,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rohok (Hellfire Peninsula 53.2, 38.2)",
                "Mari Stonehand (Shadowmoon Valley 36.8, 55.1)",
            } },
        },
    },
    [32664] = {
        p = "Enchanting",
        skill = 300,
        item = 22461,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32665] = {
        p = "Enchanting",
        skill = 350,
        item = 22462,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rungor (Terokkar Forest 48.8, 46.1)",
                "Vodesiin (Hellfire Peninsula 24.4, 38.8)",
            } },
        },
    },
    [32667] = {
        p = "Enchanting",
        skill = 375,
        item = 22463,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Vendor", d = {
                "Madame Ruby (Shattrath City 63.1, 69.3)",
            } },
        },
    },
    [32765] = {
        p = "Alchemy",
        skill = 350,
        item = 25867,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [32766] = {
        p = "Alchemy",
        skill = 350,
        item = 25868,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Honored: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Honored: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [32801] = {
        p = "Jewelcrafting",
        skill = 50,
        item = 25880,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32807] = {
        p = "Jewelcrafting",
        skill = 110,
        item = 25881,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32808] = {
        p = "Jewelcrafting",
        skill = 175,
        item = 25882,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32809] = {
        p = "Jewelcrafting",
        skill = 225,
        item = 25883,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [32814] = {
        p = "Engineering",
        skill = 335,
        item = 25886,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [32866] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25896,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Ythyar (Karazhan)",
            } },
        },
    },
    [32867] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25897,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Ythyar (Karazhan)",
            } },
        },
    },
    [32868] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25898,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [32869] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25899,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [32870] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25901,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Friendly: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [32871] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25890,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [32872] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25893,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [32873] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25894,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Honored: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Honored: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [32874] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 25895,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Honored: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [33276] = {
        p = "Cooking",
        skill = 1,
        item = 27635,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Landraelanis (Eversong Woods 49, 47)",
            } },
        },
    },
    [33277] = {
        p = "Cooking",
        skill = 1,
        item = 24105,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #9454 (Azuremyst Isle 49.8, 51.9)",
            } },
        },
    },
    [33278] = {
        p = "Cooking",
        skill = 50,
        item = 27636,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Master Chef Mouldier (Ghostlands 48.3, 30.9)",
            } },
        },
    },
    [33279] = {
        p = "Cooking",
        skill = 300,
        item = 27651,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #9356 (Hellfire Peninsula 49.2, 74.8)",
            } },
        },
    },
    [33284] = {
        p = "Cooking",
        skill = 300,
        item = 27655,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Cookie One-Eye (Hellfire Peninsula 54.6, 41.1)",
                "Sid Limbardi (Hellfire Peninsula 54.3, 63.6)",
            } },
        },
    },
    [33285] = {
        p = "Cooking",
        skill = 310,
        item = 27656,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Mycah (Zangarmarsh 17.9, 51.2)",
            } },
        },
    },
    [33286] = {
        p = "Cooking",
        skill = 315,
        item = 27657,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Innkeeper Grilka (Terokkar Forest 48.8, 45.1)",
                "Supply Officer Mills (Terokkar Forest 55.7, 53.1)",
            } },
        },
    },
    [33287] = {
        p = "Cooking",
        skill = 325,
        item = 27658,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Uriku (Nagrand 56.2, 73.3)",
                "Nula the Butcher (Nagrand 58, 35.7)",
            } },
        },
    },
    [33288] = {
        p = "Cooking",
        skill = 325,
        item = 27659,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Innkeeper Grilka (Terokkar Forest 48.8, 45.1)",
                "Supply Officer Mills (Terokkar Forest 55.7, 53.1)",
            } },
        },
    },
    [33289] = {
        p = "Cooking",
        skill = 325,
        item = 27660,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Uriku (Nagrand 56.2, 73.3)",
                "Nula the Butcher (Nagrand 58, 35.7)",
            } },
        },
    },
    [33290] = {
        p = "Cooking",
        skill = 300,
        item = 27661,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Gambarinka (Zangarmarsh 31.7, 49.3)",
                "Doba (Zangarmarsh 42.3, 27.9)",
            } },
        },
    },
    [33291] = {
        p = "Cooking",
        skill = 300,
        item = 27662,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Zurai (Zangarmarsh 85.2, 54.7)",
                "Doba (Zangarmarsh 42.3, 27.9)",
            } },
        },
    },
    [33292] = {
        p = "Cooking",
        skill = 310,
        item = 27663,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Juno Dufrain (Zangarmarsh 78, 66.1)",
            } },
        },
    },
    [33293] = {
        p = "Cooking",
        skill = 320,
        item = 27664,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Uriku (Nagrand 56.2, 73.3)",
                "Nula the Butcher (Nagrand 58, 35.7)",
            } },
        },
    },
    [33294] = {
        p = "Cooking",
        skill = 320,
        item = 27665,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Uriku (Nagrand 56.2, 73.3)",
                "Nula the Butcher (Nagrand 58, 35.7)",
            } },
        },
    },
    [33295] = {
        p = "Cooking",
        skill = 325,
        item = 27666,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rungor (Terokkar Forest 48.8, 46.1)",
                "Innkeeper Biribi (Terokkar Forest 56.7, 53.3)",
            } },
        },
    },
    [33296] = {
        p = "Cooking",
        skill = 350,
        item = 27667,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Rungor (Terokkar Forest 48.8, 46.1)",
                "Innkeeper Biribi (Terokkar Forest 56.7, 53.3)",
            } },
        },
    },
    [33732] = {
        p = "Alchemy",
        skill = 300,
        item = 28100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33733] = {
        p = "Alchemy",
        skill = 310,
        item = 28101,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33738] = {
        p = "Alchemy",
        skill = 300,
        item = 28102,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33740] = {
        p = "Alchemy",
        skill = 300,
        item = 28103,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33741] = {
        p = "Alchemy",
        skill = 315,
        item = 28104,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33990] = {
        p = "Enchanting",
        skill = 320,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33991] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33992] = {
        p = "Enchanting",
        skill = 345,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [33993] = {
        p = "Enchanting",
        skill = 305,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33994] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Revered: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [33995] = {
        p = "Enchanting",
        skill = 340,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33996] = {
        p = "Enchanting",
        skill = 310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [33997] = {
        p = "Enchanting",
        skill = 360,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Honored: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [33999] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Honored: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [34001] = {
        p = "Enchanting",
        skill = 305,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34002] = {
        p = "Enchanting",
        skill = 300,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34003] = {
        p = "Enchanting",
        skill = 325,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Friendly: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Friendly: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [34004] = {
        p = "Enchanting",
        skill = 310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34005] = {
        p = "Enchanting",
        skill = 350,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Eclipsion Archmage (Shadowmoon Valley 49.5, 58.5)",
            } },
        },
    },
    [34006] = {
        p = "Enchanting",
        skill = 350,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Voidshrieker (Netherstorm 60, 39)",
            } },
        },
    },
    [34007] = {
        p = "Enchanting",
        skill = 360,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [34008] = {
        p = "Enchanting",
        skill = 360,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [34009] = {
        p = "Enchanting",
        skill = 325,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Madame Ruby (Shattrath City 63.1, 69.3)",
            } },
        },
    },
    [34010] = {
        p = "Enchanting",
        skill = 350,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [34069] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 28290,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34529] = {
        p = "Blacksmithing",
        skill = 350,
        item = 23563,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34530] = {
        p = "Blacksmithing",
        skill = 375,
        item = 23564,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34533] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28483,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34534] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28484,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34535] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28425,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34537] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28426,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34538] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28428,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34540] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28429,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34541] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28431,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34542] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28432,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34543] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28434,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34544] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28435,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34545] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28437,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34546] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28438,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34547] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28440,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34548] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28441,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34590] = {
        p = "Jewelcrafting",
        skill = 305,
        item = 28595,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34607] = {
        p = "Blacksmithing",
        skill = 300,
        item = 28420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34608] = {
        p = "Blacksmithing",
        skill = 350,
        item = 28421,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [34955] = {
        p = "Jewelcrafting",
        skill = 180,
        item = 29157,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34959] = {
        p = "Jewelcrafting",
        skill = 200,
        item = 29158,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34960] = {
        p = "Jewelcrafting",
        skill = 280,
        item = 29159,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34961] = {
        p = "Jewelcrafting",
        skill = 290,
        item = 29160,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34979] = {
        p = "Blacksmithing",
        skill = 100,
        item = 29201,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34981] = {
        p = "Blacksmithing",
        skill = 200,
        item = 29202,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34982] = {
        p = "Blacksmithing",
        skill = 300,
        item = 29203,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [34983] = {
        p = "Blacksmithing",
        skill = 350,
        item = 29204,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35520] = {
        p = "Leatherworking",
        skill = 340,
        item = 29483,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Time-Lost Shadowmage (Sethekk Halls)",
            } },
        },
    },
    [35521] = {
        p = "Leatherworking",
        skill = 340,
        item = 29485,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Gargantuan Abyssal (The Arcatraz)",
            } },
        },
    },
    [35522] = {
        p = "Leatherworking",
        skill = 340,
        item = 29486,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Hydromancer Thespia (The Steamvault)",
            } },
        },
    },
    [35523] = {
        p = "Leatherworking",
        skill = 340,
        item = 29487,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Mennu the Betrayer (The Slave Pens)",
            } },
        },
    },
    [35524] = {
        p = "Leatherworking",
        skill = 340,
        item = 29488,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Chrono Lord Deja (The Black Morass)",
            } },
        },
    },
    [35525] = {
        p = "Leatherworking",
        skill = 350,
        item = 29489,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Exalted: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35526] = {
        p = "Leatherworking",
        skill = 350,
        item = 29490,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Honored: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35527] = {
        p = "Leatherworking",
        skill = 350,
        item = 29491,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35528] = {
        p = "Leatherworking",
        skill = 350,
        item = 29493,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Revered: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35529] = {
        p = "Leatherworking",
        skill = 350,
        item = 29492,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Exalted: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35530] = {
        p = "Leatherworking",
        skill = 325,
        item = 29540,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Honored: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [35531] = {
        p = "Leatherworking",
        skill = 350,
        item = 29494,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35532] = {
        p = "Leatherworking",
        skill = 350,
        item = 29495,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Exalted: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35533] = {
        p = "Leatherworking",
        skill = 350,
        item = 29496,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Revered: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35534] = {
        p = "Leatherworking",
        skill = 350,
        item = 29497,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scryers - Honored: Quartermaster Enuril (Shattrath City 60.5, 64.2)",
            } },
        },
    },
    [35535] = {
        p = "Leatherworking",
        skill = 350,
        item = 29498,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Exalted: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35536] = {
        p = "Leatherworking",
        skill = 350,
        item = 29499,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Revered: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35537] = {
        p = "Leatherworking",
        skill = 350,
        item = 29500,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [35538] = {
        p = "Leatherworking",
        skill = 370,
        item = 29532,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Honored: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [35539] = {
        p = "Leatherworking",
        skill = 350,
        item = 29531,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kurenai - Honored: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [35540] = {
        p = "Leatherworking",
        skill = 340,
        item = 29528,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35543] = {
        p = "Leatherworking",
        skill = 365,
        item = 29529,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Honored: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [35544] = {
        p = "Leatherworking",
        skill = 345,
        item = 29530,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Mag'har - Honored: Provisioner Nasela (Nagrand 53.5, 36.9)",
            } },
            { t = "Reputation Vendor", d = {
                "Kurenai - Honored: Trader Narasu (Nagrand 54.6, 75.2)",
            } },
        },
    },
    [35549] = {
        p = "Leatherworking",
        skill = 335,
        item = 29533,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Honored: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Honored: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [35554] = {
        p = "Leatherworking",
        skill = 365,
        item = 29535,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Honor Hold - Exalted: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
            { t = "Reputation Vendor", d = {
                "Thrallmar - Exalted: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
        },
    },
    [35555] = {
        p = "Leatherworking",
        skill = 335,
        item = 29534,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [35557] = {
        p = "Leatherworking",
        skill = 365,
        item = 29536,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [35558] = {
        p = "Leatherworking",
        skill = 365,
        item = 29502,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35559] = {
        p = "Leatherworking",
        skill = 365,
        item = 29503,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35560] = {
        p = "Leatherworking",
        skill = 365,
        item = 29504,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35561] = {
        p = "Leatherworking",
        skill = 365,
        item = 29505,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35562] = {
        p = "Leatherworking",
        skill = 365,
        item = 29506,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [35563] = {
        p = "Leatherworking",
        skill = 365,
        item = 29507,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35564] = {
        p = "Leatherworking",
        skill = 365,
        item = 29508,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35567] = {
        p = "Leatherworking",
        skill = 365,
        item = 29512,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35568] = {
        p = "Leatherworking",
        skill = 365,
        item = 29509,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [35572] = {
        p = "Leatherworking",
        skill = 365,
        item = 29510,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35573] = {
        p = "Leatherworking",
        skill = 365,
        item = 29511,
        q = "Epic",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [35574] = {
        p = "Leatherworking",
        skill = 365,
        item = 29514,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [35575] = {
        p = "Leatherworking",
        skill = 375,
        item = 29515,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35576] = {
        p = "Leatherworking",
        skill = 375,
        item = 29516,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35577] = {
        p = "Leatherworking",
        skill = 375,
        item = 29517,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35580] = {
        p = "Leatherworking",
        skill = 375,
        item = 29519,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35582] = {
        p = "Leatherworking",
        skill = 375,
        item = 29520,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35584] = {
        p = "Leatherworking",
        skill = 375,
        item = 29521,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35585] = {
        p = "Leatherworking",
        skill = 375,
        item = 29522,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35587] = {
        p = "Leatherworking",
        skill = 375,
        item = 29524,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35588] = {
        p = "Leatherworking",
        skill = 375,
        item = 29523,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35589] = {
        p = "Leatherworking",
        skill = 375,
        item = 29525,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35590] = {
        p = "Leatherworking",
        skill = 375,
        item = 29526,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35591] = {
        p = "Leatherworking",
        skill = 375,
        item = 29527,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35750] = {
        p = "Mining",
        skill = 300,
        item = 22573,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [35751] = {
        p = "Mining",
        skill = 300,
        item = 22574,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36074] = {
        p = "Leatherworking",
        skill = 260,
        item = 29964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36075] = {
        p = "Leatherworking",
        skill = 260,
        item = 29970,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36076] = {
        p = "Leatherworking",
        skill = 260,
        item = 29971,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36077] = {
        p = "Leatherworking",
        skill = 330,
        item = 29973,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36078] = {
        p = "Leatherworking",
        skill = 330,
        item = 29974,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36079] = {
        p = "Leatherworking",
        skill = 330,
        item = 29975,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36122] = {
        p = "Blacksmithing",
        skill = 260,
        item = 30069,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36124] = {
        p = "Blacksmithing",
        skill = 260,
        item = 30070,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36125] = {
        p = "Blacksmithing",
        skill = 260,
        item = 30071,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36126] = {
        p = "Blacksmithing",
        skill = 260,
        item = 30072,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36128] = {
        p = "Blacksmithing",
        skill = 260,
        item = 30073,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36129] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30074,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36130] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30076,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36131] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30077,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36133] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30086,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36134] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30087,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36135] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30088,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36136] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30089,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36137] = {
        p = "Blacksmithing",
        skill = 330,
        item = 30093,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36210] = {
        p = "Cooking",
        skill = 300,
        item = 30155,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Mycah (Zangarmarsh 17.9, 51.2)",
            } },
        },
    },
    [36256] = {
        p = "Blacksmithing",
        skill = 375,
        item = 23565,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36257] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28485,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36258] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28427,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36259] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28430,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36260] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28433,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36261] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28436,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36262] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28439,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36263] = {
        p = "Blacksmithing",
        skill = 375,
        item = 28442,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36315] = {
        p = "Tailoring",
        skill = 375,
        item = 30038,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36316] = {
        p = "Tailoring",
        skill = 375,
        item = 30036,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36317] = {
        p = "Tailoring",
        skill = 375,
        item = 30037,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36318] = {
        p = "Tailoring",
        skill = 375,
        item = 30035,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36349] = {
        p = "Leatherworking",
        skill = 375,
        item = 30042,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36351] = {
        p = "Leatherworking",
        skill = 375,
        item = 30040,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36352] = {
        p = "Leatherworking",
        skill = 375,
        item = 30046,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36353] = {
        p = "Leatherworking",
        skill = 375,
        item = 30044,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36355] = {
        p = "Leatherworking",
        skill = 375,
        item = 30041,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36357] = {
        p = "Leatherworking",
        skill = 375,
        item = 30039,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36358] = {
        p = "Leatherworking",
        skill = 375,
        item = 30045,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36359] = {
        p = "Leatherworking",
        skill = 375,
        item = 30043,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36389] = {
        p = "Blacksmithing",
        skill = 375,
        item = 30034,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36390] = {
        p = "Blacksmithing",
        skill = 375,
        item = 30032,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36391] = {
        p = "Blacksmithing",
        skill = 375,
        item = 30033,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36392] = {
        p = "Blacksmithing",
        skill = 375,
        item = 30031,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from mobs in Serpentshrine Cavern. (Serpentshrine Cavern)",
            } },
            { t = "Special", d = {
                "Random drop from mobs in Tempest Keep: The Eye. (The Eye)",
            } },
        },
    },
    [36523] = {
        p = "Jewelcrafting",
        skill = 75,
        item = 30419,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36524] = {
        p = "Jewelcrafting",
        skill = 105,
        item = 30420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36525] = {
        p = "Jewelcrafting",
        skill = 230,
        item = 30421,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36526] = {
        p = "Jewelcrafting",
        skill = 265,
        item = 30422,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36686] = {
        p = "Tailoring",
        skill = 350,
        item = 24272,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Andrion Darkspinner (Shattrath City 66, 67.8)",
                "Linna Bruder (Dalaran 34.6, 34.5)",
            } },
        },
    },
    [36954] = {
        p = "Engineering",
        skill = 350,
        item = 30542,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [36955] = {
        p = "Engineering",
        skill = 350,
        item = 30544,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [37818] = {
        p = "Jewelcrafting",
        skill = 65,
        item = 30804,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [37836] = {
        p = "Cooking",
        skill = 1,
        item = 30816,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [37855] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 30825,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Honored: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [37873] = {
        p = "Tailoring",
        skill = 350,
        item = 30831,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Honored: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [37882] = {
        p = "Tailoring",
        skill = 350,
        item = 30837,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Friendly: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [37883] = {
        p = "Tailoring",
        skill = 360,
        item = 30838,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Honored: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [37884] = {
        p = "Tailoring",
        skill = 370,
        item = 30839,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Aldor - Exalted: Quartermaster Endarin (Shattrath City 47.9, 26.1)",
            } },
        },
    },
    [38068] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31079,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [38070] = {
        p = "Alchemy",
        skill = 325,
        item = 31080,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [38175] = {
        p = "Jewelcrafting",
        skill = 80,
        item = 31154,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [38473] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31364,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [38475] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31367,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Revered: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [38476] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31368,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Revered: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [38477] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31369,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Honored: Koren (Karazhan)",
            } },
        },
    },
    [38478] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31370,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Revered: Koren (Karazhan)",
            } },
        },
    },
    [38479] = {
        p = "Blacksmithing",
        skill = 375,
        item = 31371,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Honored: Koren (Karazhan)",
            } },
        },
    },
    [38503] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 31398,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Honored: Apprentice Darius (Deadwind Pass 47, 75.3)",
            } },
        },
    },
    [38504] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 31399,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Exalted: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [38867] = {
        p = "Cooking",
        skill = 335,
        item = 31672,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xerintha Ravenoak (Blade's Edge Mountains 62.5, 40.3)",
                "Sassa Weldwell (Blade's Edge Mountains 61.3, 68.9)",
            } },
            { t = "Quest", d = {
                "Quest #10860 (Blade's Edge Mountains 76.1, 60.3)",
            } },
        },
    },
    [38868] = {
        p = "Cooking",
        skill = 335,
        item = 31673,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xerintha Ravenoak (Blade's Edge Mountains 62.5, 40.3)",
                "Sassa Weldwell (Blade's Edge Mountains 61.3, 68.9)",
            } },
            { t = "Quest", d = {
                "Quest #10860 (Blade's Edge Mountains 76.1, 60.3)",
            } },
        },
    },
    [38960] = {
        p = "Alchemy",
        skill = 335,
        item = 31679,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Wrathwalker (Shadowmoon Valley 25.5, 33)",
                "Shadow Council Warlock (Shadowmoon Valley 22.9, 38.2)",
                "Mo'arg Weaponsmith (Shadowmoon Valley 25.5, 31.5)",
                "Terrormaster (Shadowmoon Valley 24, 45)",
            } },
        },
    },
    [38961] = {
        p = "Alchemy",
        skill = 360,
        item = 31677,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Eclipsion Blood Knight (Shadowmoon Valley 52.7, 63.2)",
                "Eclipsion Centurion (Shadowmoon Valley 48, 61.8)",
                "Torloth the Magnificent (Shadowmoon Valley 51.2, 72.5)",
                "Eclipsion Spellbinder (Shadowmoon Valley 52.7, 63.4)",
                "Eclipsion Soldier (Shadowmoon Valley 52.8, 66.5)",
                "Eclipsion Cavalier (Shadowmoon Valley 52.7, 61.1)",
                "Eclipsion Archmage (Shadowmoon Valley 49.5, 58.5)",
                "Eclipsion Bloodwarder (Shadowmoon Valley 46.5, 66)",
                "Illidari Watcher (Shadowmoon Valley 52.5, 72)",
            } },
        },
    },
    [38962] = {
        p = "Alchemy",
        skill = 345,
        item = 31676,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Deathforge Smith (Shadowmoon Valley 37.5, 42)",
                "Deathforge Tinkerer (Shadowmoon Valley 39, 38.7)",
                "Deathforge Guardian (Shadowmoon Valley 39, 47)",
                "Deathforge Imp (Shadowmoon Valley 40.5, 39.1)",
            } },
        },
    },
    [39451] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31860,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Drops from dragons in Ogri'la and Blade's Edge Mountains Summon Bosses",
            } },
        },
    },
    [39452] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 31861,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39455] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31862,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Drops from dragons in Ogri'la and Blade's Edge Mountains Summon Bosses",
            } },
        },
    },
    [39458] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31864,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Drops from dragons in Ogri'la and Blade's Edge Mountains Summon Bosses",
            } },
        },
    },
    [39462] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 31865,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39463] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 31863,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39466] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31866,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Drops from dragons in Ogri'la and Blade's Edge Mountains Summon Bosses",
            } },
        },
    },
    [39467] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 31869,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Drops from dragons in Ogri'la and Blade's Edge Mountains Summon Bosses",
            } },
        },
    },
    [39470] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 31867,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39471] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 31868,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39636] = {
        p = "Alchemy",
        skill = 310,
        item = 32062,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [39637] = {
        p = "Alchemy",
        skill = 320,
        item = 32063,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Cenarion Expedition - Honored: Fedryen Swiftspear (Zangarmarsh 79.3, 63.8)",
            } },
        },
    },
    [39638] = {
        p = "Alchemy",
        skill = 320,
        item = 32067,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [39639] = {
        p = "Alchemy",
        skill = 330,
        item = 32068,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Quartermaster Jaffrey Noreliqe (Nagrand 41.2, 44.3)",
                "Quartermaster Davian Vaclav (Nagrand 41.2, 44.3)",
            } },
        },
    },
    [39705] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32193,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39706] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32194,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39710] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32195,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39711] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32196,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39712] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32197,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39713] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32198,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39714] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32199,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39715] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32200,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39716] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32201,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39717] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32202,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39718] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32203,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39719] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32204,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39720] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32205,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39721] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32206,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Revered: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39722] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32207,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39723] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32208,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Friendly: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Friendly: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Friendly: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39724] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32209,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39725] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32210,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39727] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32211,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39728] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32212,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39729] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32213,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39730] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32214,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39731] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32215,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39732] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32216,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Revered: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39733] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32217,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39734] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32218,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39735] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32219,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39736] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32220,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39737] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32221,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
            } },
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
        },
    },
    [39738] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32222,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Revered: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39739] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32223,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Revered: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39740] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32224,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39741] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32225,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39742] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 32226,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Honored: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [39895] = {
        p = "Engineering",
        skill = 275,
        item = 7191,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Xizzer Fizzbolt (Winterspring 60.8, 38.6)",
                "Viggz Shinesparked (Shattrath City 64.9, 69.1)",
            } },
        },
    },
    [39961] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 32409,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Exalted: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Exalted: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [39963] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 32410,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [39971] = {
        p = "Engineering",
        skill = 335,
        item = 32423,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [39973] = {
        p = "Engineering",
        skill = 335,
        item = 32413,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [39997] = {
        p = "Leatherworking",
        skill = 375,
        item = 32398,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40001] = {
        p = "Leatherworking",
        skill = 375,
        item = 32400,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40002] = {
        p = "Leatherworking",
        skill = 375,
        item = 32397,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40003] = {
        p = "Leatherworking",
        skill = 375,
        item = 32394,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40004] = {
        p = "Leatherworking",
        skill = 375,
        item = 32395,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40005] = {
        p = "Leatherworking",
        skill = 375,
        item = 32396,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40006] = {
        p = "Leatherworking",
        skill = 375,
        item = 32393,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40020] = {
        p = "Tailoring",
        skill = 375,
        item = 32391,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40021] = {
        p = "Tailoring",
        skill = 375,
        item = 32392,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40023] = {
        p = "Tailoring",
        skill = 375,
        item = 32389,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40024] = {
        p = "Tailoring",
        skill = 375,
        item = 32390,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40033] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32402,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40034] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32403,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40035] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32404,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40036] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32401,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [40060] = {
        p = "Tailoring",
        skill = 375,
        item = 32420,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Honored: Okuno (Black Temple)",
            } },
        },
    },
    [40274] = {
        p = "Engineering",
        skill = 350,
        item = 32461,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [40514] = {
        p = "Jewelcrafting",
        skill = 340,
        item = 32508,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41132] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32568,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41133] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32570,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41134] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32571,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41135] = {
        p = "Blacksmithing",
        skill = 375,
        item = 32573,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41156] = {
        p = "Leatherworking",
        skill = 375,
        item = 32582,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41157] = {
        p = "Leatherworking",
        skill = 375,
        item = 32583,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41158] = {
        p = "Leatherworking",
        skill = 375,
        item = 32580,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41160] = {
        p = "Leatherworking",
        skill = 375,
        item = 32581,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41161] = {
        p = "Leatherworking",
        skill = 375,
        item = 32574,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41162] = {
        p = "Leatherworking",
        skill = 375,
        item = 32575,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41163] = {
        p = "Leatherworking",
        skill = 375,
        item = 32577,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41164] = {
        p = "Leatherworking",
        skill = 375,
        item = 32579,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41205] = {
        p = "Tailoring",
        skill = 375,
        item = 32586,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41206] = {
        p = "Tailoring",
        skill = 375,
        item = 32587,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41207] = {
        p = "Tailoring",
        skill = 375,
        item = 32584,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Hyjal Summit trash/bosses. (Hyjal Summit)",
            } },
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41208] = {
        p = "Tailoring",
        skill = 375,
        item = 32585,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from Black Temple trash/bosses. (Black Temple)",
            } },
        },
    },
    [41307] = {
        p = "Engineering",
        skill = 375,
        item = 32756,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41311] = {
        p = "Engineering",
        skill = 350,
        item = 32472,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41312] = {
        p = "Engineering",
        skill = 350,
        item = 32473,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41314] = {
        p = "Engineering",
        skill = 350,
        item = 32474,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41315] = {
        p = "Engineering",
        skill = 350,
        item = 32476,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41316] = {
        p = "Engineering",
        skill = 350,
        item = 32475,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41317] = {
        p = "Engineering",
        skill = 350,
        item = 32478,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41318] = {
        p = "Engineering",
        skill = 350,
        item = 32479,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41319] = {
        p = "Engineering",
        skill = 350,
        item = 32480,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41320] = {
        p = "Engineering",
        skill = 350,
        item = 32494,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41321] = {
        p = "Engineering",
        skill = 350,
        item = 32495,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41414] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 32772,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41415] = {
        p = "Jewelcrafting",
        skill = 330,
        item = 32774,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41418] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 32776,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41420] = {
        p = "Jewelcrafting",
        skill = 325,
        item = 32833,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41429] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 32836,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [41458] = {
        p = "Alchemy",
        skill = 360,
        item = 32839,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by Major Protection Potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [41500] = {
        p = "Alchemy",
        skill = 360,
        item = 32849,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by Major Protection Potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [41501] = {
        p = "Alchemy",
        skill = 360,
        item = 32850,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by Major Protection Potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [41502] = {
        p = "Alchemy",
        skill = 360,
        item = 32851,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by Major Protection Potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [41503] = {
        p = "Alchemy",
        skill = 360,
        item = 32852,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered by Major Protection Potions using Burning Crusade or higher ingredients.",
            } },
        },
    },
    [42296] = {
        p = "Cooking",
        skill = 320,
        item = 33048,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [42302] = {
        p = "Cooking",
        skill = 350,
        item = 33052,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [42305] = {
        p = "Cooking",
        skill = 350,
        item = 33053,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [42546] = {
        p = "Leatherworking",
        skill = 360,
        item = 33122,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Exalted: Apprentice Darius (Deadwind Pass 47, 75.3)",
            } },
        },
    },
    [42558] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33133,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Revered: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [42588] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33134,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Honored: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [42589] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33131,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Consortium - Revered: Karaaz (Netherstorm 43.6, 34.3)",
                "The Consortium - Revered: Paulsta'ats (Nagrand 30.6, 57)",
            } },
        },
    },
    [42590] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33135,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Revered: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [42591] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33143,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Revered: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [42592] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33140,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sha'tar - Revered: Almaador (Shattrath City 51, 41.9)",
            } },
        },
    },
    [42593] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 33144,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Keepers of Time - Honored: Alurmi (Tanaris 63.6, 57.6)",
            } },
        },
    },
    [42613] = {
        p = "Enchanting",
        skill = 300,
        item = 22448,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [42615] = {
        p = "Enchanting",
        skill = 335,
        item = 22448,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [42620] = {
        p = "Enchanting",
        skill = 350,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Exalted: Apprentice Darius (Deadwind Pass 47, 75.3)",
            } },
        },
    },
    [42662] = {
        p = "Blacksmithing",
        skill = 365,
        item = 33173,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Enraged Fire Spirit (Shadowmoon Valley 48, 43.5)",
                "Enraged Water Spirit (Shadowmoon Valley 51, 25.5)",
                "Enraged Air Spirit (Shadowmoon Valley 70.5, 28.5)",
                "Enraged Earth Spirit (Shadowmoon Valley 46.5, 45)",
            } },
        },
    },
    [42688] = {
        p = "Blacksmithing",
        skill = 335,
        item = 33185,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Kael'thas Sunstrider (Magisters' Terrace)",
            } },
        },
    },
    [42731] = {
        p = "Leatherworking",
        skill = 365,
        item = 33204,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Revered: Apprentice Darius (Deadwind Pass 47, 75.3)",
            } },
        },
    },
    [42736] = {
        p = "Alchemy",
        skill = 375,
        item = 33208,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Violet Eye - Honored: Apprentice Darius (Deadwind Pass 47, 75.3)",
            } },
        },
    },
    [42974] = {
        p = "Enchanting",
        skill = 375,
        item = 33307,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random drop off of Zul'Aman bosses. (Zul'Aman)",
            } },
        },
    },
    [43493] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 33782,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Quartermaster Jaffrey Noreliqe (Nagrand 41.2, 44.3)",
                "Quartermaster Davian Vaclav (Nagrand 41.2, 44.3)",
            } },
        },
    },
    [43549] = {
        p = "Blacksmithing",
        skill = 35,
        item = 33791,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #1578 (Ironforge 48.5, 43)",
            } },
        },
    },
    [43676] = {
        p = "Engineering",
        skill = 335,
        item = 20475,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Sunfury Archer (Netherstorm 55.5, 81)",
            } },
        },
    },
    [43707] = {
        p = "Cooking",
        skill = 325,
        item = 33825,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
            } },
            { t = "Special", d = {
                "Choose Barrel of Fish when completing any of these quests. (Shattrath)",
            } },
        },
    },
    [43758] = {
        p = "Cooking",
        skill = 300,
        item = 33866,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
                "Quest #13100 (Dalaran 40.5, 65.8)",
                "Quest #13101 (Dalaran 40.5, 65.8)",
                "Quest #13102 (Dalaran 40.5, 65.8)",
                "Quest #13103 (Dalaran 40.5, 65.8)",
                "Quest #13107 (Dalaran 40.5, 65.8)",
                "Quest #13112 (Dalaran 70, 38.6)",
                "Quest #13113 (Dalaran 70, 38.6)",
                "Quest #13114 (Dalaran 70, 38.6)",
                "Quest #13115 (Dalaran 70, 38.6)",
                "Quest #13116 (Dalaran 70, 38.6)",
            } },
            { t = "Special", d = {
                "Choose Crate of Meat when completing any of these quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Choose Barrel of Fish when completing any of these quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Randomly obtained by completing any of the cooking daily quests in Dalaran. (Dalaran)",
            } },
        },
    },
    [43761] = {
        p = "Cooking",
        skill = 300,
        item = 33867,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
            } },
            { t = "Special", d = {
                "Choose Barrel of Fish when completing any of these quests. (Shattrath)",
            } },
        },
    },
    [43765] = {
        p = "Cooking",
        skill = 325,
        item = 33872,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
            } },
            { t = "Special", d = {
                "Choose Crate of Meat when completing any of these quests. (Shattrath)",
            } },
        },
    },
    [43772] = {
        p = "Cooking",
        skill = 300,
        item = 33874,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
            } },
            { t = "Special", d = {
                "Choose Crate of Meat when completing any of these quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Choose Barrel of Fish when completing any of these quests. (Shattrath)",
            } },
        },
    },
    [43779] = {
        p = "Cooking",
        skill = 1,
        item = 33924,
        q = "Rare",
        sources = {
            { t = "Quest", d = {
                "Quest #11381 (Shattrath City 61.6, 16.5)",
                "Quest #11377 (Shattrath City 61.6, 16.5)",
                "Quest #11379 (Shattrath City 61.6, 16.5)",
                "Quest #11380 (Shattrath City 61.6, 16.5)",
                "Quest #13100 (Dalaran 40.5, 65.8)",
                "Quest #13101 (Dalaran 40.5, 65.8)",
                "Quest #13102 (Dalaran 40.5, 65.8)",
                "Quest #13103 (Dalaran 40.5, 65.8)",
                "Quest #13107 (Dalaran 40.5, 65.8)",
                "Quest #13112 (Dalaran 70, 38.6)",
                "Quest #13113 (Dalaran 70, 38.6)",
                "Quest #13114 (Dalaran 70, 38.6)",
                "Quest #13115 (Dalaran 70, 38.6)",
                "Quest #13116 (Dalaran 70, 38.6)",
            } },
            { t = "Special", d = {
                "Choose Crate of Meat when completing any of these quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Choose Barrel of Fish when completing any of these quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Randomly obtained by completing any of the cooking daily quests in Dalaran. (Dalaran)",
            } },
        },
    },
    [43846] = {
        p = "Blacksmithing",
        skill = 365,
        item = 32854,
        q = "Epic",
        sources = {
            { t = "World Drop", d = {
                "Outland",
            } },
        },
    },
    [44155] = {
        p = "Engineering",
        skill = 300,
        item = 34060,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44157] = {
        p = "Engineering",
        skill = 375,
        item = 34061,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44343] = {
        p = "Leatherworking",
        skill = 315,
        item = 34099,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44344] = {
        p = "Leatherworking",
        skill = 315,
        item = 34100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44359] = {
        p = "Leatherworking",
        skill = 350,
        item = 34105,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Lower City - Revered: Nakodu (Shattrath City 62.1, 69)",
            } },
        },
    },
    [44383] = {
        p = "Enchanting",
        skill = 330,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44391] = {
        p = "Engineering",
        skill = 360,
        item = 34113,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Simon Unit (Blade's Edge Mountains 33.5, 51.5)",
                "Gan'arg Analyzer (Blade's Edge Mountains 33, 52.5)",
            } },
        },
    },
    [44483] = {
        p = "Enchanting",
        skill = 400,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Damned Apothecary (Icecrown 49.8, 32.7)",
            } },
        },
    },
    [44484] = {
        p = "Enchanting",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44488] = {
        p = "Enchanting",
        skill = 410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44489] = {
        p = "Enchanting",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44492] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44494] = {
        p = "Enchanting",
        skill = 400,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cult Alchemist (Icecrown 49.5, 33.1)",
            } },
        },
    },
    [44500] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44506] = {
        p = "Enchanting",
        skill = 375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44508] = {
        p = "Enchanting",
        skill = 410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44509] = {
        p = "Enchanting",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44510] = {
        p = "Enchanting",
        skill = 410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44513] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44524] = {
        p = "Enchanting",
        skill = 425,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44528] = {
        p = "Enchanting",
        skill = 385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44529] = {
        p = "Enchanting",
        skill = 415,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44555] = {
        p = "Enchanting",
        skill = 375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44556] = {
        p = "Enchanting",
        skill = 400,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Skeletal Runesmith (Icecrown 60, 73.1)",
            } },
        },
    },
    [44575] = {
        p = "Enchanting",
        skill = 430,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44576] = {
        p = "Enchanting",
        skill = 425,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44582] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44584] = {
        p = "Enchanting",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44588] = {
        p = "Enchanting",
        skill = 410,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44589] = {
        p = "Enchanting",
        skill = 415,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44590] = {
        p = "Enchanting",
        skill = 400,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cultist Shard Watcher (Icecrown 48.1, 67.9)",
            } },
        },
    },
    [44591] = {
        p = "Enchanting",
        skill = 435,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44592] = {
        p = "Enchanting",
        skill = 360,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44593] = {
        p = "Enchanting",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44595] = {
        p = "Enchanting",
        skill = 430,
        item = 44473,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44596] = {
        p = "Enchanting",
        skill = 400,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Frostbrood Spawn (Icecrown 75.3, 43.4)",
                "Cult Researcher (Icecrown 50.7, 30.9)",
            } },
        },
    },
    [44598] = {
        p = "Enchanting",
        skill = 415,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44616] = {
        p = "Enchanting",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44621] = {
        p = "Enchanting",
        skill = 430,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44623] = {
        p = "Enchanting",
        skill = 370,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44625] = {
        p = "Enchanting",
        skill = 435,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44629] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44630] = {
        p = "Enchanting",
        skill = 390,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44631] = {
        p = "Enchanting",
        skill = 440,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [44633] = {
        p = "Enchanting",
        skill = 410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44635] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44636] = {
        p = "Enchanting",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44645] = {
        p = "Enchanting",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44768] = {
        p = "Leatherworking",
        skill = 350,
        item = 34106,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Thrallmar - Revered: Quartermaster Urgronn (Hellfire Peninsula 54.9, 37.9)",
            } },
            { t = "Reputation Vendor", d = {
                "Honor Hold - Revered: Logistics Officer Ulrike (Hellfire Peninsula 56.7, 62.6)",
            } },
        },
    },
    [44770] = {
        p = "Leatherworking",
        skill = 350,
        item = 34207,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [44794] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34220,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Coilskar Siren (Shadowmoon Valley 46.5, 30)",
            } },
        },
    },
    [44950] = {
        p = "Tailoring",
        skill = 250,
        item = 34087,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Penney Copperpinch (Orgrimmar 53.5, 66.1)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [44953] = {
        p = "Leatherworking",
        skill = 285,
        item = 34086,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Penney Copperpinch (Orgrimmar 53.5, 66.1)",
                "Wulmort Jinglepocket (Ironforge 33, 67.6)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [44958] = {
        p = "Tailoring",
        skill = 250,
        item = 34085,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Wulmort Jinglepocket (Ironforge 33, 67.6)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [44970] = {
        p = "Leatherworking",
        skill = 350,
        item = 34330,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45022] = {
        p = "Cooking",
        skill = 325,
        item = 34411,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Penney Copperpinch (Orgrimmar 53.5, 66.1)",
                "Wulmort Jinglepocket (Ironforge 33, 67.6)",
            } },
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [45061] = {
        p = "Alchemy",
        skill = 325,
        item = 34440,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45100] = {
        p = "Leatherworking",
        skill = 300,
        item = 34482,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45117] = {
        p = "Leatherworking",
        skill = 360,
        item = 34490,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Gordunni Elementalist (Terokkar Forest 21.3, 12)",
                "Gordunni Head-Splitter (Terokkar Forest 22.5, 8.3)",
                "Gordunni Back-Breaker (Terokkar Forest 21.2, 8.1)",
                "Gordunni Soulreaper (Terokkar Forest 22.9, 8.8)",
            } },
        },
    },
    [45382] = {
        p = "Inscription",
        skill = 1,
        item = 1180,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [45545] = {
        p = "First Aid",
        skill = 350,
        item = 34721,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45546] = {
        p = "First Aid",
        skill = 400,
        item = 34722,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [45549] = {
        p = "Cooking",
        skill = 350,
        item = 34748,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45550] = {
        p = "Cooking",
        skill = 350,
        item = 34749,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45551] = {
        p = "Cooking",
        skill = 350,
        item = 34750,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45552] = {
        p = "Cooking",
        skill = 350,
        item = 34751,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45553] = {
        p = "Cooking",
        skill = 350,
        item = 34752,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45554] = {
        p = "Cooking",
        skill = 375,
        item = 34753,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45555] = {
        p = "Cooking",
        skill = 400,
        item = 34754,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45556] = {
        p = "Cooking",
        skill = 400,
        item = 34755,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45557] = {
        p = "Cooking",
        skill = 400,
        item = 34756,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45558] = {
        p = "Cooking",
        skill = 400,
        item = 34757,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45559] = {
        p = "Cooking",
        skill = 400,
        item = 34758,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45560] = {
        p = "Cooking",
        skill = 350,
        item = 34759,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45561] = {
        p = "Cooking",
        skill = 350,
        item = 34760,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45562] = {
        p = "Cooking",
        skill = 350,
        item = 34761,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45563] = {
        p = "Cooking",
        skill = 350,
        item = 34762,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45564] = {
        p = "Cooking",
        skill = 350,
        item = 34763,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45565] = {
        p = "Cooking",
        skill = 350,
        item = 34764,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45566] = {
        p = "Cooking",
        skill = 350,
        item = 34765,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45567] = {
        p = "Cooking",
        skill = 400,
        item = 34766,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45568] = {
        p = "Cooking",
        skill = 400,
        item = 34767,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45569] = {
        p = "Cooking",
        skill = 350,
        item = 42942,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [45570] = {
        p = "Cooking",
        skill = 400,
        item = 34769,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45571] = {
        p = "Cooking",
        skill = 400,
        item = 34768,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [45695] = {
        p = "Cooking",
        skill = 100,
        item = 34832,
        q = "Uncommon",
        sources = {
            { t = "Quest", d = {
                "Quest #11666 (Terokkar Forest 38.7, 12.8)",
                "Quest #11668 (Terokkar Forest 38.7, 12.8)",
                "Quest #11667 (Terokkar Forest 38.7, 12.8)",
                "Quest #11669 (Terokkar Forest 38.7, 12.8)",
                "Quest #13100 (Dalaran 40.5, 65.8)",
                "Quest #13101 (Dalaran 40.5, 65.8)",
                "Quest #13102 (Dalaran 40.5, 65.8)",
                "Quest #13103 (Dalaran 40.5, 65.8)",
                "Quest #13107 (Dalaran 40.5, 65.8)",
                "Quest #13112 (Dalaran 70, 38.6)",
                "Quest #13113 (Dalaran 70, 38.6)",
                "Quest #13114 (Dalaran 70, 38.6)",
                "Quest #13115 (Dalaran 70, 38.6)",
                "Quest #13116 (Dalaran 70, 38.6)",
            } },
            { t = "Special", d = {
                "Randomly obtained by completing any of the BC fishing daily quests. (Shattrath)",
            } },
            { t = "Special", d = {
                "Randomly obtained by completing any of the cooking daily quests in Dalaran. (Dalaran)",
            } },
        },
    },
    [45765] = {
        p = "Enchanting",
        skill = 375,
        item = 22449,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46106] = {
        p = "Engineering",
        skill = 375,
        item = 35183,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46107] = {
        p = "Engineering",
        skill = 375,
        item = 35185,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46108] = {
        p = "Engineering",
        skill = 375,
        item = 35181,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46109] = {
        p = "Engineering",
        skill = 375,
        item = 35182,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46110] = {
        p = "Engineering",
        skill = 375,
        item = 35184,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46111] = {
        p = "Engineering",
        skill = 375,
        item = 34847,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46112] = {
        p = "Engineering",
        skill = 375,
        item = 34355,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46113] = {
        p = "Engineering",
        skill = 375,
        item = 34356,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46114] = {
        p = "Engineering",
        skill = 375,
        item = 34354,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46115] = {
        p = "Engineering",
        skill = 375,
        item = 34357,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46116] = {
        p = "Engineering",
        skill = 375,
        item = 34353,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46122] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34362,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46123] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34363,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46124] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34361,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46125] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34359,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46126] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34360,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46127] = {
        p = "Jewelcrafting",
        skill = 365,
        item = 34358,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46128] = {
        p = "Tailoring",
        skill = 365,
        item = 34366,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46129] = {
        p = "Tailoring",
        skill = 365,
        item = 34367,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46130] = {
        p = "Tailoring",
        skill = 365,
        item = 34364,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46131] = {
        p = "Tailoring",
        skill = 365,
        item = 34365,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46132] = {
        p = "Leatherworking",
        skill = 365,
        item = 34372,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46133] = {
        p = "Leatherworking",
        skill = 365,
        item = 34374,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46134] = {
        p = "Leatherworking",
        skill = 365,
        item = 34370,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46135] = {
        p = "Leatherworking",
        skill = 365,
        item = 34376,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46136] = {
        p = "Leatherworking",
        skill = 365,
        item = 34371,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46137] = {
        p = "Leatherworking",
        skill = 365,
        item = 34373,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46138] = {
        p = "Leatherworking",
        skill = 365,
        item = 34369,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46139] = {
        p = "Leatherworking",
        skill = 365,
        item = 34375,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46140] = {
        p = "Blacksmithing",
        skill = 365,
        item = 34380,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46141] = {
        p = "Blacksmithing",
        skill = 365,
        item = 34378,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46142] = {
        p = "Blacksmithing",
        skill = 365,
        item = 34379,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46144] = {
        p = "Blacksmithing",
        skill = 365,
        item = 34377,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46353] = {
        p = "Mining",
        skill = 375,
        item = 35128,
        q = "Rare",
        sources = {
            { t = "Special", d = {
                "Random Sunwell trash drop. (Sunwell Plateau)",
            } },
        },
    },
    [46403] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 35315,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
        },
    },
    [46404] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 35316,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
        },
    },
    [46405] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 35318,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
        },
    },
    [46578] = {
        p = "Enchanting",
        skill = 350,
        item = 35498,
        q = "Rare",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [46594] = {
        p = "Enchanting",
        skill = 360,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Honored: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46597] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 35501,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46601] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 35503,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46684] = {
        p = "Cooking",
        skill = 250,
        item = 35563,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Malygen (Felwood 62.3, 25.6)",
                "Bale (Felwood 34.8, 53.1)",
            } },
        },
    },
    [46688] = {
        p = "Cooking",
        skill = 250,
        item = 35565,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Malygen (Felwood 62.3, 25.6)",
                "Bale (Felwood 34.8, 53.1)",
            } },
        },
    },
    [46697] = {
        p = "Engineering",
        skill = 355,
        item = 35581,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Mechano-Lord Capacitus (The Mechanar)",
            } },
        },
    },
    [46775] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35693,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46776] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35694,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46777] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35700,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46778] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35702,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46779] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35703,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [46803] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 35707,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [47046] = {
        p = "Alchemy",
        skill = 375,
        item = 35748,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [47048] = {
        p = "Alchemy",
        skill = 375,
        item = 35749,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [47049] = {
        p = "Alchemy",
        skill = 375,
        item = 35750,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [47050] = {
        p = "Alchemy",
        skill = 375,
        item = 35751,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
            } },
        },
    },
    [47051] = {
        p = "Enchanting",
        skill = 375,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Priestess Delrissa (Magisters' Terrace)",
            } },
        },
    },
    [47053] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35759,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [47054] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35758,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
        },
    },
    [47055] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35760,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [47056] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 35761,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Revered: Eldara Dawnrunner (Isle of Quel'Danas 47.1, 30)",
                "Shattered Sun Offensive - Revered: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Revered: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
            { t = "Reputation Vendor", d = {
                "The Scale of the Sands - Honored: Indormi (Hyjal Summit)",
            } },
        },
    },
    [47280] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 35945,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [47672] = {
        p = "Enchanting",
        skill = 430,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [47766] = {
        p = "Enchanting",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [47898] = {
        p = "Enchanting",
        skill = 430,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [47899] = {
        p = "Enchanting",
        skill = 440,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [47900] = {
        p = "Enchanting",
        skill = 425,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [47901] = {
        p = "Enchanting",
        skill = 440,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [48114] = {
        p = "Inscription",
        skill = 1,
        item = 955,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [48116] = {
        p = "Inscription",
        skill = 1,
        item = 1181,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [48121] = {
        p = "Inscription",
        skill = 100,
        item = 40924,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [48247] = {
        p = "Inscription",
        skill = 110,
        item = 37168,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [48248] = {
        p = "Inscription",
        skill = 35,
        item = 37118,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [48789] = {
        p = "Jewelcrafting",
        skill = 375,
        item = 37503,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Shattered Sun Offensive - Exalted: Shaani (Isle of Quel'Danas 51.5, 32.6)",
                "Shattered Sun Offensive - Exalted: Ontuvo (Shattrath City 48.7, 41.3)",
            } },
        },
    },
    [49252] = {
        p = "Mining",
        skill = 350,
        item = 36916,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [49258] = {
        p = "Mining",
        skill = 400,
        item = 36913,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [49677] = {
        p = "Tailoring",
        skill = 250,
        item = 6836,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Haughty Modiste (Tanaris 66.5, 22.3)",
            } },
        },
    },
    [50194] = {
        p = "Tailoring",
        skill = 375,
        item = 38225,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Sporeggar - Revered: Mycah (Zangarmarsh 17.9, 51.2)",
            } },
        },
    },
    [50598] = {
        p = "Inscription",
        skill = 75,
        item = 2290,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50599] = {
        p = "Inscription",
        skill = 165,
        item = 4419,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50600] = {
        p = "Inscription",
        skill = 215,
        item = 10308,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50601] = {
        p = "Inscription",
        skill = 260,
        item = 27499,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50602] = {
        p = "Inscription",
        skill = 310,
        item = 33458,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50603] = {
        p = "Inscription",
        skill = 360,
        item = 37091,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50604] = {
        p = "Inscription",
        skill = 410,
        item = 37092,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50605] = {
        p = "Inscription",
        skill = 75,
        item = 1712,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50606] = {
        p = "Inscription",
        skill = 160,
        item = 4424,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50607] = {
        p = "Inscription",
        skill = 210,
        item = 10306,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50608] = {
        p = "Inscription",
        skill = 255,
        item = 27501,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50609] = {
        p = "Inscription",
        skill = 295,
        item = 33460,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50610] = {
        p = "Inscription",
        skill = 355,
        item = 37097,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50611] = {
        p = "Inscription",
        skill = 405,
        item = 37098,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50612] = {
        p = "Inscription",
        skill = 75,
        item = 1711,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50614] = {
        p = "Inscription",
        skill = 155,
        item = 4422,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50616] = {
        p = "Inscription",
        skill = 205,
        item = 10307,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50617] = {
        p = "Inscription",
        skill = 250,
        item = 27502,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50618] = {
        p = "Inscription",
        skill = 290,
        item = 33461,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50619] = {
        p = "Inscription",
        skill = 350,
        item = 37093,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50620] = {
        p = "Inscription",
        skill = 400,
        item = 37094,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50644] = {
        p = "Tailoring",
        skill = 250,
        item = 38277,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Haughty Modiste (Tanaris 66.5, 22.3)",
            } },
        },
    },
    [50647] = {
        p = "Tailoring",
        skill = 245,
        item = 38278,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Haughty Modiste (Tanaris 66.5, 22.3)",
            } },
        },
    },
    [50936] = {
        p = "Leatherworking",
        skill = 390,
        item = 38425,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50938] = {
        p = "Leatherworking",
        skill = 375,
        item = 38408,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50939] = {
        p = "Leatherworking",
        skill = 370,
        item = 38410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50940] = {
        p = "Leatherworking",
        skill = 380,
        item = 38411,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50941] = {
        p = "Leatherworking",
        skill = 370,
        item = 38409,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50942] = {
        p = "Leatherworking",
        skill = 375,
        item = 38407,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50943] = {
        p = "Leatherworking",
        skill = 380,
        item = 38406,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50944] = {
        p = "Leatherworking",
        skill = 370,
        item = 38400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50945] = {
        p = "Leatherworking",
        skill = 375,
        item = 38401,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50946] = {
        p = "Leatherworking",
        skill = 380,
        item = 38402,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50947] = {
        p = "Leatherworking",
        skill = 375,
        item = 38403,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50948] = {
        p = "Leatherworking",
        skill = 370,
        item = 38404,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50949] = {
        p = "Leatherworking",
        skill = 380,
        item = 38405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50950] = {
        p = "Leatherworking",
        skill = 375,
        item = 38414,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50951] = {
        p = "Leatherworking",
        skill = 370,
        item = 38416,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50952] = {
        p = "Leatherworking",
        skill = 375,
        item = 38424,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50953] = {
        p = "Leatherworking",
        skill = 380,
        item = 38415,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50954] = {
        p = "Leatherworking",
        skill = 380,
        item = 38413,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50955] = {
        p = "Leatherworking",
        skill = 370,
        item = 38412,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50956] = {
        p = "Leatherworking",
        skill = 375,
        item = 38420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50957] = {
        p = "Leatherworking",
        skill = 370,
        item = 38422,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50958] = {
        p = "Leatherworking",
        skill = 380,
        item = 38417,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50959] = {
        p = "Leatherworking",
        skill = 370,
        item = 38421,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50960] = {
        p = "Leatherworking",
        skill = 380,
        item = 38419,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50961] = {
        p = "Leatherworking",
        skill = 375,
        item = 38418,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50962] = {
        p = "Leatherworking",
        skill = 350,
        item = 38375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50963] = {
        p = "Leatherworking",
        skill = 395,
        item = 38376,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50964] = {
        p = "Leatherworking",
        skill = 405,
        item = 38371,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50965] = {
        p = "Leatherworking",
        skill = 425,
        item = 38373,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50966] = {
        p = "Leatherworking",
        skill = 400,
        item = 38372,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50967] = {
        p = "Leatherworking",
        skill = 425,
        item = 38374,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [50970] = {
        p = "Leatherworking",
        skill = 415,
        item = 38399,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Kalu'ak - Revered: Tanaika (Howling Fjord 25.5, 58.7)",
                "The Kalu'ak - Revered: Sairuk (Dragonblight 48.5, 75.7)",
            } },
        },
    },
    [50971] = {
        p = "Leatherworking",
        skill = 415,
        item = 38347,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sons of Hodir - Honored: Lillehoff (The Storm Peaks 66.2, 61.4)",
            } },
        },
    },
    [51568] = {
        p = "Leatherworking",
        skill = 400,
        item = 38590,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [51569] = {
        p = "Leatherworking",
        skill = 395,
        item = 38591,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [51570] = {
        p = "Leatherworking",
        skill = 395,
        item = 38592,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [51571] = {
        p = "Leatherworking",
        skill = 385,
        item = 38433,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [51572] = {
        p = "Leatherworking",
        skill = 385,
        item = 38437,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52567] = {
        p = "Blacksmithing",
        skill = 370,
        item = 39086,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52568] = {
        p = "Blacksmithing",
        skill = 350,
        item = 39087,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52569] = {
        p = "Blacksmithing",
        skill = 350,
        item = 39088,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52570] = {
        p = "Blacksmithing",
        skill = 375,
        item = 39085,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52571] = {
        p = "Blacksmithing",
        skill = 370,
        item = 39084,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52572] = {
        p = "Blacksmithing",
        skill = 360,
        item = 39083,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52733] = {
        p = "Leatherworking",
        skill = 375,
        item = 32399,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Ashtongue Deathsworn - Friendly: Okuno (Black Temple)",
            } },
        },
    },
    [52738] = {
        p = "Inscription",
        skill = 1,
        item = 37101,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Learned by default when learning the profession.",
            } },
        },
    },
    [52739] = {
        p = "Inscription",
        skill = 35,
        item = 38682,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52840] = {
        p = "Inscription",
        skill = 75,
        item = 39349,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [52843] = {
        p = "Inscription",
        skill = 35,
        item = 39469,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53056] = {
        p = "Cooking",
        skill = 375,
        item = 39520,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #13571 (Dalaran)",
            } },
            { t = "Special", d = {
                "From a NPC in Dalaran sewers after doing The Taste Test",
            } },
        },
    },
    [53281] = {
        p = "Engineering",
        skill = 350,
        item = 39690,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53323] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53331] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53341] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53342] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53343] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53344] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53462] = {
        p = "Inscription",
        skill = 75,
        item = 39774,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53771] = {
        p = "Alchemy",
        skill = 405,
        item = 35627,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53773] = {
        p = "Alchemy",
        skill = 405,
        item = 36860,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53774] = {
        p = "Alchemy",
        skill = 405,
        item = 35622,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53775] = {
        p = "Alchemy",
        skill = 405,
        item = 35625,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53776] = {
        p = "Alchemy",
        skill = 405,
        item = 35622,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53777] = {
        p = "Alchemy",
        skill = 405,
        item = 35624,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53779] = {
        p = "Alchemy",
        skill = 405,
        item = 35624,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53780] = {
        p = "Alchemy",
        skill = 405,
        item = 35625,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53781] = {
        p = "Alchemy",
        skill = 405,
        item = 35623,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53782] = {
        p = "Alchemy",
        skill = 405,
        item = 35627,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53783] = {
        p = "Alchemy",
        skill = 405,
        item = 35623,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53784] = {
        p = "Alchemy",
        skill = 405,
        item = 36860,
        q = "Uncommon",
        sources = {
            { t = "Special", d = {
                "Discovered by doing transmutes using Northrend or higher ingredients (transmute tooltip mentions that there is a chance to discovery something).",
            } },
        },
    },
    [53812] = {
        p = "Alchemy",
        skill = 375,
        item = 40195,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53830] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 39996,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53831] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39900,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53832] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39905,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53834] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39911,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53835] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39906,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53836] = {
        p = "Alchemy",
        skill = 405,
        item = 33447,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53837] = {
        p = "Alchemy",
        skill = 410,
        item = 33448,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53838] = {
        p = "Alchemy",
        skill = 350,
        item = 39671,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53839] = {
        p = "Alchemy",
        skill = 360,
        item = 40067,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53840] = {
        p = "Alchemy",
        skill = 395,
        item = 39666,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53841] = {
        p = "Alchemy",
        skill = 355,
        item = 40068,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53842] = {
        p = "Alchemy",
        skill = 365,
        item = 40070,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53843] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 39907,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53844] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39908,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53845] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39909,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53847] = {
        p = "Alchemy",
        skill = 385,
        item = 40072,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53848] = {
        p = "Alchemy",
        skill = 375,
        item = 40076,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53852] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39912,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53853] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39914,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53854] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39915,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53855] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39916,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53856] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39918,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53857] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39917,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53859] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39934,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53860] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39935,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53861] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39942,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53862] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39936,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53863] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39941,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53864] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39943,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53865] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39945,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53866] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39937,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53867] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39944,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53868] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 39938,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53869] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39939,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Kalu'ak - Honored: Tanaika (Howling Fjord 25.5, 58.7)",
                "The Kalu'ak - Honored: Sairuk (Dragonblight 48.5, 75.7)",
            } },
        },
    },
    [53870] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39933,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53871] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39940,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53872] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39947,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53873] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39948,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53874] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39949,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53875] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39950,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53876] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39951,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53877] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39952,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Knights of the Ebon Blade - Friendly: Duchess Mynx (Icecrown 43.5, 20.6)",
            } },
        },
    },
    [53878] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39953,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53879] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39954,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53880] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53881] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39946,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53882] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39956,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53883] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39957,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53884] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39958,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53885] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39959,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "Frenzyheart Tribe - Friendly: Tanak (Sholazar Basin 55.1, 69.1)",
            } },
        },
    },
    [53886] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39960,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53887] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39961,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53888] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39962,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53889] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39963,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53890] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53891] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 39965,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53892] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39966,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53893] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39967,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53894] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39968,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53895] = {
        p = "Alchemy",
        skill = 400,
        item = 40077,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [53898] = {
        p = "Alchemy",
        skill = 390,
        item = 40078,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53899] = {
        p = "Alchemy",
        skill = 375,
        item = 40079,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53900] = {
        p = "Alchemy",
        skill = 380,
        item = 40081,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53901] = {
        p = "Alchemy",
        skill = 435,
        item = 40082,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53902] = {
        p = "Alchemy",
        skill = 435,
        item = 40083,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53903] = {
        p = "Alchemy",
        skill = 435,
        item = 40084,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53904] = {
        p = "Alchemy",
        skill = 400,
        item = 40087,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [53905] = {
        p = "Alchemy",
        skill = 395,
        item = 40093,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53916] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39974,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53917] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39975,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Oracles - Friendly: Geen (Sholazar Basin 54.5, 56.2)",
            } },
        },
    },
    [53918] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39976,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53919] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39977,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53920] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39978,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53921] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39979,
        q = "Uncommon",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Kalu'ak - Friendly: Tanaika (Howling Fjord 25.5, 58.7)",
                "The Kalu'ak - Friendly: Sairuk (Dragonblight 48.5, 75.7)",
            } },
        },
    },
    [53922] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39980,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53923] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39981,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53924] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39982,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53925] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39983,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53926] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39984,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53927] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39985,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53928] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39986,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53929] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39988,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53930] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39989,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53931] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39990,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53932] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39991,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53933] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39992,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53934] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39919,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53936] = {
        p = "Alchemy",
        skill = 400,
        item = 40213,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cult Researcher (Icecrown 50.7, 30.9)",
                "Frostbrood Spawn (Icecrown 75.3, 43.4)",
            } },
        },
    },
    [53937] = {
        p = "Alchemy",
        skill = 400,
        item = 40215,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Damned Apothecary (Icecrown 49.8, 32.7)",
            } },
        },
    },
    [53938] = {
        p = "Alchemy",
        skill = 400,
        item = 40217,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cultist Shard Watcher (Icecrown 48.1, 67.9)",
            } },
        },
    },
    [53939] = {
        p = "Alchemy",
        skill = 400,
        item = 40214,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Skeletal Runesmith (Icecrown 60, 73.1)",
            } },
        },
    },
    [53940] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39920,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53941] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39927,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53942] = {
        p = "Alchemy",
        skill = 400,
        item = 40216,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Cult Alchemist (Icecrown 49.5, 33.1)",
            } },
        },
    },
    [53943] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39927,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Captain O'Neal (Stormwind City 75.7, 66.6)",
                "Lady Palanseer (Orgrimmar 37, 64.9)",
            } },
        },
    },
    [53945] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 39997,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53946] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 39998,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kirin Tor - Exalted: Archmage Alvareaux (Dalaran 25.5, 47.4)",
            } },
        },
    },
    [53947] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 39999,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53948] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40000,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53949] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40001,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53950] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40002,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Nascent Val'kyr (The Storm Peaks 27.1, 60)",
            } },
        },
    },
    [53951] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40003,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Herald Volazj (Ahn'kahet: The Old Kingdom)",
            } },
        },
    },
    [53952] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40008,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53953] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40009,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53954] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40010,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53955] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40011,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53956] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40012,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53957] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40013,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sons of Hodir - Exalted: Lillehoff (The Storm Peaks 66.2, 61.4)",
            } },
        },
    },
    [53958] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40014,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53959] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40015,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cyanigosa (The Violet Hold)",
            } },
        },
    },
    [53960] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40016,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53961] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40017,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53962] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40022,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53963] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40023,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53964] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40024,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53965] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40025,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Knights of the Ebon Blade - Exalted: Duchess Mynx (Icecrown 43.5, 20.6)",
            } },
        },
    },
    [53966] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40026,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53967] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40027,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53968] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40028,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53969] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40029,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53970] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40030,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Anub'arak (Azjol-Nerub)",
            } },
        },
    },
    [53971] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40031,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53972] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40032,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Stormforged Ambusher (The Storm Peaks 70.3, 57.5)",
                "Stormforged Champion (The Storm Peaks 26.1, 47.5)",
                "Stormforged Infiltrator (The Storm Peaks 58.5, 63.2)",
                "Stormforged Artificer (The Storm Peaks 31.5, 44.2)",
            } },
        },
    },
    [53973] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40033,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53974] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40034,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Crusade - Revered: Veteran Crusader Aliocha Segard (Icecrown 87.6, 75.6)",
            } },
        },
    },
    [53975] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40037,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53976] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40038,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53977] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40039,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53978] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40040,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53979] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40043,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Keristrasza (The Nexus)",
            } },
        },
    },
    [53980] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40044,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53981] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40045,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53982] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40046,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Sjonnir The Ironshaper (Halls of Stone)",
            } },
        },
    },
    [53983] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40047,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53984] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40048,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53985] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40049,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53986] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40050,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53987] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40051,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53988] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40052,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Knights of the Ebon Blade - Revered: Duchess Mynx (Icecrown 43.5, 20.6)",
            } },
        },
    },
    [53989] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40053,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [53990] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40054,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [53991] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40055,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53992] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40056,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [53993] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40057,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Wyrmrest Accord - Exalted: Cielstrasza (Dragonblight 59.9, 53.1)",
            } },
        },
    },
    [53994] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40058,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Stoic Mammoth (The Storm Peaks 54.8, 64.9)",
                "Shattertusk Mammoth (Sholazar Basin 53.5, 24.4)",
                "Ironwool Mammoth (The Storm Peaks 36, 83.5)",
                "Enraged Mammoth (Zul'Drak 72, 41.1)",
                "Plains Mammoth (The Storm Peaks 66.1, 45.6)",
            } },
        },
    },
    [53995] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40085,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "The Prophet Tharon'ja (Drak'Tharon Keep)",
            } },
        },
    },
    [53996] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40086,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Frenzyheart Tribe - Revered: Tanak (Sholazar Basin 55.1, 69.1)",
            } },
        },
    },
    [53997] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40088,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [53998] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40089,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54000] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40090,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [54001] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40091,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54002] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40092,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54003] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40095,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [54004] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40099,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [54005] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40102,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [54006] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40104,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54007] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40094,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54008] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40096,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Oracles - Revered: Geen (Sholazar Basin 54.5, 56.2)",
            } },
        },
    },
    [54009] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40100,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54010] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40103,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [54011] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40105,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [54012] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40098,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Frostfeather Screecher (The Storm Peaks 33.5, 65.5)",
                "Frostfeather Witch (The Storm Peaks 33, 66.8)",
            } },
        },
    },
    [54013] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40101,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [54014] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40106,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [54017] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 39910,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54019] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40041,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Ingvar the Plunderer (Utgarde Keep)",
            } },
        },
    },
    [54023] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 40059,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [54213] = {
        p = "Alchemy",
        skill = 435,
        item = 40404,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54218] = {
        p = "Alchemy",
        skill = 385,
        item = 40073,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54220] = {
        p = "Alchemy",
        skill = 400,
        item = 40097,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [54221] = {
        p = "Alchemy",
        skill = 400,
        item = 40211,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [54222] = {
        p = "Alchemy",
        skill = 400,
        item = 40212,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [54353] = {
        p = "Engineering",
        skill = 400,
        item = 39688,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54446] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54447] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54550] = {
        p = "Blacksmithing",
        skill = 360,
        item = 40668,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54551] = {
        p = "Blacksmithing",
        skill = 395,
        item = 40669,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54552] = {
        p = "Blacksmithing",
        skill = 400,
        item = 40671,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54553] = {
        p = "Blacksmithing",
        skill = 400,
        item = 40672,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54554] = {
        p = "Blacksmithing",
        skill = 395,
        item = 40674,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54555] = {
        p = "Blacksmithing",
        skill = 405,
        item = 40673,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54556] = {
        p = "Blacksmithing",
        skill = 405,
        item = 40675,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54557] = {
        p = "Blacksmithing",
        skill = 390,
        item = 40670,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54736] = {
        p = "Engineering",
        skill = 390,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54793] = {
        p = "Engineering",
        skill = 380,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54917] = {
        p = "Blacksmithing",
        skill = 375,
        item = 40942,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54918] = {
        p = "Blacksmithing",
        skill = 380,
        item = 40949,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54941] = {
        p = "Blacksmithing",
        skill = 385,
        item = 40950,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54944] = {
        p = "Blacksmithing",
        skill = 385,
        item = 40951,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54945] = {
        p = "Blacksmithing",
        skill = 390,
        item = 40952,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54946] = {
        p = "Blacksmithing",
        skill = 395,
        item = 40953,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54947] = {
        p = "Blacksmithing",
        skill = 395,
        item = 40943,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54948] = {
        p = "Blacksmithing",
        skill = 400,
        item = 40954,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54949] = {
        p = "Blacksmithing",
        skill = 400,
        item = 40955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54978] = {
        p = "Blacksmithing",
        skill = 375,
        item = 40956,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Onslaught Mason (Dragonblight 85.8, 36)",
            } },
        },
    },
    [54979] = {
        p = "Blacksmithing",
        skill = 375,
        item = 40957,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Iron Rune-Shaper (Grizzly Hills 67.8, 16.3)",
            } },
        },
    },
    [54980] = {
        p = "Blacksmithing",
        skill = 375,
        item = 40958,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Gundrak Savage (Zul'Drak 66.8, 42.4)",
            } },
        },
    },
    [54981] = {
        p = "Blacksmithing",
        skill = 375,
        item = 40959,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Venture Co. Excavator (Sholazar Basin 35.8, 45.5)",
            } },
        },
    },
    [54998] = {
        p = "Engineering",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [54999] = {
        p = "Engineering",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55002] = {
        p = "Engineering",
        skill = 380,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55013] = {
        p = "Blacksmithing",
        skill = 390,
        item = 41117,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55014] = {
        p = "Blacksmithing",
        skill = 410,
        item = 41113,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55015] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41114,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55016] = {
        p = "Engineering",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55017] = {
        p = "Blacksmithing",
        skill = 410,
        item = 41116,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55055] = {
        p = "Blacksmithing",
        skill = 395,
        item = 41126,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55056] = {
        p = "Blacksmithing",
        skill = 400,
        item = 41127,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55057] = {
        p = "Blacksmithing",
        skill = 405,
        item = 41128,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55058] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41129,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55174] = {
        p = "Blacksmithing",
        skill = 390,
        item = 41181,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55177] = {
        p = "Blacksmithing",
        skill = 395,
        item = 41182,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55179] = {
        p = "Blacksmithing",
        skill = 400,
        item = 41183,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55181] = {
        p = "Blacksmithing",
        skill = 405,
        item = 41184,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55182] = {
        p = "Blacksmithing",
        skill = 410,
        item = 41185,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55183] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41186,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55184] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41187,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55185] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41188,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55186] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41189,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55187] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41190,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55199] = {
        p = "Leatherworking",
        skill = 395,
        item = 41238,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55200] = {
        p = "Blacksmithing",
        skill = 380,
        item = 41239,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55201] = {
        p = "Blacksmithing",
        skill = 380,
        item = 41240,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55202] = {
        p = "Blacksmithing",
        skill = 385,
        item = 41241,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55203] = {
        p = "Blacksmithing",
        skill = 385,
        item = 41242,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55204] = {
        p = "Blacksmithing",
        skill = 390,
        item = 41243,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55206] = {
        p = "Blacksmithing",
        skill = 405,
        item = 41245,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55208] = {
        p = "Mining",
        skill = 450,
        item = 37663,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55211] = {
        p = "Mining",
        skill = 450,
        item = 41163,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55252] = {
        p = "Engineering",
        skill = 415,
        item = 40769,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #12889 (The Storm Peaks 37.7, 46.5)",
            } },
        },
    },
    [55298] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41355,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55300] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41356,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55301] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41357,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55302] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41344,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55303] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41345,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55304] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41346,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55305] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41354,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55306] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41351,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55307] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41352,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55308] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41348,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55309] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41349,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55310] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41347,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55311] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41353,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55312] = {
        p = "Blacksmithing",
        skill = 425,
        item = 41350,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55369] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41257,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55370] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41383,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55371] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41384,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55372] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41386,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55373] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41387,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55374] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41388,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55375] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41391,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55376] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41392,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55377] = {
        p = "Blacksmithing",
        skill = 440,
        item = 41394,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55384] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41377,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55386] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55387] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41378,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [55388] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41379,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [55389] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41285,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55390] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41307,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55392] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41333,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55393] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41335,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Stone Guard Mukar (Wintergrasp 51.7, 17.5)",
                "Knight Dameron (Wintergrasp 51.7, 17.5)",
                "Morgan Day (Wintergrasp 49, 17.1)",
            } },
        },
    },
    [55394] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41339,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55395] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41400,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55396] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41401,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55397] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41395,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Ley-Guardian Eregos (The Oculus)",
            } },
        },
    },
    [55398] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41396,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Loken (Halls of Lightning)",
            } },
        },
    },
    [55399] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41397,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55400] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41398,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55401] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41380,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "King Ymiron (Utgarde Pinnacle)",
            } },
        },
    },
    [55402] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41381,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55403] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41382,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55404] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41385,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55405] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41389,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55407] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 41376,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [55628] = {
        p = "Blacksmithing",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55641] = {
        p = "Blacksmithing",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55642] = {
        p = "Tailoring",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55656] = {
        p = "Blacksmithing",
        skill = 415,
        item = 41611,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55732] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41745,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55769] = {
        p = "Tailoring",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55777] = {
        p = "Tailoring",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55834] = {
        p = "Blacksmithing",
        skill = 360,
        item = 41974,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55835] = {
        p = "Blacksmithing",
        skill = 370,
        item = 41975,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55839] = {
        p = "Blacksmithing",
        skill = 420,
        item = 41976,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55898] = {
        p = "Tailoring",
        skill = 360,
        item = 41509,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55899] = {
        p = "Tailoring",
        skill = 350,
        item = 41510,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55900] = {
        p = "Tailoring",
        skill = 400,
        item = 41511,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55901] = {
        p = "Tailoring",
        skill = 395,
        item = 41548,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55902] = {
        p = "Tailoring",
        skill = 350,
        item = 41513,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55903] = {
        p = "Tailoring",
        skill = 360,
        item = 41515,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55904] = {
        p = "Tailoring",
        skill = 360,
        item = 44211,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55906] = {
        p = "Tailoring",
        skill = 375,
        item = 41520,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55907] = {
        p = "Tailoring",
        skill = 380,
        item = 41521,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55908] = {
        p = "Tailoring",
        skill = 370,
        item = 41522,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55910] = {
        p = "Tailoring",
        skill = 385,
        item = 41523,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55911] = {
        p = "Tailoring",
        skill = 390,
        item = 41525,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55913] = {
        p = "Tailoring",
        skill = 385,
        item = 41528,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55914] = {
        p = "Tailoring",
        skill = 395,
        item = 41543,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55919] = {
        p = "Tailoring",
        skill = 395,
        item = 41546,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55920] = {
        p = "Tailoring",
        skill = 400,
        item = 41551,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55921] = {
        p = "Tailoring",
        skill = 405,
        item = 41549,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55922] = {
        p = "Tailoring",
        skill = 405,
        item = 41545,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55923] = {
        p = "Tailoring",
        skill = 410,
        item = 41550,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55924] = {
        p = "Tailoring",
        skill = 410,
        item = 41544,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55925] = {
        p = "Tailoring",
        skill = 415,
        item = 41553,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55941] = {
        p = "Tailoring",
        skill = 420,
        item = 41554,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55943] = {
        p = "Tailoring",
        skill = 415,
        item = 41555,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55993] = {
        p = "Tailoring",
        skill = 400,
        item = 41248,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55994] = {
        p = "Tailoring",
        skill = 400,
        item = 41249,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55995] = {
        p = "Tailoring",
        skill = 400,
        item = 41251,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [55996] = {
        p = "Tailoring",
        skill = 400,
        item = 41250,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55997] = {
        p = "Tailoring",
        skill = 400,
        item = 41252,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55998] = {
        p = "Tailoring",
        skill = 400,
        item = 41253,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [55999] = {
        p = "Tailoring",
        skill = 400,
        item = 41254,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [56000] = {
        p = "Tailoring",
        skill = 400,
        item = 41255,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56001] = {
        p = "Tailoring",
        skill = 415,
        item = 41594,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56002] = {
        p = "Tailoring",
        skill = 415,
        item = 41593,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56003] = {
        p = "Tailoring",
        skill = 415,
        item = 41595,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56004] = {
        p = "Tailoring",
        skill = 435,
        item = 41597,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Knights of the Ebon Blade - Revered: Duchess Mynx (Icecrown 43.5, 20.6)",
            } },
        },
    },
    [56005] = {
        p = "Tailoring",
        skill = 445,
        item = 41600,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Sons of Hodir - Exalted: Lillehoff (The Storm Peaks 66.2, 61.4)",
            } },
        },
    },
    [56006] = {
        p = "Tailoring",
        skill = 440,
        item = 41598,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Wyrmrest Accord - Revered: Cielstrasza (Dragonblight 59.9, 53.1)",
            } },
        },
    },
    [56007] = {
        p = "Tailoring",
        skill = 410,
        item = 41599,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56008] = {
        p = "Tailoring",
        skill = 400,
        item = 41601,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56009] = {
        p = "Tailoring",
        skill = 430,
        item = 41602,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Argent Crusade - Exalted: Veteran Crusader Aliocha Segard (Icecrown 87.6, 75.6)",
            } },
        },
    },
    [56010] = {
        p = "Tailoring",
        skill = 400,
        item = 41603,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56011] = {
        p = "Tailoring",
        skill = 430,
        item = 41604,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "Kirin Tor - Exalted: Archmage Alvareaux (Dalaran 25.5, 47.4)",
            } },
        },
    },
    [56014] = {
        p = "Tailoring",
        skill = 390,
        item = 41607,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56015] = {
        p = "Tailoring",
        skill = 395,
        item = 41608,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56016] = {
        p = "Tailoring",
        skill = 420,
        item = 41609,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Special", d = {
                "You can train this recipe if you have earned the \"Northrend Dungeonmaster\" achievement",
            } },
        },
    },
    [56017] = {
        p = "Tailoring",
        skill = 420,
        item = 41610,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
            { t = "Special", d = {
                "You can train this recipe if you have earned the \"Loremaster of Northrend\" achievement",
            } },
        },
    },
    [56018] = {
        p = "Tailoring",
        skill = 425,
        item = 41984,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56019] = {
        p = "Tailoring",
        skill = 420,
        item = 41985,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56020] = {
        p = "Tailoring",
        skill = 420,
        item = 41986,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56021] = {
        p = "Tailoring",
        skill = 425,
        item = 42093,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56022] = {
        p = "Tailoring",
        skill = 420,
        item = 42095,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56023] = {
        p = "Tailoring",
        skill = 420,
        item = 42096,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56024] = {
        p = "Tailoring",
        skill = 440,
        item = 42100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56025] = {
        p = "Tailoring",
        skill = 435,
        item = 42103,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56026] = {
        p = "Tailoring",
        skill = 440,
        item = 42101,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56027] = {
        p = "Tailoring",
        skill = 435,
        item = 42111,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56028] = {
        p = "Tailoring",
        skill = 440,
        item = 42102,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56029] = {
        p = "Tailoring",
        skill = 435,
        item = 42113,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56030] = {
        p = "Tailoring",
        skill = 380,
        item = 41519,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56031] = {
        p = "Tailoring",
        skill = 350,
        item = 41512,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56034] = {
        p = "Tailoring",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56039] = {
        p = "Tailoring",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56049] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42142,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56052] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42143,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56053] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42144,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56054] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 36766,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56055] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42151,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56056] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42152,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56074] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42148,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56076] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42153,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56077] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42146,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56079] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42158,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56081] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42154,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56083] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42150,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56084] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42156,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56085] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42149,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56086] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 36767,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56087] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42145,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56088] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42155,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56089] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42157,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56193] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 42336,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56194] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 42337,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56195] = {
        p = "Jewelcrafting",
        skill = 380,
        item = 42338,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56196] = {
        p = "Jewelcrafting",
        skill = 380,
        item = 42339,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56197] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 42340,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56199] = {
        p = "Jewelcrafting",
        skill = 400,
        item = 42341,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56201] = {
        p = "Jewelcrafting",
        skill = 400,
        item = 42395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56202] = {
        p = "Jewelcrafting",
        skill = 400,
        item = 42413,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56203] = {
        p = "Jewelcrafting",
        skill = 400,
        item = 42418,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56205] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 41367,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56206] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 42420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56208] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 42421,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56234] = {
        p = "Blacksmithing",
        skill = 440,
        item = 42435,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56280] = {
        p = "Blacksmithing",
        skill = 410,
        item = 42443,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56349] = {
        p = "Engineering",
        skill = 350,
        item = 39681,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56357] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42500,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56400] = {
        p = "Blacksmithing",
        skill = 440,
        item = 42508,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56459] = {
        p = "Engineering",
        skill = 375,
        item = 40892,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56460] = {
        p = "Engineering",
        skill = 350,
        item = 40771,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56461] = {
        p = "Engineering",
        skill = 375,
        item = 40893,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56462] = {
        p = "Engineering",
        skill = 435,
        item = 40772,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56463] = {
        p = "Engineering",
        skill = 375,
        item = 40536,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56464] = {
        p = "Engineering",
        skill = 375,
        item = 39682,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56465] = {
        p = "Engineering",
        skill = 420,
        item = 41112,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56466] = {
        p = "Engineering",
        skill = 420,
        item = 40767,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56467] = {
        p = "Engineering",
        skill = 420,
        item = 40865,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56468] = {
        p = "Engineering",
        skill = 405,
        item = 41119,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56469] = {
        p = "Engineering",
        skill = 425,
        item = 41121,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56470] = {
        p = "Engineering",
        skill = 425,
        item = 41146,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56471] = {
        p = "Engineering",
        skill = 390,
        item = 39683,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56472] = {
        p = "Engineering",
        skill = 425,
        item = 40768,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56473] = {
        p = "Engineering",
        skill = 425,
        item = 40895,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56474] = {
        p = "Engineering",
        skill = 410,
        item = 44507,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56475] = {
        p = "Engineering",
        skill = 415,
        item = 44506,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56476] = {
        p = "Engineering",
        skill = 410,
        item = 37567,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56477] = {
        p = "Engineering",
        skill = 415,
        item = 42546,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56478] = {
        p = "Engineering",
        skill = 430,
        item = 41167,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56479] = {
        p = "Engineering",
        skill = 450,
        item = 41168,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56480] = {
        p = "Engineering",
        skill = 440,
        item = 42549,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56481] = {
        p = "Engineering",
        skill = 440,
        item = 42550,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56483] = {
        p = "Engineering",
        skill = 440,
        item = 42552,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56484] = {
        p = "Engineering",
        skill = 440,
        item = 42553,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56486] = {
        p = "Engineering",
        skill = 440,
        item = 42554,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56487] = {
        p = "Engineering",
        skill = 440,
        item = 42555,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56496] = {
        p = "Jewelcrafting",
        skill = 430,
        item = 42642,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56497] = {
        p = "Jewelcrafting",
        skill = 430,
        item = 42643,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56498] = {
        p = "Jewelcrafting",
        skill = 430,
        item = 42644,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56499] = {
        p = "Jewelcrafting",
        skill = 440,
        item = 42645,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56500] = {
        p = "Jewelcrafting",
        skill = 440,
        item = 42646,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56501] = {
        p = "Jewelcrafting",
        skill = 440,
        item = 42647,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [56514] = {
        p = "Engineering",
        skill = 425,
        item = 42641,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56519] = {
        p = "Alchemy",
        skill = 400,
        item = 40109,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [56530] = {
        p = "Jewelcrafting",
        skill = 360,
        item = 42701,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56531] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 42702,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56549] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42723,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56550] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42727,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56551] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42729,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56552] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42730,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56553] = {
        p = "Blacksmithing",
        skill = 420,
        item = 42724,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56554] = {
        p = "Blacksmithing",
        skill = 425,
        item = 42726,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56555] = {
        p = "Blacksmithing",
        skill = 425,
        item = 42725,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56556] = {
        p = "Blacksmithing",
        skill = 425,
        item = 42728,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56574] = {
        p = "Engineering",
        skill = 440,
        item = 42551,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56943] = {
        p = "Inscription",
        skill = 350,
        item = 40896,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56944] = {
        p = "Inscription",
        skill = 385,
        item = 40899,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56945] = {
        p = "Inscription",
        skill = 115,
        item = 40914,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56946] = {
        p = "Inscription",
        skill = 385,
        item = 40920,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56947] = {
        p = "Inscription",
        skill = 385,
        item = 40908,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56948] = {
        p = "Inscription",
        skill = 150,
        item = 40919,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56949] = {
        p = "Inscription",
        skill = 385,
        item = 40915,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56950] = {
        p = "Inscription",
        skill = 385,
        item = 40900,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56951] = {
        p = "Inscription",
        skill = 130,
        item = 40923,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56952] = {
        p = "Inscription",
        skill = 310,
        item = 40903,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56953] = {
        p = "Inscription",
        skill = 170,
        item = 40909,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56954] = {
        p = "Inscription",
        skill = 385,
        item = 40912,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56955] = {
        p = "Inscription",
        skill = 80,
        item = 40913,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56956] = {
        p = "Inscription",
        skill = 200,
        item = 40902,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56957] = {
        p = "Inscription",
        skill = 260,
        item = 40901,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56958] = {
        p = "Inscription",
        skill = 385,
        item = 40921,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56959] = {
        p = "Inscription",
        skill = 220,
        item = 40916,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56960] = {
        p = "Inscription",
        skill = 385,
        item = 40906,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56961] = {
        p = "Inscription",
        skill = 90,
        item = 40897,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56963] = {
        p = "Inscription",
        skill = 85,
        item = 40922,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56965] = {
        p = "Inscription",
        skill = 310,
        item = 44955,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [56968] = {
        p = "Inscription",
        skill = 100,
        item = 42734,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56971] = {
        p = "Inscription",
        skill = 115,
        item = 42735,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56972] = {
        p = "Inscription",
        skill = 335,
        item = 42736,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56973] = {
        p = "Inscription",
        skill = 130,
        item = 42737,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56974] = {
        p = "Inscription",
        skill = 155,
        item = 42738,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56975] = {
        p = "Inscription",
        skill = 385,
        item = 42739,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56976] = {
        p = "Inscription",
        skill = 80,
        item = 42741,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56977] = {
        p = "Inscription",
        skill = 385,
        item = 42742,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56978] = {
        p = "Inscription",
        skill = 90,
        item = 42743,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56979] = {
        p = "Inscription",
        skill = 225,
        item = 42744,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56980] = {
        p = "Inscription",
        skill = 375,
        item = 42745,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56981] = {
        p = "Inscription",
        skill = 175,
        item = 42746,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56982] = {
        p = "Inscription",
        skill = 205,
        item = 42747,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56983] = {
        p = "Inscription",
        skill = 385,
        item = 42748,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56984] = {
        p = "Inscription",
        skill = 325,
        item = 42749,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56985] = {
        p = "Inscription",
        skill = 280,
        item = 42750,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56986] = {
        p = "Inscription",
        skill = 385,
        item = 42751,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56987] = {
        p = "Inscription",
        skill = 400,
        item = 42752,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56988] = {
        p = "Inscription",
        skill = 385,
        item = 42753,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56989] = {
        p = "Inscription",
        skill = 385,
        item = 42754,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56990] = {
        p = "Inscription",
        skill = 310,
        item = 44920,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [56991] = {
        p = "Inscription",
        skill = 315,
        item = 44955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56994] = {
        p = "Inscription",
        skill = 175,
        item = 42897,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56995] = {
        p = "Inscription",
        skill = 100,
        item = 42898,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56996] = {
        p = "Inscription",
        skill = 385,
        item = 42899,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56997] = {
        p = "Inscription",
        skill = 115,
        item = 42900,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [56998] = {
        p = "Inscription",
        skill = 385,
        item = 42901,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [56999] = {
        p = "Inscription",
        skill = 385,
        item = 42902,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57000] = {
        p = "Inscription",
        skill = 200,
        item = 42903,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57001] = {
        p = "Inscription",
        skill = 225,
        item = 42904,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57002] = {
        p = "Inscription",
        skill = 260,
        item = 42905,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57003] = {
        p = "Inscription",
        skill = 350,
        item = 42906,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57004] = {
        p = "Inscription",
        skill = 80,
        item = 42907,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57005] = {
        p = "Inscription",
        skill = 130,
        item = 42908,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57006] = {
        p = "Inscription",
        skill = 375,
        item = 42909,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57007] = {
        p = "Inscription",
        skill = 150,
        item = 42910,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57008] = {
        p = "Inscription",
        skill = 315,
        item = 42911,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57009] = {
        p = "Inscription",
        skill = 90,
        item = 42912,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57010] = {
        p = "Inscription",
        skill = 385,
        item = 42913,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57011] = {
        p = "Inscription",
        skill = 385,
        item = 42914,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57012] = {
        p = "Inscription",
        skill = 385,
        item = 42915,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57013] = {
        p = "Inscription",
        skill = 385,
        item = 42916,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57014] = {
        p = "Inscription",
        skill = 385,
        item = 42917,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57019] = {
        p = "Inscription",
        skill = 385,
        item = 41101,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57020] = {
        p = "Inscription",
        skill = 180,
        item = 41104,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57021] = {
        p = "Inscription",
        skill = 385,
        item = 41107,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57022] = {
        p = "Inscription",
        skill = 80,
        item = 41096,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57023] = {
        p = "Inscription",
        skill = 205,
        item = 41099,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57024] = {
        p = "Inscription",
        skill = 230,
        item = 41098,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57025] = {
        p = "Inscription",
        skill = 265,
        item = 41103,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57026] = {
        p = "Inscription",
        skill = 300,
        item = 41105,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57027] = {
        p = "Inscription",
        skill = 90,
        item = 41095,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57028] = {
        p = "Inscription",
        skill = 385,
        item = 41097,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57029] = {
        p = "Inscription",
        skill = 105,
        item = 41106,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57030] = {
        p = "Inscription",
        skill = 120,
        item = 41092,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57031] = {
        p = "Inscription",
        skill = 135,
        item = 41108,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57032] = {
        p = "Inscription",
        skill = 155,
        item = 41100,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57033] = {
        p = "Inscription",
        skill = 335,
        item = 41094,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57034] = {
        p = "Inscription",
        skill = 385,
        item = 41110,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57035] = {
        p = "Inscription",
        skill = 385,
        item = 41109,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57036] = {
        p = "Inscription",
        skill = 375,
        item = 41102,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57112] = {
        p = "Inscription",
        skill = 385,
        item = 42954,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57113] = {
        p = "Inscription",
        skill = 340,
        item = 42955,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57114] = {
        p = "Inscription",
        skill = 80,
        item = 42956,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57115] = {
        p = "Inscription",
        skill = 385,
        item = 42957,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57116] = {
        p = "Inscription",
        skill = 385,
        item = 42958,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57117] = {
        p = "Inscription",
        skill = 385,
        item = 42959,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57119] = {
        p = "Inscription",
        skill = 95,
        item = 42960,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57120] = {
        p = "Inscription",
        skill = 105,
        item = 42961,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57121] = {
        p = "Inscription",
        skill = 120,
        item = 42962,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57122] = {
        p = "Inscription",
        skill = 305,
        item = 42963,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57123] = {
        p = "Inscription",
        skill = 135,
        item = 42964,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57124] = {
        p = "Inscription",
        skill = 385,
        item = 42965,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57125] = {
        p = "Inscription",
        skill = 160,
        item = 42966,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57126] = {
        p = "Inscription",
        skill = 385,
        item = 42967,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57127] = {
        p = "Inscription",
        skill = 385,
        item = 42968,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57128] = {
        p = "Inscription",
        skill = 385,
        item = 42969,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57129] = {
        p = "Inscription",
        skill = 185,
        item = 42970,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57130] = {
        p = "Inscription",
        skill = 385,
        item = 42971,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57131] = {
        p = "Inscription",
        skill = 210,
        item = 42972,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57132] = {
        p = "Inscription",
        skill = 235,
        item = 42973,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57133] = {
        p = "Inscription",
        skill = 285,
        item = 42974,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57151] = {
        p = "Inscription",
        skill = 220,
        item = 43420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57152] = {
        p = "Inscription",
        skill = 385,
        item = 43425,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57153] = {
        p = "Inscription",
        skill = 385,
        item = 43412,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57154] = {
        p = "Inscription",
        skill = 240,
        item = 43414,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57155] = {
        p = "Inscription",
        skill = 385,
        item = 43415,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57156] = {
        p = "Inscription",
        skill = 285,
        item = 43416,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57157] = {
        p = "Inscription",
        skill = 125,
        item = 43417,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57158] = {
        p = "Inscription",
        skill = 95,
        item = 43418,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57159] = {
        p = "Inscription",
        skill = 385,
        item = 43419,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57160] = {
        p = "Inscription",
        skill = 385,
        item = 43421,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57161] = {
        p = "Inscription",
        skill = 170,
        item = 43422,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57162] = {
        p = "Inscription",
        skill = 85,
        item = 43413,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57163] = {
        p = "Inscription",
        skill = 110,
        item = 43423,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57164] = {
        p = "Inscription",
        skill = 385,
        item = 43430,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57165] = {
        p = "Inscription",
        skill = 190,
        item = 43424,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57166] = {
        p = "Inscription",
        skill = 385,
        item = 43426,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57167] = {
        p = "Inscription",
        skill = 140,
        item = 43427,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57168] = {
        p = "Inscription",
        skill = 320,
        item = 43428,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57169] = {
        p = "Inscription",
        skill = 385,
        item = 43429,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57170] = {
        p = "Inscription",
        skill = 385,
        item = 43431,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57172] = {
        p = "Inscription",
        skill = 345,
        item = 43432,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57181] = {
        p = "Inscription",
        skill = 385,
        item = 42396,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57183] = {
        p = "Inscription",
        skill = 230,
        item = 42397,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57184] = {
        p = "Inscription",
        skill = 105,
        item = 42398,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57185] = {
        p = "Inscription",
        skill = 270,
        item = 42399,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57186] = {
        p = "Inscription",
        skill = 120,
        item = 42400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57187] = {
        p = "Inscription",
        skill = 315,
        item = 42401,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57188] = {
        p = "Inscription",
        skill = 135,
        item = 42402,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57189] = {
        p = "Inscription",
        skill = 385,
        item = 42403,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57190] = {
        p = "Inscription",
        skill = 385,
        item = 42404,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57191] = {
        p = "Inscription",
        skill = 385,
        item = 42405,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57192] = {
        p = "Inscription",
        skill = 350,
        item = 42406,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57193] = {
        p = "Inscription",
        skill = 385,
        item = 42407,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57194] = {
        p = "Inscription",
        skill = 80,
        item = 42408,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57195] = {
        p = "Inscription",
        skill = 385,
        item = 42409,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57196] = {
        p = "Inscription",
        skill = 95,
        item = 42410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57197] = {
        p = "Inscription",
        skill = 160,
        item = 42411,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57198] = {
        p = "Inscription",
        skill = 375,
        item = 42412,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57199] = {
        p = "Inscription",
        skill = 385,
        item = 42414,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57200] = {
        p = "Inscription",
        skill = 180,
        item = 42415,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57201] = {
        p = "Inscription",
        skill = 210,
        item = 42416,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57202] = {
        p = "Inscription",
        skill = 385,
        item = 42417,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57207] = {
        p = "Inscription",
        skill = 385,
        item = 43533,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57208] = {
        p = "Inscription",
        skill = 385,
        item = 43534,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57209] = {
        p = "Inscription",
        skill = 320,
        item = 43535,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57210] = {
        p = "Inscription",
        skill = 265,
        item = 43536,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57211] = {
        p = "Inscription",
        skill = 385,
        item = 43537,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57212] = {
        p = "Inscription",
        skill = 385,
        item = 43538,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57213] = {
        p = "Inscription",
        skill = 285,
        item = 43541,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57214] = {
        p = "Inscription",
        skill = 385,
        item = 43542,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57215] = {
        p = "Inscription",
        skill = 300,
        item = 43539,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57216] = {
        p = "Inscription",
        skill = 270,
        item = 43543,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57217] = {
        p = "Inscription",
        skill = 320,
        item = 43544,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57218] = {
        p = "Inscription",
        skill = 385,
        item = 43545,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57219] = {
        p = "Inscription",
        skill = 280,
        item = 43546,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57220] = {
        p = "Inscription",
        skill = 385,
        item = 43547,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57221] = {
        p = "Inscription",
        skill = 300,
        item = 43548,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57222] = {
        p = "Inscription",
        skill = 350,
        item = 43549,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57223] = {
        p = "Inscription",
        skill = 385,
        item = 43550,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57224] = {
        p = "Inscription",
        skill = 330,
        item = 43551,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57225] = {
        p = "Inscription",
        skill = 375,
        item = 43552,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57226] = {
        p = "Inscription",
        skill = 305,
        item = 43553,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57227] = {
        p = "Inscription",
        skill = 345,
        item = 43554,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57228] = {
        p = "Inscription",
        skill = 300,
        item = 43673,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57229] = {
        p = "Inscription",
        skill = 300,
        item = 43671,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57230] = {
        p = "Inscription",
        skill = 300,
        item = 43672,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57232] = {
        p = "Inscription",
        skill = 385,
        item = 41517,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57233] = {
        p = "Inscription",
        skill = 385,
        item = 41518,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57234] = {
        p = "Inscription",
        skill = 385,
        item = 41524,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57235] = {
        p = "Inscription",
        skill = 385,
        item = 41526,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57236] = {
        p = "Inscription",
        skill = 300,
        item = 41527,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57237] = {
        p = "Inscription",
        skill = 385,
        item = 41529,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57238] = {
        p = "Inscription",
        skill = 110,
        item = 41530,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57239] = {
        p = "Inscription",
        skill = 85,
        item = 41531,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57240] = {
        p = "Inscription",
        skill = 125,
        item = 41532,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57241] = {
        p = "Inscription",
        skill = 185,
        item = 41547,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57242] = {
        p = "Inscription",
        skill = 215,
        item = 41533,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57243] = {
        p = "Inscription",
        skill = 385,
        item = 41534,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57244] = {
        p = "Inscription",
        skill = 235,
        item = 41535,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57245] = {
        p = "Inscription",
        skill = 140,
        item = 41536,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57246] = {
        p = "Inscription",
        skill = 95,
        item = 41537,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57247] = {
        p = "Inscription",
        skill = 385,
        item = 41538,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57248] = {
        p = "Inscription",
        skill = 375,
        item = 41539,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57249] = {
        p = "Inscription",
        skill = 165,
        item = 41540,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57250] = {
        p = "Inscription",
        skill = 385,
        item = 41552,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57251] = {
        p = "Inscription",
        skill = 275,
        item = 41541,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57252] = {
        p = "Inscription",
        skill = 330,
        item = 41542,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57253] = {
        p = "Inscription",
        skill = 355,
        item = 44923,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [57257] = {
        p = "Inscription",
        skill = 350,
        item = 42453,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57258] = {
        p = "Inscription",
        skill = 385,
        item = 42454,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57259] = {
        p = "Inscription",
        skill = 85,
        item = 42455,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57260] = {
        p = "Inscription",
        skill = 385,
        item = 42456,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57261] = {
        p = "Inscription",
        skill = 385,
        item = 42457,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57262] = {
        p = "Inscription",
        skill = 125,
        item = 42458,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57263] = {
        p = "Inscription",
        skill = 385,
        item = 42459,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57264] = {
        p = "Inscription",
        skill = 385,
        item = 42460,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57265] = {
        p = "Inscription",
        skill = 110,
        item = 42461,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57266] = {
        p = "Inscription",
        skill = 95,
        item = 42462,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57267] = {
        p = "Inscription",
        skill = 385,
        item = 42463,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57268] = {
        p = "Inscription",
        skill = 385,
        item = 42464,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57269] = {
        p = "Inscription",
        skill = 140,
        item = 42465,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57270] = {
        p = "Inscription",
        skill = 215,
        item = 42466,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57271] = {
        p = "Inscription",
        skill = 165,
        item = 42467,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57272] = {
        p = "Inscription",
        skill = 275,
        item = 42468,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57273] = {
        p = "Inscription",
        skill = 385,
        item = 42469,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57274] = {
        p = "Inscription",
        skill = 240,
        item = 42470,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57275] = {
        p = "Inscription",
        skill = 325,
        item = 42471,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57276] = {
        p = "Inscription",
        skill = 385,
        item = 42472,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [57277] = {
        p = "Inscription",
        skill = 190,
        item = 42473,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57421] = {
        p = "Cooking",
        skill = 350,
        item = 34747,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #13088 (Borean Tundra 57.9, 71.5)",
                "Quest #13087 (Howling Fjord 58.2, 62.1)",
                "Quest #13089 (Howling Fjord 78.7, 29.5)",
                "Quest #13090 (Borean Tundra 42, 54.2)",
            } },
        },
    },
    [57423] = {
        p = "Cooking",
        skill = 450,
        item = 43015,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57425] = {
        p = "Alchemy",
        skill = 430,
        item = 41266,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57427] = {
        p = "Alchemy",
        skill = 425,
        item = 41334,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57433] = {
        p = "Cooking",
        skill = 400,
        item = 42993,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57434] = {
        p = "Cooking",
        skill = 400,
        item = 42994,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57435] = {
        p = "Cooking",
        skill = 400,
        item = 43004,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57436] = {
        p = "Cooking",
        skill = 400,
        item = 42995,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57437] = {
        p = "Cooking",
        skill = 400,
        item = 42996,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57438] = {
        p = "Cooking",
        skill = 400,
        item = 42997,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57439] = {
        p = "Cooking",
        skill = 400,
        item = 42998,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57440] = {
        p = "Cooking",
        skill = 400,
        item = 43005,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57441] = {
        p = "Cooking",
        skill = 400,
        item = 42999,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57442] = {
        p = "Cooking",
        skill = 400,
        item = 43000,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57443] = {
        p = "Cooking",
        skill = 400,
        item = 43001,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [57683] = {
        p = "Leatherworking",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57690] = {
        p = "Leatherworking",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57691] = {
        p = "Leatherworking",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57692] = {
        p = "Leatherworking",
        skill = 400,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Skeletal Runesmith (Icecrown 60, 73.1)",
            } },
        },
    },
    [57694] = {
        p = "Leatherworking",
        skill = 400,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Damned Apothecary (Icecrown 49.8, 32.7)",
            } },
        },
    },
    [57696] = {
        p = "Leatherworking",
        skill = 400,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cultist Shard Watcher (Icecrown 48.1, 67.9)",
            } },
        },
    },
    [57699] = {
        p = "Leatherworking",
        skill = 400,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Cult Alchemist (Icecrown 49.5, 33.1)",
            } },
        },
    },
    [57701] = {
        p = "Leatherworking",
        skill = 400,
        q = "Rare",
        sources = {
            { t = "Mob Drop", d = {
                "Frostbrood Spawn (Icecrown 75.3, 43.4)",
                "Cult Researcher (Icecrown 50.7, 30.9)",
            } },
        },
    },
    [57703] = {
        p = "Inscription",
        skill = 85,
        item = 43115,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57704] = {
        p = "Inscription",
        skill = 100,
        item = 43116,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57706] = {
        p = "Inscription",
        skill = 125,
        item = 43117,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57707] = {
        p = "Inscription",
        skill = 150,
        item = 43118,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57708] = {
        p = "Inscription",
        skill = 175,
        item = 43119,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57709] = {
        p = "Inscription",
        skill = 200,
        item = 43120,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57710] = {
        p = "Inscription",
        skill = 225,
        item = 43121,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57711] = {
        p = "Inscription",
        skill = 250,
        item = 43122,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57712] = {
        p = "Inscription",
        skill = 275,
        item = 43123,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57713] = {
        p = "Inscription",
        skill = 290,
        item = 43124,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57714] = {
        p = "Inscription",
        skill = 325,
        item = 43125,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57715] = {
        p = "Inscription",
        skill = 350,
        item = 43126,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57716] = {
        p = "Inscription",
        skill = 375,
        item = 43127,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [57719] = {
        p = "Inscription",
        skill = 385,
        item = 42740,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [58065] = {
        p = "Cooking",
        skill = 350,
        item = 43268,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58141] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 43244,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58142] = {
        p = "Jewelcrafting",
        skill = 350,
        item = 43245,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58143] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 43246,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58144] = {
        p = "Jewelcrafting",
        skill = 370,
        item = 43247,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58145] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 43248,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58146] = {
        p = "Jewelcrafting",
        skill = 390,
        item = 43249,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58147] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43250,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58148] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43251,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58149] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43252,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58150] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43253,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58286] = {
        p = "Inscription",
        skill = 75,
        item = 43316,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58287] = {
        p = "Inscription",
        skill = 150,
        item = 43334,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58288] = {
        p = "Inscription",
        skill = 95,
        item = 43331,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58289] = {
        p = "Inscription",
        skill = 75,
        item = 43332,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58296] = {
        p = "Inscription",
        skill = 75,
        item = 43335,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58297] = {
        p = "Inscription",
        skill = 195,
        item = 43355,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58298] = {
        p = "Inscription",
        skill = 75,
        item = 43356,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58299] = {
        p = "Inscription",
        skill = 75,
        item = 43338,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58300] = {
        p = "Inscription",
        skill = 75,
        item = 43354,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58301] = {
        p = "Inscription",
        skill = 75,
        item = 43350,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58302] = {
        p = "Inscription",
        skill = 150,
        item = 43351,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58303] = {
        p = "Inscription",
        skill = 75,
        item = 43339,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58305] = {
        p = "Inscription",
        skill = 95,
        item = 43357,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58306] = {
        p = "Inscription",
        skill = 75,
        item = 43359,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58307] = {
        p = "Inscription",
        skill = 120,
        item = 43360,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58308] = {
        p = "Inscription",
        skill = 75,
        item = 43364,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58310] = {
        p = "Inscription",
        skill = 75,
        item = 43361,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58311] = {
        p = "Inscription",
        skill = 95,
        item = 43365,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58312] = {
        p = "Inscription",
        skill = 75,
        item = 43366,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58313] = {
        p = "Inscription",
        skill = 75,
        item = 43367,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58314] = {
        p = "Inscription",
        skill = 75,
        item = 43340,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58315] = {
        p = "Inscription",
        skill = 95,
        item = 43368,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58316] = {
        p = "Inscription",
        skill = 150,
        item = 43369,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58317] = {
        p = "Inscription",
        skill = 75,
        item = 43342,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58318] = {
        p = "Inscription",
        skill = 75,
        item = 43371,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58319] = {
        p = "Inscription",
        skill = 170,
        item = 43370,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58320] = {
        p = "Inscription",
        skill = 95,
        item = 43373,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58321] = {
        p = "Inscription",
        skill = 150,
        item = 43372,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58322] = {
        p = "Inscription",
        skill = 345,
        item = 43374,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58323] = {
        p = "Inscription",
        skill = 75,
        item = 43379,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58324] = {
        p = "Inscription",
        skill = 120,
        item = 43376,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58325] = {
        p = "Inscription",
        skill = 95,
        item = 43377,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58326] = {
        p = "Inscription",
        skill = 75,
        item = 43343,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58327] = {
        p = "Inscription",
        skill = 195,
        item = 43378,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58328] = {
        p = "Inscription",
        skill = 120,
        item = 43380,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58329] = {
        p = "Inscription",
        skill = 150,
        item = 43381,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58330] = {
        p = "Inscription",
        skill = 150,
        item = 43385,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58331] = {
        p = "Inscription",
        skill = 120,
        item = 43344,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58332] = {
        p = "Inscription",
        skill = 95,
        item = 43386,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58333] = {
        p = "Inscription",
        skill = 150,
        item = 43388,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58336] = {
        p = "Inscription",
        skill = 95,
        item = 43389,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58337] = {
        p = "Inscription",
        skill = 75,
        item = 43390,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58338] = {
        p = "Inscription",
        skill = 150,
        item = 43392,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58339] = {
        p = "Inscription",
        skill = 150,
        item = 43393,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58340] = {
        p = "Inscription",
        skill = 120,
        item = 43391,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58341] = {
        p = "Inscription",
        skill = 345,
        item = 43394,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58342] = {
        p = "Inscription",
        skill = 75,
        item = 43395,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58343] = {
        p = "Inscription",
        skill = 75,
        item = 43396,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58344] = {
        p = "Inscription",
        skill = 75,
        item = 43397,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58345] = {
        p = "Inscription",
        skill = 95,
        item = 43398,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58346] = {
        p = "Inscription",
        skill = 75,
        item = 43399,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58347] = {
        p = "Inscription",
        skill = 320,
        item = 43400,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [58472] = {
        p = "Inscription",
        skill = 15,
        item = 3012,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58473] = {
        p = "Inscription",
        skill = 85,
        item = 1477,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58476] = {
        p = "Inscription",
        skill = 175,
        item = 4425,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58478] = {
        p = "Inscription",
        skill = 225,
        item = 10309,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58480] = {
        p = "Inscription",
        skill = 270,
        item = 27498,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58481] = {
        p = "Inscription",
        skill = 310,
        item = 33457,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58482] = {
        p = "Inscription",
        skill = 370,
        item = 43463,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58483] = {
        p = "Inscription",
        skill = 420,
        item = 43464,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58484] = {
        p = "Inscription",
        skill = 15,
        item = 954,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58485] = {
        p = "Inscription",
        skill = 80,
        item = 2289,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58486] = {
        p = "Inscription",
        skill = 170,
        item = 4426,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58487] = {
        p = "Inscription",
        skill = 220,
        item = 10310,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58488] = {
        p = "Inscription",
        skill = 265,
        item = 27503,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58489] = {
        p = "Inscription",
        skill = 305,
        item = 33462,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58490] = {
        p = "Inscription",
        skill = 365,
        item = 43465,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58491] = {
        p = "Inscription",
        skill = 415,
        item = 43466,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58492] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43482,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58507] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43498,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [58512] = {
        p = "Cooking",
        skill = 350,
        item = 43490,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [58521] = {
        p = "Cooking",
        skill = 350,
        item = 43488,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [58523] = {
        p = "Cooking",
        skill = 350,
        item = 43491,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [58525] = {
        p = "Cooking",
        skill = 350,
        item = 43492,
        q = "Uncommon",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [58527] = {
        p = "Cooking",
        skill = 425,
        item = 43478,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [58528] = {
        p = "Cooking",
        skill = 425,
        item = 43480,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [58565] = {
        p = "Inscription",
        skill = 110,
        item = 43515,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58868] = {
        p = "Alchemy",
        skill = 410,
        item = 43570,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58871] = {
        p = "Alchemy",
        skill = 410,
        item = 43569,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [58954] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 43582,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Tiffany Cartier (Dalaran 40.5, 34.4)",
                "Anuur (Icecrown 71.4, 20.8)",
            } },
        },
    },
    [59315] = {
        p = "Inscription",
        skill = 150,
        item = 43674,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [59326] = {
        p = "Inscription",
        skill = 95,
        item = 43725,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [59338] = {
        p = "Inscription",
        skill = 310,
        item = 43825,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59339] = {
        p = "Inscription",
        skill = 320,
        item = 43826,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59340] = {
        p = "Inscription",
        skill = 340,
        item = 43827,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59387] = {
        p = "Inscription",
        skill = 200,
        item = 43850,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59405] = {
        p = "Blacksmithing",
        skill = 350,
        item = 43854,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59406] = {
        p = "Blacksmithing",
        skill = 430,
        item = 43853,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59436] = {
        p = "Blacksmithing",
        skill = 395,
        item = 43860,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59438] = {
        p = "Blacksmithing",
        skill = 400,
        item = 43864,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59440] = {
        p = "Blacksmithing",
        skill = 405,
        item = 43865,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59441] = {
        p = "Blacksmithing",
        skill = 415,
        item = 43870,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59442] = {
        p = "Blacksmithing",
        skill = 410,
        item = 43871,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59475] = {
        p = "Inscription",
        skill = 125,
        item = 43654,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59478] = {
        p = "Inscription",
        skill = 125,
        item = 43655,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59480] = {
        p = "Inscription",
        skill = 125,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59484] = {
        p = "Inscription",
        skill = 175,
        item = 43656,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59486] = {
        p = "Inscription",
        skill = 175,
        item = 43657,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59487] = {
        p = "Inscription",
        skill = 175,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59488] = {
        p = "Inscription",
        skill = 235,
        item = 39350,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59489] = {
        p = "Inscription",
        skill = 225,
        item = 43660,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59490] = {
        p = "Inscription",
        skill = 225,
        item = 43661,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59491] = {
        p = "Inscription",
        skill = 225,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59493] = {
        p = "Inscription",
        skill = 275,
        item = 43663,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59494] = {
        p = "Inscription",
        skill = 275,
        item = 43664,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59495] = {
        p = "Inscription",
        skill = 325,
        item = 43666,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59496] = {
        p = "Inscription",
        skill = 325,
        item = 43667,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59497] = {
        p = "Inscription",
        skill = 400,
        item = 38322,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59498] = {
        p = "Inscription",
        skill = 400,
        item = 44210,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59499] = {
        p = "Inscription",
        skill = 200,
        item = 37602,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59500] = {
        p = "Inscription",
        skill = 350,
        item = 43145,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59501] = {
        p = "Inscription",
        skill = 400,
        item = 43146,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59502] = {
        p = "Inscription",
        skill = 275,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59503] = {
        p = "Inscription",
        skill = 325,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59504] = {
        p = "Inscription",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59559] = {
        p = "Inscription",
        skill = 385,
        item = 43867,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [59560] = {
        p = "Inscription",
        skill = 385,
        item = 43868,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [59561] = {
        p = "Inscription",
        skill = 385,
        item = 43869,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [59582] = {
        p = "Tailoring",
        skill = 415,
        item = 43969,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59583] = {
        p = "Tailoring",
        skill = 415,
        item = 43974,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59584] = {
        p = "Tailoring",
        skill = 420,
        item = 43973,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59585] = {
        p = "Tailoring",
        skill = 420,
        item = 43970,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59586] = {
        p = "Tailoring",
        skill = 420,
        item = 41516,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59587] = {
        p = "Tailoring",
        skill = 420,
        item = 43972,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59588] = {
        p = "Tailoring",
        skill = 420,
        item = 43975,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59589] = {
        p = "Tailoring",
        skill = 420,
        item = 43971,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59619] = {
        p = "Enchanting",
        skill = 440,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [59621] = {
        p = "Enchanting",
        skill = 440,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [59625] = {
        p = "Enchanting",
        skill = 440,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [59636] = {
        p = "Enchanting",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [59759] = {
        p = "Jewelcrafting",
        skill = 400,
        item = 44063,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60336] = {
        p = "Inscription",
        skill = 200,
        item = 44314,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60337] = {
        p = "Inscription",
        skill = 350,
        item = 44315,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60350] = {
        p = "Alchemy",
        skill = 395,
        item = 41163,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60354] = {
        p = "Alchemy",
        skill = 400,
        item = 44325,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60355] = {
        p = "Alchemy",
        skill = 400,
        item = 44327,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60356] = {
        p = "Alchemy",
        skill = 400,
        item = 44328,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60357] = {
        p = "Alchemy",
        skill = 400,
        item = 44329,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60365] = {
        p = "Alchemy",
        skill = 400,
        item = 44330,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60366] = {
        p = "Alchemy",
        skill = 400,
        item = 44331,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [60367] = {
        p = "Alchemy",
        skill = 395,
        item = 44332,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60396] = {
        p = "Alchemy",
        skill = 400,
        item = 44322,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60403] = {
        p = "Alchemy",
        skill = 400,
        item = 44323,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60405] = {
        p = "Alchemy",
        skill = 400,
        item = 44324,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60583] = {
        p = "Leatherworking",
        skill = 405,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60584] = {
        p = "Leatherworking",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60599] = {
        p = "Leatherworking",
        skill = 385,
        item = 38436,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60600] = {
        p = "Leatherworking",
        skill = 385,
        item = 38440,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60601] = {
        p = "Leatherworking",
        skill = 395,
        item = 44436,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60604] = {
        p = "Leatherworking",
        skill = 395,
        item = 44437,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60605] = {
        p = "Leatherworking",
        skill = 400,
        item = 44438,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60606] = {
        p = "Enchanting",
        skill = 375,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60607] = {
        p = "Leatherworking",
        skill = 385,
        item = 38434,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60608] = {
        p = "Leatherworking",
        skill = 385,
        item = 38438,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60609] = {
        p = "Enchanting",
        skill = 350,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60611] = {
        p = "Leatherworking",
        skill = 395,
        item = 44440,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60613] = {
        p = "Leatherworking",
        skill = 395,
        item = 44441,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60616] = {
        p = "Enchanting",
        skill = 360,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60619] = {
        p = "Enchanting",
        skill = 425,
        item = 44452,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60620] = {
        p = "Leatherworking",
        skill = 400,
        item = 44442,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60621] = {
        p = "Enchanting",
        skill = 380,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60622] = {
        p = "Leatherworking",
        skill = 385,
        item = 38435,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60623] = {
        p = "Enchanting",
        skill = 385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60624] = {
        p = "Leatherworking",
        skill = 385,
        item = 38439,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60627] = {
        p = "Leatherworking",
        skill = 395,
        item = 44443,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60629] = {
        p = "Leatherworking",
        skill = 395,
        item = 44444,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60630] = {
        p = "Leatherworking",
        skill = 400,
        item = 44445,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60631] = {
        p = "Leatherworking",
        skill = 380,
        item = 38441,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60637] = {
        p = "Leatherworking",
        skill = 440,
        item = 43566,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60640] = {
        p = "Leatherworking",
        skill = 440,
        item = 43565,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60643] = {
        p = "Leatherworking",
        skill = 415,
        item = 44446,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60645] = {
        p = "Leatherworking",
        skill = 415,
        item = 44447,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Kalu'ak - Honored: Tanaika (Howling Fjord 25.5, 58.7)",
                "The Kalu'ak - Honored: Sairuk (Dragonblight 48.5, 75.7)",
            } },
        },
    },
    [60647] = {
        p = "Leatherworking",
        skill = 415,
        item = 44448,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Knights of the Ebon Blade - Honored: Duchess Mynx (Icecrown 43.5, 20.6)",
            } },
        },
    },
    [60649] = {
        p = "Leatherworking",
        skill = 425,
        item = 43129,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60651] = {
        p = "Leatherworking",
        skill = 420,
        item = 43130,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60652] = {
        p = "Leatherworking",
        skill = 420,
        item = 43131,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60653] = {
        p = "Enchanting",
        skill = 395,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60655] = {
        p = "Leatherworking",
        skill = 425,
        item = 43132,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60658] = {
        p = "Leatherworking",
        skill = 420,
        item = 43133,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60660] = {
        p = "Leatherworking",
        skill = 425,
        item = 42731,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60663] = {
        p = "Enchanting",
        skill = 420,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60665] = {
        p = "Leatherworking",
        skill = 420,
        item = 43255,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60666] = {
        p = "Leatherworking",
        skill = 420,
        item = 43256,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60668] = {
        p = "Enchanting",
        skill = 425,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60669] = {
        p = "Leatherworking",
        skill = 425,
        item = 43257,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60671] = {
        p = "Leatherworking",
        skill = 420,
        item = 43258,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60691] = {
        p = "Enchanting",
        skill = 430,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60692] = {
        p = "Enchanting",
        skill = 440,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60697] = {
        p = "Leatherworking",
        skill = 420,
        item = 43260,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60702] = {
        p = "Leatherworking",
        skill = 420,
        item = 43433,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60703] = {
        p = "Leatherworking",
        skill = 420,
        item = 43434,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60704] = {
        p = "Leatherworking",
        skill = 420,
        item = 43435,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60705] = {
        p = "Leatherworking",
        skill = 425,
        item = 43436,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60706] = {
        p = "Leatherworking",
        skill = 425,
        item = 43437,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60707] = {
        p = "Enchanting",
        skill = 435,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60711] = {
        p = "Leatherworking",
        skill = 425,
        item = 43438,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60712] = {
        p = "Leatherworking",
        skill = 425,
        item = 43439,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60714] = {
        p = "Enchanting",
        skill = 435,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60715] = {
        p = "Leatherworking",
        skill = 420,
        item = 43261,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60716] = {
        p = "Leatherworking",
        skill = 420,
        item = 43262,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60718] = {
        p = "Leatherworking",
        skill = 420,
        item = 43263,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60720] = {
        p = "Leatherworking",
        skill = 420,
        item = 43264,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60721] = {
        p = "Leatherworking",
        skill = 425,
        item = 43265,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60723] = {
        p = "Leatherworking",
        skill = 425,
        item = 43266,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60725] = {
        p = "Leatherworking",
        skill = 425,
        item = 43271,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60727] = {
        p = "Leatherworking",
        skill = 425,
        item = 43273,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60728] = {
        p = "Leatherworking",
        skill = 420,
        item = 43447,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60729] = {
        p = "Leatherworking",
        skill = 420,
        item = 43449,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60730] = {
        p = "Leatherworking",
        skill = 420,
        item = 43445,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60731] = {
        p = "Leatherworking",
        skill = 420,
        item = 43444,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60732] = {
        p = "Leatherworking",
        skill = 425,
        item = 43446,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60734] = {
        p = "Leatherworking",
        skill = 425,
        item = 43442,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60735] = {
        p = "Leatherworking",
        skill = 425,
        item = 43448,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60737] = {
        p = "Leatherworking",
        skill = 425,
        item = 43443,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60743] = {
        p = "Leatherworking",
        skill = 420,
        item = 43455,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60746] = {
        p = "Leatherworking",
        skill = 420,
        item = 43457,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60747] = {
        p = "Leatherworking",
        skill = 420,
        item = 43453,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60748] = {
        p = "Leatherworking",
        skill = 420,
        item = 43452,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60749] = {
        p = "Leatherworking",
        skill = 425,
        item = 43454,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60750] = {
        p = "Leatherworking",
        skill = 425,
        item = 43450,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60751] = {
        p = "Leatherworking",
        skill = 425,
        item = 43456,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60752] = {
        p = "Leatherworking",
        skill = 425,
        item = 43451,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60754] = {
        p = "Leatherworking",
        skill = 440,
        item = 43458,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60755] = {
        p = "Leatherworking",
        skill = 440,
        item = 43459,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60756] = {
        p = "Leatherworking",
        skill = 440,
        item = 43461,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60757] = {
        p = "Leatherworking",
        skill = 440,
        item = 43469,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60758] = {
        p = "Leatherworking",
        skill = 440,
        item = 43481,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60759] = {
        p = "Leatherworking",
        skill = 440,
        item = 43484,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60760] = {
        p = "Leatherworking",
        skill = 440,
        item = 43495,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60761] = {
        p = "Leatherworking",
        skill = 440,
        item = 43502,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60763] = {
        p = "Enchanting",
        skill = 440,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60767] = {
        p = "Enchanting",
        skill = 440,
        item = 44498,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [60866] = {
        p = "Engineering",
        skill = 450,
        item = 41508,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "Horde Expedition - Exalted: Gara Skullcrush (Borean Tundra 41.4, 53.6)",
                "Horde Expedition - Exalted: Sebastian Crane (Howling Fjord 79.6, 30.7)",
            } },
        },
    },
    [60867] = {
        p = "Engineering",
        skill = 450,
        item = 44413,
        q = "Epic",
    },
    [60874] = {
        p = "Engineering",
        skill = 450,
        item = 44504,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60893] = {
        p = "Alchemy",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60969] = {
        p = "Tailoring",
        skill = 300,
        item = 44554,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60971] = {
        p = "Tailoring",
        skill = 425,
        item = 44558,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60990] = {
        p = "Tailoring",
        skill = 420,
        item = 43584,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60993] = {
        p = "Tailoring",
        skill = 425,
        item = 43583,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60994] = {
        p = "Tailoring",
        skill = 420,
        item = 43585,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [60996] = {
        p = "Leatherworking",
        skill = 425,
        item = 43590,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60997] = {
        p = "Leatherworking",
        skill = 420,
        item = 43591,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60998] = {
        p = "Leatherworking",
        skill = 420,
        item = 43592,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [60999] = {
        p = "Leatherworking",
        skill = 425,
        item = 43593,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [61000] = {
        p = "Leatherworking",
        skill = 420,
        item = 43594,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [61002] = {
        p = "Leatherworking",
        skill = 420,
        item = 43595,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [61008] = {
        p = "Blacksmithing",
        skill = 425,
        item = 43586,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61009] = {
        p = "Blacksmithing",
        skill = 420,
        item = 43587,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61010] = {
        p = "Blacksmithing",
        skill = 420,
        item = 43588,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61117] = {
        p = "Inscription",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61118] = {
        p = "Inscription",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61119] = {
        p = "Inscription",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61120] = {
        p = "Inscription",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61177] = {
        p = "Inscription",
        skill = 385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61288] = {
        p = "Inscription",
        skill = 75,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61471] = {
        p = "Engineering",
        skill = 390,
        item = 44739,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61481] = {
        p = "Engineering",
        skill = 420,
        item = 44742,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61482] = {
        p = "Engineering",
        skill = 420,
        item = 44742,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61483] = {
        p = "Engineering",
        skill = 420,
        item = 44742,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [61677] = {
        p = "Inscription",
        skill = 385,
        item = 44684,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend Inscription Research.",
            } },
        },
    },
    [62044] = {
        p = "Cooking",
        skill = 100,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [62045] = {
        p = "Cooking",
        skill = 330,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [62049] = {
        p = "Cooking",
        skill = 210,
        item = 44840,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [62050] = {
        p = "Cooking",
        skill = 90,
        item = 44837,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [62051] = {
        p = "Cooking",
        skill = 270,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [62158] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62162] = {
        p = "Inscription",
        skill = 375,
        item = 44928,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62176] = {
        p = "Leatherworking",
        skill = 440,
        item = 44930,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [62177] = {
        p = "Leatherworking",
        skill = 440,
        item = 44931,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Braeg Stoutbeard (Dalaran 37.6, 29.5)",
            } },
        },
    },
    [62202] = {
        p = "Blacksmithing",
        skill = 450,
        item = 44936,
        q = "Rare",
        sources = {
            { t = "Reputation Vendor", d = {
                "Horde Expedition - Exalted: Gara Skullcrush (Borean Tundra 41.4, 53.6)",
                "Horde Expedition - Exalted: Sebastian Crane (Howling Fjord 79.6, 30.7)",
            } },
            { t = "Reputation Vendor", d = {
                "Alliance Vanguard - Exalted: Logistics Officer Silverstone (Borean Tundra 57.7, 66.5)",
                "Alliance Vanguard - Exalted: Logistics Officer Brighton (Howling Fjord 59.7, 63.9)",
            } },
        },
    },
    [62213] = {
        p = "Alchemy",
        skill = 385,
        item = 44939,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62242] = {
        p = "Jewelcrafting",
        skill = 425,
        item = 44943,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62256] = {
        p = "Enchanting",
        skill = 450,
        item = 44944,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [62271] = {
        p = "Engineering",
        skill = 440,
        item = 44949,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62350] = {
        p = "Cooking",
        skill = 400,
        item = 44953,
        q = "Uncommon",
        sources = {
            { t = "Vendor", d = {
                "Misensi (Dalaran 70.1, 38.5)",
                "Derek Odds (Dalaran 41.5, 64.8)",
                "Mera Mistrunner (Icecrown 72.4, 20.9)",
            } },
        },
    },
    [62409] = {
        p = "Alchemy",
        skill = 375,
        item = 44958,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62410] = {
        p = "Alchemy",
        skill = 400,
        item = 8827,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Northrend alchemy research.",
            } },
        },
    },
    [62448] = {
        p = "Leatherworking",
        skill = 425,
        item = 44963,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62941] = {
        p = "Jewelcrafting",
        skill = 300,
        item = 45054,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [62948] = {
        p = "Enchanting",
        skill = 450,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Vanessa Sellers (Dalaran 38.7, 40.8)",
            } },
        },
    },
    [62959] = {
        p = "Enchanting",
        skill = 385,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63182] = {
        p = "Blacksmithing",
        skill = 440,
        item = 45085,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63187] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45088,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63188] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45089,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63189] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45090,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63190] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45091,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63191] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45092,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63192] = {
        p = "Blacksmithing",
        skill = 450,
        item = 45093,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63194] = {
        p = "Leatherworking",
        skill = 450,
        item = 45553,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63195] = {
        p = "Leatherworking",
        skill = 450,
        item = 45095,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63196] = {
        p = "Leatherworking",
        skill = 450,
        item = 45096,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63197] = {
        p = "Leatherworking",
        skill = 450,
        item = 45097,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63198] = {
        p = "Leatherworking",
        skill = 450,
        item = 45098,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63199] = {
        p = "Leatherworking",
        skill = 450,
        item = 45099,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63200] = {
        p = "Leatherworking",
        skill = 450,
        item = 45100,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63201] = {
        p = "Leatherworking",
        skill = 450,
        item = 45101,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63203] = {
        p = "Tailoring",
        skill = 450,
        item = 45102,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63204] = {
        p = "Tailoring",
        skill = 450,
        item = 45566,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63205] = {
        p = "Tailoring",
        skill = 450,
        item = 45104,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63206] = {
        p = "Tailoring",
        skill = 450,
        item = 45567,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [63732] = {
        p = "Alchemy",
        skill = 135,
        item = 45621,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63742] = {
        p = "Tailoring",
        skill = 125,
        item = 45626,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63743] = {
        p = "Jewelcrafting",
        skill = 200,
        item = 45627,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63746] = {
        p = "Enchanting",
        skill = 225,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63750] = {
        p = "Engineering",
        skill = 250,
        item = 45631,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63765] = {
        p = "Engineering",
        skill = 380,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63770] = {
        p = "Engineering",
        skill = 400,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [63924] = {
        p = "Tailoring",
        skill = 435,
        item = 45773,
        q = "Common",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Kalu'ak - Revered: Tanaika (Howling Fjord 25.5, 58.7)",
                "The Kalu'ak - Revered: Sairuk (Dragonblight 48.5, 75.7)",
            } },
        },
    },
    [64051] = {
        p = "Inscription",
        skill = 350,
        item = 46108,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Silverbrook Defender (Grizzly Hills 24.6, 33.3)",
                "Silverbrook Villager (Grizzly Hills 27.3, 33.9)",
                "Silverbrook Trapper (Grizzly Hills 27.3, 33.9)",
                "Silverbrook Hunter (Grizzly Hills 37.5, 68)",
            } },
        },
    },
    [64053] = {
        p = "Inscription",
        skill = 350,
        item = 45849,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64054] = {
        p = "Cooking",
        skill = 250,
        item = 33004,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #6610 (Tanaris 52.6, 28.1)",
            } },
        },
    },
    [64246] = {
        p = "Inscription",
        skill = 425,
        item = 45735,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64247] = {
        p = "Inscription",
        skill = 425,
        item = 45778,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64248] = {
        p = "Inscription",
        skill = 425,
        item = 45785,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64249] = {
        p = "Inscription",
        skill = 425,
        item = 45734,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64250] = {
        p = "Inscription",
        skill = 425,
        item = 45789,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64251] = {
        p = "Inscription",
        skill = 425,
        item = 45747,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64252] = {
        p = "Inscription",
        skill = 425,
        item = 45797,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64253] = {
        p = "Inscription",
        skill = 425,
        item = 45733,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64254] = {
        p = "Inscription",
        skill = 425,
        item = 45746,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64255] = {
        p = "Inscription",
        skill = 425,
        item = 45793,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64256] = {
        p = "Inscription",
        skill = 425,
        item = 45623,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64257] = {
        p = "Inscription",
        skill = 425,
        item = 45740,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64258] = {
        p = "Inscription",
        skill = 250,
        item = 45622,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64259] = {
        p = "Inscription",
        skill = 255,
        item = 45760,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64260] = {
        p = "Inscription",
        skill = 255,
        item = 45768,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64261] = {
        p = "Inscription",
        skill = 250,
        item = 45775,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64262] = {
        p = "Inscription",
        skill = 255,
        item = 45776,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64266] = {
        p = "Inscription",
        skill = 275,
        item = 45804,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64267] = {
        p = "Inscription",
        skill = 280,
        item = 45805,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64268] = {
        p = "Inscription",
        skill = 425,
        item = 45601,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64270] = {
        p = "Inscription",
        skill = 425,
        item = 45602,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64271] = {
        p = "Inscription",
        skill = 425,
        item = 45625,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64273] = {
        p = "Inscription",
        skill = 425,
        item = 45731,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64274] = {
        p = "Inscription",
        skill = 425,
        item = 45736,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64275] = {
        p = "Inscription",
        skill = 425,
        item = 45737,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64276] = {
        p = "Inscription",
        skill = 425,
        item = 45738,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64277] = {
        p = "Inscription",
        skill = 425,
        item = 45741,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64278] = {
        p = "Inscription",
        skill = 425,
        item = 45742,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64279] = {
        p = "Inscription",
        skill = 425,
        item = 45743,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64280] = {
        p = "Inscription",
        skill = 425,
        item = 45753,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64281] = {
        p = "Inscription",
        skill = 425,
        item = 45755,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64282] = {
        p = "Inscription",
        skill = 425,
        item = 45756,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64283] = {
        p = "Inscription",
        skill = 425,
        item = 45758,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64284] = {
        p = "Inscription",
        skill = 425,
        item = 45761,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64285] = {
        p = "Inscription",
        skill = 425,
        item = 45762,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64286] = {
        p = "Inscription",
        skill = 425,
        item = 45764,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64287] = {
        p = "Inscription",
        skill = 425,
        item = 45770,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64288] = {
        p = "Inscription",
        skill = 425,
        item = 45771,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64289] = {
        p = "Inscription",
        skill = 425,
        item = 45772,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64291] = {
        p = "Inscription",
        skill = 425,
        item = 45779,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64294] = {
        p = "Inscription",
        skill = 425,
        item = 45781,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64295] = {
        p = "Inscription",
        skill = 425,
        item = 45790,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64296] = {
        p = "Inscription",
        skill = 425,
        item = 45792,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64297] = {
        p = "Inscription",
        skill = 425,
        item = 45799,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64298] = {
        p = "Inscription",
        skill = 425,
        item = 45800,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64299] = {
        p = "Inscription",
        skill = 425,
        item = 45803,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64300] = {
        p = "Inscription",
        skill = 425,
        item = 45806,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64302] = {
        p = "Inscription",
        skill = 425,
        item = 45795,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64303] = {
        p = "Inscription",
        skill = 425,
        item = 45769,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64304] = {
        p = "Inscription",
        skill = 425,
        item = 45732,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64305] = {
        p = "Inscription",
        skill = 425,
        item = 45745,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64307] = {
        p = "Inscription",
        skill = 425,
        item = 45604,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64308] = {
        p = "Inscription",
        skill = 425,
        item = 45744,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64309] = {
        p = "Inscription",
        skill = 425,
        item = 45757,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64310] = {
        p = "Inscription",
        skill = 425,
        item = 45767,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64311] = {
        p = "Inscription",
        skill = 425,
        item = 45783,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64312] = {
        p = "Inscription",
        skill = 425,
        item = 45794,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64313] = {
        p = "Inscription",
        skill = 425,
        item = 45603,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64314] = {
        p = "Inscription",
        skill = 425,
        item = 45739,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64315] = {
        p = "Inscription",
        skill = 425,
        item = 45766,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64316] = {
        p = "Inscription",
        skill = 425,
        item = 45777,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64317] = {
        p = "Inscription",
        skill = 425,
        item = 45782,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64318] = {
        p = "Inscription",
        skill = 425,
        item = 45780,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [64358] = {
        p = "Cooking",
        skill = 400,
        item = 45932,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64441] = {
        p = "Enchanting",
        skill = 450,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [64579] = {
        p = "Enchanting",
        skill = 450,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop off of Ulduar bosses. (Ulduar)",
            } },
        },
    },
    [64661] = {
        p = "Leatherworking",
        skill = 350,
        item = 33568,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64725] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 45812,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64726] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 45813,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64727] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 45808,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64728] = {
        p = "Jewelcrafting",
        skill = 420,
        item = 45809,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64729] = {
        p = "Tailoring",
        skill = 400,
        item = 45811,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [64730] = {
        p = "Tailoring",
        skill = 405,
        item = 45810,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [65245] = {
        p = "Inscription",
        skill = 425,
        item = 46372,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Discovered randomly by reading the Book of Glyph Mastery.",
            } },
        },
    },
    [65454] = {
        p = "Cooking",
        skill = 45,
        item = 46691,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66034] = {
        p = "Cooking",
        skill = 270,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66035] = {
        p = "Cooking",
        skill = 210,
        item = 44840,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66036] = {
        p = "Cooking",
        skill = 100,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66037] = {
        p = "Cooking",
        skill = 330,
        item = 44839,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66038] = {
        p = "Cooking",
        skill = 90,
        item = 44837,
        q = "Common",
        sources = {
            { t = "Seasonal", d = {
                "name (seasonal)",
            } },
        },
    },
    [66338] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40167,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66428] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40168,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66429] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40166,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66430] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40175,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66431] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40165,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66432] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40164,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66433] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40170,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66434] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40169,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66435] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40171,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66436] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40176,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66437] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40172,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66438] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40181,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66439] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40177,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66440] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40174,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66441] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40180,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66442] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40179,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66443] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40182,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66444] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40178,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66445] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40173,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66446] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40113,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66447] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40111,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66448] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40112,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66449] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40114,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66450] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40118,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66451] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40117,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66452] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40115,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66453] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40116,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66497] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40119,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66498] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40120,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66499] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40122,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66500] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40121,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66501] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40125,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66502] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40124,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66503] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40123,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66504] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40126,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66505] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40127,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66506] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40128,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66553] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40136,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66554] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40129,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66555] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40132,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66556] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40133,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66557] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40130,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66558] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40134,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66559] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40138,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66560] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40139,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66561] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40141,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66562] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40135,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66563] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40140,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66564] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40137,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66565] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40131,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66566] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40151,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66567] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40142,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66568] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40147,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66569] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40152,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66570] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40153,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66571] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40154,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66572] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40143,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66573] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40157,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66574] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40155,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66575] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40148,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66576] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40162,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66577] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40156,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66578] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40161,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66579] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40144,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66580] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40158,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66581] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40160,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66582] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40145,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66583] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40146,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66584] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40150,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66585] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40149,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66586] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40163,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66587] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 40159,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [66658] = {
        p = "Alchemy",
        skill = 450,
        item = 36931,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [66659] = {
        p = "Alchemy",
        skill = 450,
        item = 36919,
        q = "Common",
        sources = {
            { t = "Quest", d = {
                "Quest #14151 (Dalaran 42.5, 32.1)",
            } },
        },
    },
    [66660] = {
        p = "Alchemy",
        skill = 450,
        item = 36922,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [66662] = {
        p = "Alchemy",
        skill = 450,
        item = 36928,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [66663] = {
        p = "Alchemy",
        skill = 450,
        item = 36925,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [66664] = {
        p = "Alchemy",
        skill = 450,
        item = 36934,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [67025] = {
        p = "Alchemy",
        skill = 425,
        item = 47499,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [67064] = {
        p = "Tailoring",
        skill = 450,
        item = 47605,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67065] = {
        p = "Tailoring",
        skill = 450,
        item = 47587,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67066] = {
        p = "Tailoring",
        skill = 450,
        item = 47603,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67079] = {
        p = "Tailoring",
        skill = 450,
        item = 47585,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67080] = {
        p = "Leatherworking",
        skill = 450,
        item = 47597,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67081] = {
        p = "Leatherworking",
        skill = 450,
        item = 47579,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67082] = {
        p = "Leatherworking",
        skill = 450,
        item = 47595,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67083] = {
        p = "Leatherworking",
        skill = 450,
        item = 47576,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67084] = {
        p = "Leatherworking",
        skill = 450,
        item = 47602,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67085] = {
        p = "Leatherworking",
        skill = 450,
        item = 47583,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67086] = {
        p = "Leatherworking",
        skill = 450,
        item = 47599,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67087] = {
        p = "Leatherworking",
        skill = 450,
        item = 47581,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67091] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47591,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67092] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47570,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67093] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47589,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67094] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47572,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67095] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47593,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67096] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47574,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67130] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47592,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67131] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47571,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67132] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47590,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67133] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47573,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67134] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47594,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67135] = {
        p = "Blacksmithing",
        skill = 450,
        item = 47575,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67136] = {
        p = "Leatherworking",
        skill = 450,
        item = 47598,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67137] = {
        p = "Leatherworking",
        skill = 450,
        item = 47580,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67138] = {
        p = "Leatherworking",
        skill = 450,
        item = 47596,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67139] = {
        p = "Leatherworking",
        skill = 450,
        item = 47582,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67140] = {
        p = "Leatherworking",
        skill = 450,
        item = 47601,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67141] = {
        p = "Leatherworking",
        skill = 450,
        item = 47584,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67142] = {
        p = "Leatherworking",
        skill = 450,
        item = 47600,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67143] = {
        p = "Leatherworking",
        skill = 450,
        item = 47577,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67144] = {
        p = "Tailoring",
        skill = 450,
        item = 47606,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67145] = {
        p = "Tailoring",
        skill = 450,
        item = 47586,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67146] = {
        p = "Tailoring",
        skill = 450,
        item = 47604,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67147] = {
        p = "Tailoring",
        skill = 450,
        item = 47588,
        q = "Epic",
        sources = {
            { t = "Special", d = {
                "Random drop from the Trial of the Crusader, 25 man normal version.",
            } },
        },
    },
    [67326] = {
        p = "Engineering",
        skill = 410,
        item = 47828,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [67600] = {
        p = "Inscription",
        skill = 100,
        item = 48720,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [67839] = {
        p = "Engineering",
        skill = 410,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [67920] = {
        p = "Engineering",
        skill = 435,
        item = 48933,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [68067] = {
        p = "Engineering",
        skill = 450,
        item = 49050,
        q = "Rare",
        sources = {
            { t = "World Drop", d = {
                "Northrend",
            } },
        },
    },
    [68166] = {
        p = "Inscription",
        skill = 355,
        item = 49084,
        q = "Common",
        sources = {
            { t = "Special", d = {
                "Obtained randomly by conducting Minor Inscription Research.",
            } },
        },
    },
    [68253] = {
        p = "Jewelcrafting",
        skill = 450,
        item = 49110,
        q = "Rare",
        sources = {
            { t = "Vendor", d = {
                "Kirembri Silvermane (Shattrath City 58.1, 75)",
                "Nemiha (Shattrath City 36.1, 47.7)",
                "Timothy Jones (Dalaran 40.5, 35.2)",
                "Inessera (Shattrath City 34.5, 20.2)",
            } },
        },
    },
    [69385] = {
        p = "Inscription",
        skill = 440,
        item = 49632,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [69386] = {
        p = "Leatherworking",
        skill = 450,
        item = 49633,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [69388] = {
        p = "Leatherworking",
        skill = 450,
        item = 49634,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [69412] = {
        p = "Enchanting",
        skill = 445,
        item = 49640,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [70164] = {
        p = "Runeforging",
        skill = 1,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [70524] = {
        p = "Mining",
        skill = 250,
        item = 12655,
        q = "Common",
        sources = {
            { t = "Trainer", d = {
                "Profession trainer",
            } },
        },
    },
    [70550] = {
        p = "Tailoring",
        skill = 450,
        item = 49891,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70551] = {
        p = "Tailoring",
        skill = 450,
        item = 49890,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70552] = {
        p = "Tailoring",
        skill = 450,
        item = 49892,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70553] = {
        p = "Tailoring",
        skill = 450,
        item = 49893,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70554] = {
        p = "Leatherworking",
        skill = 450,
        item = 49898,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70555] = {
        p = "Leatherworking",
        skill = 450,
        item = 49894,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70556] = {
        p = "Leatherworking",
        skill = 450,
        item = 49899,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70557] = {
        p = "Leatherworking",
        skill = 450,
        item = 49895,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70558] = {
        p = "Leatherworking",
        skill = 450,
        item = 49900,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70559] = {
        p = "Leatherworking",
        skill = 450,
        item = 49896,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70560] = {
        p = "Leatherworking",
        skill = 450,
        item = 49901,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70561] = {
        p = "Leatherworking",
        skill = 450,
        item = 49897,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70562] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49902,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70563] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49905,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70565] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49903,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70566] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49906,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70567] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49904,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Revered: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [70568] = {
        p = "Blacksmithing",
        skill = 450,
        item = 49907,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [71015] = {
        p = "Inscription",
        skill = 375,
        item = 50125,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Larana Drome (Dalaran 42.3, 37.5)",
            } },
        },
    },
    [71101] = {
        p = "Inscription",
        skill = 250,
        item = 50045,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Larana Drome (Dalaran 42.3, 37.5)",
                "Jezebel Bican (Hellfire Peninsula 53.9, 65.5)",
                "Kul Inkspiller (Hellfire Peninsula 52.5, 36)",
            } },
        },
    },
    [71102] = {
        p = "Inscription",
        skill = 375,
        item = 50077,
        q = "Common",
        sources = {
            { t = "Vendor", d = {
                "Larana Drome (Dalaran 42.3, 37.5)",
            } },
        },
    },
    [71692] = {
        p = "Enchanting",
        skill = 375,
        q = "Uncommon",
        sources = {
            { t = "Mob Drop", d = {
                "Indu'le Fisherman (Dragonblight 40.2, 65.5)",
                "Indu'le Mystic (Dragonblight 40.2, 65.5)",
                "Indu'le Warrior (Dragonblight 40.2, 65.5)",
            } },
        },
    },
    [72952] = {
        p = "Engineering",
        skill = 450,
        item = 52020,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [72953] = {
        p = "Engineering",
        skill = 450,
        item = 52021,
        q = "Epic",
        sources = {
            { t = "Reputation Vendor", d = {
                "The Ashen Verdict - Honored: Alchemist Finklestein (Icecrown Citadel)",
            } },
        },
    },
    [75597] = {
        p = "Tailoring",
        skill = 450,
        item = 54797,
        q = "Epic",
        sources = {
            { t = "Vendor", d = {
                "Frozo the Renowned (Dalaran 41, 28.5)",
            } },
        },
    },
};

AtlasLoot_CraftingSourceData_Meta = { count = 3517, withSources = 3516, source = "AckisRecipeList v2.01-14-gfc58e9f" };