local AL = LibStub("AceLocale-3.0"):GetLocale("AtlasLoot");
local GREY = "|cff999999";
local RED = "|cffff0000";
local WHITE = "|cffFFFFFF";
local GREEN = "|cff1eff00";
local PURPLE = "|cff9F3FFF";
local BLUE = "|cff0070dd";
local ORANGE = "|cffFF8400";
local DEFAULT = "|cffFFd200";
local ParseTooltip_Enabled = false;
local AtlasLootScanTooltip = CreateFrame("GAMETOOLTIP","AtlasLootScanTooltip",nil,"GameTooltipTemplate");
AtlasLootScanTooltip:SetOwner(UIParent, "ANCHOR_NONE");
local AtlasLootCraftingTooltip = CreateFrame("GAMETOOLTIP","AtlasLootCraftingTooltip",nil,"GameTooltipTemplate");
AtlasLootCraftingTooltip:SetOwner(UIParent, "ANCHOR_NONE");
local AtlasLootCraftingScanTooltip = CreateFrame("GAMETOOLTIP","AtlasLootCraftingScanTooltip",nil,"GameTooltipTemplate");
AtlasLootCraftingScanTooltip:SetOwner(UIParent, "ANCHOR_NONE");

local function AtlasLoot_CraftingTrim(text)
    if not text then return "" end
    return (gsub(gsub(text, "^%s+", ""), "%s+$", ""));
end

local function AtlasLoot_CraftingPlainText(text)
    if not text then return "" end
    text = AtlasLoot_FixText(text);
    text = gsub(text, "|c%x%x%x%x%x%x%x%x", "");
    text = gsub(text, "|r", "");
    text = gsub(text, "=%a+%d*=", "");
    text = gsub(text, "%s+", " ");
    return AtlasLoot_CraftingTrim(text);
end

local function AtlasLoot_CraftingProfessionName(dataID, sectionText)
    dataID = dataID or "";
    sectionText = AtlasLoot_CraftingPlainText(sectionText);

    if sectionText ~= "" and not string.find(sectionText, "Level", 1, true) then
        return sectionText;
    end

    local professionPrefixes = {
        { "^Alchemy", 2259, "Alchemy" },
        { "^Smithing", 2018, "Blacksmithing" },
        { "^Armorsmith", 2018, "Blacksmithing" },
        { "^Weaponsmith", 2018, "Blacksmithing" },
        { "^Axesmith", 2018, "Blacksmithing" },
        { "^Hammersmith", 2018, "Blacksmithing" },
        { "^Swordsmith", 2018, "Blacksmithing" },
        { "^Cooking", 2550, "Cooking" },
        { "^Enchanting", 7411, "Enchanting" },
        { "^Engineering", 4036, "Engineering" },
        { "^Gnomish", 4036, "Engineering" },
        { "^Goblin", 4036, "Engineering" },
        { "^FirstAid", 3273, "First Aid" },
        { "^Inscription", 45357, "Inscription" },
        { "^Jewel", 25229, "Jewelcrafting" },
        { "^Leather", 2108, "Leatherworking" },
        { "^Dragonscale", 2108, "Leatherworking" },
        { "^Elemental", 2108, "Leatherworking" },
        { "^Tribal", 2108, "Leatherworking" },
        { "^Mining", 2575, "Mining" },
        { "^Tailoring", 3908, "Tailoring" },
        { "^Mooncloth", 3908, "Tailoring" },
        { "^Shadoweave", 3908, "Tailoring" },
        { "^Spellfire", 3908, "Tailoring" },
    };

    for _, profession in ipairs(professionPrefixes) do
        if string.find(dataID, profession[1]) then
            return GetSpellInfo(profession[2]) or profession[3];
        end
    end

    return "";
end

local function AtlasLoot_CraftingSourceContains(sourceText, key)
    local label = AL[key] or key;
    if not label or label == "" then return false end
    return string.find(string.lower(sourceText), string.lower(label), 1, true) ~= nil;
end

local function AtlasLoot_CraftingGetSkillRequirement(sourceText)
    local plain = AtlasLoot_CraftingPlainText(sourceText);
    if plain == "" then return nil end
    if string.find(string.lower(plain), string.lower(AL["Skill Required:"] or "Skill Required"), 1, true) then
        return plain;
    end
    return nil;
end

local function AtlasLoot_CraftingClassifySource(sourceText)
    local plain = AtlasLoot_CraftingPlainText(sourceText);
    if plain == "" or AtlasLoot_CraftingGetSkillRequirement(plain) then
        return "Not listed";
    end
    if AtlasLoot_CraftingSourceContains(plain, "Trainer") then return AL["Trainer"] or "Trainer" end
    if AtlasLoot_CraftingSourceContains(plain, "Vendor") then return AL["Vendor"] or "Vendor" end
    if AtlasLoot_CraftingSourceContains(plain, "World Drop") then return AL["World Drop"] or "World Drop" end
    if AtlasLoot_CraftingSourceContains(plain, "Drop") then return AL["Drop"] or "Drop" end
    if AtlasLoot_CraftingSourceContains(plain, "Discovery") then return AL["Discovery"] or "Discovery" end
    if AtlasLoot_CraftingSourceContains(plain, "Quest") then return AL["Quest"] or "Quest" end

    local lower = string.lower(plain);
    if string.find(plain, ":", 1, true) and (string.find(lower, "neutral", 1, true) or string.find(lower, "friendly", 1, true) or string.find(lower, "honored", 1, true) or string.find(lower, "revered", 1, true) or string.find(lower, "exalted", 1, true)) then
        return "Reputation";
    end

    return "Listed source";
end

local function AtlasLoot_CraftingGetRecipeSource(sourceText)
    local plain = AtlasLoot_CraftingPlainText(sourceText);
    if plain == "" or AtlasLoot_CraftingGetSkillRequirement(plain) then
        return "Not listed in AtlasLoot";
    end
    return plain;
end

local function AtlasLoot_CraftingGetTradeSkillMaterials(spellName)
    if not spellName or not GetNumTradeSkills or not GetTradeSkillInfo or not GetTradeSkillNumReagents or not GetTradeSkillReagentInfo then
        return nil;
    end

    local materials = {};
    for i = 1, GetNumTradeSkills() do
        local tradeSkillName = GetTradeSkillInfo(i);
        if tradeSkillName == spellName then
            for reagentIndex = 1, GetTradeSkillNumReagents(i) do
                local reagentName, _, requiredCount = GetTradeSkillReagentInfo(i, reagentIndex);
                local reagentLink = GetTradeSkillReagentItemLink and GetTradeSkillReagentItemLink(i, reagentIndex);
                if reagentName and requiredCount then
                    table.insert(materials, (reagentLink or reagentName).." x"..requiredCount);
                end
            end
            if #materials > 0 then return materials end
        end
    end

    return nil;
end

local function AtlasLoot_CraftingGetTooltipMaterials(spellID)
    if not spellID then return nil end

    local link = AtlasLoot_GetEnchantLink(spellID);
    if not link then return nil end

    AtlasLootCraftingScanTooltip:SetOwner(UIParent, "ANCHOR_NONE");
    AtlasLootCraftingScanTooltip:ClearLines();
    AtlasLootCraftingScanTooltip:SetHyperlink(link);
    AtlasLootCraftingScanTooltip:Show();

    local materials = {};
    local capture = false;
    for i = 2, 30 do
        local left = getglobal("AtlasLootCraftingScanTooltipTextLeft"..i);
        local right = getglobal("AtlasLootCraftingScanTooltipTextRight"..i);
        local leftText = left and left:GetText();
        local rightText = right and right:GetText();
        local plain = AtlasLoot_CraftingPlainText(leftText);
        local lower = string.lower(plain);

        if plain ~= "" then
            if string.find(lower, "reagent", 1, true) or string.find(lower, "material", 1, true) then
                capture = true;
                local afterColon = string.match(plain, ":%s*(.+)$");
                if afterColon and afterColon ~= "" then
                    table.insert(materials, afterColon);
                end
            elseif capture then
                if string.find(lower, "requires", 1, true) or string.find(lower, "cooldown", 1, true) then
                    break;
                end
                if rightText and rightText ~= "" then
                    table.insert(materials, plain.." "..AtlasLoot_CraftingPlainText(rightText));
                else
                    table.insert(materials, plain);
                end
                if #materials >= 8 then break end
            end
        elseif capture then
            break;
        end
    end

    AtlasLootCraftingScanTooltip:Hide();
    if #materials > 0 then return materials end
    return nil;
end

local function AtlasLoot_CraftingShowTooltip(button)
    local info = button and button.craftingInfo;
    if not info then return end

    local spellName = info.spellID and GetSpellInfo(info.spellID);
    local professionName = AtlasLoot_CraftingProfessionName(info.dataID, info.sectionText);
    local sourceText = info.sourceText or "";
    local skillRequirement = AtlasLoot_CraftingGetSkillRequirement(sourceText);
    local sourceType = info.spellID and AtlasLoot_CraftingClassifySource(sourceText) or "Not listed";
    local recipeSource = info.spellID and AtlasLoot_CraftingGetRecipeSource(sourceText) or "Not listed in AtlasLoot";
    local itemTypeText = (not info.spellID) and AtlasLoot_CraftingPlainText(sourceText) or "";
    local craftedItemName, craftedItemLink = nil, nil;
    if info.craftedItemID then
        craftedItemName, craftedItemLink = GetItemInfo(info.craftedItemID);
    end

    local materials = nil;
    if spellName then
        materials = AtlasLoot_CraftingGetTradeSkillMaterials(spellName) or AtlasLoot_CraftingGetTooltipMaterials(info.spellID);
    end

    AtlasLootCraftingTooltip:SetOwner(button, "ANCHOR_NONE");
    AtlasLootCraftingTooltip:ClearAllPoints();
    if AtlasLootTooltip and AtlasLootTooltip:IsVisible() then
        AtlasLootCraftingTooltip:SetPoint("TOPLEFT", AtlasLootTooltip, "BOTTOMLEFT", 0, -4);
    elseif GameTooltip and GameTooltip:IsVisible() then
        AtlasLootCraftingTooltip:SetPoint("TOPLEFT", GameTooltip, "BOTTOMLEFT", 0, -4);
    else
        AtlasLootCraftingTooltip:SetPoint("TOPLEFT", button, "BOTTOMRIGHT", 0, -4);
    end
    AtlasLootCraftingTooltip:ClearLines();
    AtlasLootCraftingTooltip:AddLine("Crafting Details", 1, 0.82, 0, 1);

    if professionName ~= "" then
        AtlasLootCraftingTooltip:AddDoubleLine("Profession", professionName, 1, 1, 1, 0.8, 0.8, 0.8);
    end
    if spellName then
        AtlasLootCraftingTooltip:AddDoubleLine("Recipe", spellName, 1, 1, 1, 0.8, 0.8, 0.8);
    end
    if craftedItemLink or craftedItemName or info.itemText then
        AtlasLootCraftingTooltip:AddDoubleLine("Crafts", craftedItemLink or craftedItemName or AtlasLoot_CraftingPlainText(info.itemText), 1, 1, 1, 0.8, 0.8, 0.8);
    end
    if skillRequirement then
        AtlasLootCraftingTooltip:AddDoubleLine("Requirement", skillRequirement, 1, 1, 1, 0.8, 0.8, 0.8);
    end
    if itemTypeText ~= "" then
        AtlasLootCraftingTooltip:AddDoubleLine("Item Type", itemTypeText, 1, 1, 1, 0.8, 0.8, 0.8);
    end
    AtlasLootCraftingTooltip:AddDoubleLine("Recipe Source", recipeSource, 1, 1, 1, 0.8, 0.8, 0.8);
    AtlasLootCraftingTooltip:AddDoubleLine("Source Type", sourceType, 1, 1, 1, 0.8, 0.8, 0.8);
    if info.priceText and info.priceText ~= "" then
        AtlasLootCraftingTooltip:AddDoubleLine("Cost", AtlasLoot_CraftingPlainText(info.priceText), 1, 1, 1, 0.8, 0.8, 0.8);
    end
    if info.pageName and info.pageName ~= "" then
        AtlasLootCraftingTooltip:AddDoubleLine("AtlasLoot Page", AtlasLoot_CraftingPlainText(info.pageName), 1, 1, 1, 0.8, 0.8, 0.8);
    end

    AtlasLootCraftingTooltip:AddLine(" ");
    AtlasLootCraftingTooltip:AddLine("Materials", 1, 0.82, 0, 1);
    if materials then
        for _, material in ipairs(materials) do
            AtlasLootCraftingTooltip:AddLine(material, 0.8, 0.8, 0.8, 1);
        end
    elseif info.spellID then
        AtlasLootCraftingTooltip:AddLine("Unavailable from client data. Open the matching profession window to let AtlasLoot read known recipe reagents.", 0.8, 0.8, 0.8, 1);
    else
        AtlasLootCraftingTooltip:AddLine("Unavailable because this AtlasLoot row is an item entry, not a recipe spell.", 0.8, 0.8, 0.8, 1);
    end

    AtlasLootCraftingTooltip:Show();
end


function AtlasLoot_GetEnchantLink(enchantID)
   if not enchantID then return end
   local EnchantLink = nil
   AtlasLootScanTooltip:SetOwner(UIParent, "ANCHOR_NONE")
   AtlasLootScanTooltip:ClearLines();
   AtlasLootScanTooltip:SetHyperlink("enchant:"..enchantID);
   AtlasLootScanTooltip:Show()
   local tooltipline = getglobal("AtlasLootScanTooltipTextLeft1")
   local text = tooltipline:GetText()
   if text and string.find(text, ":") then
      EnchantLink = "|cffffd000|Henchant:"..enchantID.."|h["..text.."]|h|r"
   else
      EnchantLink = GetSpellLink(enchantID)
   end
   AtlasLootScanTooltip:Hide()
   return EnchantLink
end

--------------------------------------------------------------------------------
-- Item OnEnter
-- Called when a loot item is moused over
--------------------------------------------------------------------------------
function AtlasLootItem_OnEnter()
    local isItem;
    AtlasLootTooltip:ClearLines();
    for i=1, 30, 1 do
        if (getglobal("AtlasLootTooltipTextRight"..i) ~= nil) then
            getglobal("AtlasLootTooltipTextRight"..i):SetText("");
        end
    end
    if this.itemID and (this.itemID ~= 0) then
        if string.sub(this.itemID, 1, 1) == "s" then
            isItem = false;
        else
            isItem = true;
        end
        if isItem then
            local color = strsub(getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), 3, 10);
            local name = strsub(getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), 11);
            if(this.itemID ~= 0 and this.itemID ~= "" and this.itemID ~= nil and AtlasLootDKPValues and AtlasLootClassPriority) then
                Identifier = "Item"..this.itemID;
                DKP = AtlasLootDKPValues[Identifier];
                priority = AtlasLootClassPriority[Identifier];
            else
                DKP = nil;
                priority = nil;
            end
            --Lootlink tooltips
            if( AtlasLoot.db.profile.LootlinkTT ) then
                --If we have seen the item, use the game tooltip to minimise same name item problems
                if(GetItemInfo(this.itemID) ~= nil) then
                    getglobal(this:GetName().."_Unsafe"):Hide();
                    AtlasLootTooltip:SetOwner(this, "ANCHOR_RIGHT", -(this:GetWidth() / 2), 24);
                    AtlasLootTooltip:SetHyperlink("item:"..this.itemID..":0:0:0");
                    if ( AtlasLoot.db.profile.ItemIDs ) then
                        AtlasLootTooltip:AddLine(BLUE..AL["ItemID:"].." "..this.itemID, nil, nil, nil, 1);
                    end
                    if( this.droprate ~= nil) then
                        AtlasLootTooltip:AddLine(AL["Drop Rate: "]..this.droprate, 1, 1, 0);
                    end
                    if( DKP ~= nil and DKP ~= "" ) then
                        AtlasLootTooltip:AddLine(RED..DKP.." "..AL["DKP"], 1, 1, 0, 1);
                    end
                    if( priority ~= nil and priority ~= "" ) then
                        AtlasLootTooltip:AddLine(GREEN..AL["Priority:"].." "..priority, 1, 1, 0, 1);
                    end
                    AtlasLootTooltip:Show();
                    if((AtlasLoot.db.profile.EquipCompare and ((not EquipCompare_RegisterTooltip) or (not EquipCompare_Enabled)))) or IsShiftKeyDown() then
                        AtlasLootItem_ShowCompareItem(); --- CALL MISSING METHOD TO SHOW 2 TOOLTIPS (Item Compare)
                    end
                    if (LootLink_AddItem) then
                        LootLink_AddItem(name, this.itemID..":0:0:0", color);
                    end
                else
                    getglobal(this:GetName().."_Unsafe"):Show();
                    AtlasLootTooltip:SetOwner(this, "ANCHOR_RIGHT", -(this:GetWidth() / 2), 24);
                    if (LootLink_Database and LootLink_Database[this.itemID]) then
                       LootLink_SetTooltip(AtlasLootTooltip, LootLink_Database[this.itemID][1], 1);
                    else
                       LootLink_SetTooltip(AtlasLootTooltip,strsub(getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), 11), 1);
                    end
                    if ( AtlasLoot.db.profile.ItemIDs ) then
                        AtlasLootTooltip:AddLine(BLUE..AL["ItemID:"].." "..this.itemID, nil, nil, nil, 1);
                    end
                    if( this.droprate ~= nil) then
                        AtlasLootTooltip:AddLine(AL["Drop Rate: "]..this.droprate, 1, 1, 0, 1);
                    end
                    if( DKP ~= nil and DKP ~= "" ) then
                        AtlasLootTooltip:AddLine(RED..DKP.." "..AL["DKP"], 1, 1, 0);
                    end
                    if( priority ~= nil and priority ~= "" ) then
                        AtlasLootTooltip:AddLine(GREEN..AL["Priority:"].." "..priority, 1, 1, 0);
                    end
                    AtlasLootTooltip:AddLine(" ");
                    AtlasLootTooltip:AddLine(AL["You can right-click to attempt to query the server.  You may be disconnected."], nil, nil, nil, 1);
                    AtlasLootTooltip:Show();
                end
            --Item Sync tooltips
            elseif( AtlasLoot.db.profile.ItemSyncTT ) then
                if(GetItemInfo(this.itemID) ~= nil) then
                    getglobal(this:GetName().."_Unsafe"):Hide();
                end
                ItemSync:ButtonEnter();
                if ( AtlasLoot.db.profile.ItemIDs ) then
                    GameTooltip:AddLine(BLUE..AL["ItemID:"].." "..this.itemID, nil, nil, nil, 1);
                end
                if( this.droprate ~= nil) then
                    GameTooltip:AddLine(AL["Drop Rate: "]..this.droprate, 1, 1, 0);
                end
                if( DKP ~= nil and DKP ~= "" ) then
                    GameTooltip:AddLine(RED..DKP.." "..AL["DKP"], 1, 1, 0);
                end 
                if( priority ~= nil and priority ~= "" ) then
                    GameTooltip:AddLine(GREEN..AL["Priority:"].." "..priority, 1, 1, 0);
                end
                GameTooltip:Show();
                if((AtlasLoot.db.profile.EquipCompare and ((not EquipCompare_RegisterTooltip) or (not EquipCompare_Enabled)))) or IsShiftKeyDown() then
                    GameTooltip_ShowCompareItem(); --- CALL MISSING METHOD TO SHOW 2 TOOLTIPS (Item Compare)
                end
            --Default game tooltips
            else
                if(this.itemID ~= nil) then
                    if(GetItemInfo(this.itemID) ~= nil) then
                        getglobal(this:GetName().."_Unsafe"):Hide();
                        AtlasLootTooltip:SetOwner(this, "ANCHOR_RIGHT", -(this:GetWidth() / 2), 24);
                        AtlasLootTooltip:SetHyperlink("item:"..this.itemID..":0:0:0");
                        if ( AtlasLoot.db.profile.ItemIDs ) then
                            AtlasLootTooltip:AddLine(BLUE..AL["ItemID:"].." "..this.itemID, nil, nil, nil, 1);
                        end
                        if( this.droprate ~= nil) then
                            AtlasLootTooltip:AddLine(AL["Drop Rate: "]..this.droprate, 1, 1, 0);
                        end
                        if( DKP ~= nil and DKP ~= "" ) then
                            AtlasLootTooltip:AddLine(RED..DKP.." "..AL["DKP"], 1, 1, 0);
                        end
                        if( priority ~= nil and priority ~= "" ) then
                            AtlasLootTooltip:AddLine(GREEN..AL["Priority:"].." "..priority, 1, 1, 0);
                        end
                        AtlasLootTooltip:Show();
                        if((AtlasLoot.db.profile.EquipCompare and ((not EquipCompare_RegisterTooltip) or (not EquipCompare_Enabled)))) or IsShiftKeyDown() then
                            AtlasLootItem_ShowCompareItem(); --- CALL MISSING METHOD TO SHOW 2 TOOLTIPS (Item Compare)
                        end
                    else
                        AtlasLootTooltip:SetOwner(this, "ANCHOR_RIGHT", -(this:GetWidth() / 2), 24);
                        AtlasLootTooltip:ClearLines();
                        AtlasLootTooltip:AddLine(RED..AL["Item Unavailable"], nil, nil, nil, 1);
                        AtlasLootTooltip:AddLine(BLUE..AL["ItemID:"].." "..this.itemID, nil, nil, nil, 1);
                        AtlasLootTooltip:AddLine(AL["This item is unsafe.  To view this item without the risk of disconnection, you need to have first seen it in the game world. This is a restriction enforced by Blizzard since Patch 1.10."], nil, nil, nil, 1);
                        AtlasLootTooltip:AddLine(" ");
                        AtlasLootTooltip:AddLine(AL["You can right-click to attempt to query the server.  You may be disconnected."], nil, nil, nil, 1);
                        AtlasLootTooltip:Show();
                    end
                end
            end
        else
            spellID = string.sub(this.itemID, 2);
            AtlasLootTooltip:SetOwner(this, "ANCHOR_RIGHT", -(this:GetWidth() / 2), 24);
            AtlasLootTooltip:ClearLines();
            AtlasLootTooltip:SetHyperlink(AtlasLoot_GetEnchantLink(spellID));
            AtlasLootTooltip:Show();
            if(this.spellitemID and ((AtlasLoot.db.profile.EquipCompare and ((not EquipCompare_RegisterTooltip) or (not EquipCompare_Enabled))) or IsShiftKeyDown())) then
                AtlasLootItem_ShowCompareItem(); --- CALL MISSING METHOD TO SHOW 2 TOOLTIPS (Item Compare)
            end    
        end
    end
    AtlasLoot_CraftingShowTooltip(this);
end

--------------------------------------------------------------------------------
-- Item OnLeave
-- Called when the mouse cursor leaves a loot item
--------------------------------------------------------------------------------
function AtlasLootItem_OnLeave()
    --Hide the necessary tooltips
    AtlasLootCraftingTooltip:Hide();
    if( AtlasLoot.db.profile.LootlinkTT ) then
        AtlasLootTooltip:Hide();
    elseif( AtlasLoot.db.profile.ItemSyncTT ) then
        if(GameTooltip:IsVisible()) then
            GameTooltip:Hide();
        end
    else
        if(this.itemID ~= nil) then
		    AtlasLootTooltip:Hide();
            GameTooltip:Hide();
	    end
    end
    if ( ShoppingTooltip2:IsVisible() or ShoppingTooltip1.IsVisible) then
       ShoppingTooltip2:Hide();
       ShoppingTooltip1:Hide();
    end
end

--------------------------------------------------------------------------------
-- Item OnClick
-- Called when a loot item is clicked on
--------------------------------------------------------------------------------
function AtlasLootItem_OnClick(arg1)
    local isItem;
	local color = strsub(getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), 1, 10);
	local id = this:GetID();
	local name = strsub(getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), 11);
    if string.sub(this.itemID, 1, 1) == "s" then
            isItem = false;
        else
            isItem = true;
        end
    if isItem then
        local iteminfo = GetItemInfo(this.itemID);
        local itemName, itemLink, itemQuality, itemLevel, itemMinLevel, itemType, itemSubType, itemCount, itemEquipLoc, itemTexture = GetItemInfo(this.itemID);
        --If shift-clicked, link in the chat window
        if(arg1=="RightButton" and not iteminfo and this.itemID ~= 0) then
            AtlasLootTooltip:SetHyperlink("item:"..this.itemID..":0:0:0:0:0:0:0");
            if not AtlasLoot.db.profile.ItemSpam then
                DEFAULT_CHAT_FRAME:AddMessage(AL["Server queried for "]..color.."["..name.."]".."|r"..AL[".  Right click on any other item to refresh the loot page."]);
            end
            AtlasLootItemsFrame:Hide();
            AtlasLoot_ShowItemsFrame(AtlasLootItemsFrame.refresh[1], AtlasLootItemsFrame.refresh[2], AtlasLootItemsFrame.refresh[3], AtlasLootItemsFrame.refresh[4]);
        elseif(arg1=="RightButton" and iteminfo) then
            AtlasLootItemsFrame:Hide();
            AtlasLoot_ShowItemsFrame(AtlasLootItemsFrame.refresh[1], AtlasLootItemsFrame.refresh[2], AtlasLootItemsFrame.refresh[3], AtlasLootItemsFrame.refresh[4]);
            if not AtlasLoot.db.profile.ItemSpam then
                DEFAULT_CHAT_FRAME:AddMessage(itemLink..AL[" is safe."]);
            end
        elseif(IsShiftKeyDown() and iteminfo and (AtlasLoot.db.profile.SafeLinks or AtlasLoot.db.profile.AllLinks)) then
            ChatEdit_InsertLink(itemLink);
        elseif(IsShiftKeyDown() and AtlasLoot.db.profile.AllLinks) then
            ChatEdit_InsertLink(color.."|Hitem:"..this.itemID..":0:0:0:0:0:0:0|h["..name.."]|h|r");
        elseif(ChatFrameEditBox and ChatFrameEditBox:IsVisible() and IsShiftKeyDown()) then
            ChatFrameEditBox:Insert(name);  -- <-- this line just inserts plain text, does not need any adjustment
        --If control-clicked, use the dressing room
        elseif(IsControlKeyDown() and iteminfo) then
            DressUpItemLink(itemLink);
        elseif(IsAltKeyDown() and (this.itemID ~= 0)) then
            if AtlasLootItemsFrame.refresh[1] == "WishList" then
                AtlasLoot_DeleteFromWishList(this.itemID);
            elseif AtlasLootItemsFrame.refresh[1] == "SearchResult" then
            	AtlasLoot:GetOriginalDataFromSearchResult(this.itemID);
            else
                AtlasLoot_ShowWishListDropDown(this.itemID, this.itemTexture, getglobal("AtlasLootItem_"..this:GetID().."_Name"):GetText(), AtlasLoot_BossName:GetText(), AtlasLootItemsFrame.refreshOri[1].."|"..AtlasLootItemsFrame.refreshOri[2], this);
            end
        elseif((AtlasLootItemsFrame.refresh[1] == "SearchResult" or AtlasLootItemsFrame.refresh[1] == "WishList") and this.sourcePage) then
            local dataID, dataSource = strsplit("|", this.sourcePage);
            if(dataID and dataSource and AtlasLoot_IsLootTableAvailable(dataID)) then
                AtlasLoot_ShowItemsFrame(dataID, dataSource, AtlasLoot_TableNames[dataID][1], AtlasLootItemsFrame.refresh[4]);
            end
        end
    else
        if IsShiftKeyDown() then
            spellID = string.sub(this.itemID, 2);
            ChatEdit_InsertLink(AtlasLoot_GetEnchantLink(spellID));
        elseif(IsAltKeyDown() and (this.itemID ~= 0)) then
            if AtlasLootItemsFrame.refresh[1] == "WishList" then
                AtlasLoot_DeleteFromWishList(this.itemID);
            else
                spellName, _, _, _, _, _, _, _, _ = GetSpellInfo(string.sub(this.itemID, 2));
                --spellIcon = GetItemIcon(this.dressingroomID);
                AtlasLoot_ShowWishListDropDown(this.itemID, this.dressingroomID, "=ds="..spellName, "=ds="..AtlasLootItemsFrame.refresh[3], AtlasLootItemsFrame.refreshOri[1].."|"..AtlasLootItemsFrame.refreshOri[2],this);
            end
        elseif(IsControlKeyDown()) then
            DressUpItemLink("item:"..this.dressingroomID..":0:0:0:0:0:0:0");
        elseif((AtlasLootItemsFrame.refresh[1] == "SearchResult" or AtlasLootItemsFrame.refresh[1] == "WishList") and this.sourcePage) then
            local dataID, dataSource = strsplit("|", this.sourcePage);
            if(dataID and dataSource and AtlasLoot_IsLootTableAvailable(dataID)) then
                AtlasLoot_ShowItemsFrame(dataID, dataSource, AtlasLootItemsFrame.refresh[3], AtlasLootItemsFrame.refresh[4]);
            end
        end
    end
end

-------
-- Missing GameToolTip method
-- Enables item comparing. I've ripped this method directly from GameTooltip.lua and modified to work with AtlasLootTooltip /siena
-------
function AtlasLootItem_ShowCompareItem()
   local shift = 1;
   local item,link = nil,nil
   if this.spellitemID and this.spellitemID ~= "" and this.spellitemID ~= 0 then
      item = AtlasLootTooltip:GetSpell()
      _,link = GetItemInfo(this.spellitemID)
   else
      item,link = AtlasLootTooltip:GetItem();
   end

   if ( not link ) then
      return
   end
   
   ShoppingTooltip1:SetOwner(AtlasLootTooltip, "ANCHOR_NONE");
   ShoppingTooltip2:SetOwner(AtlasLootTooltip, "ANCHOR_NONE");
   ShoppingTooltip3:SetOwner(AtlasLootTooltip, "ANCHOR_NONE");
   
   local item1 = nil;
   local item2 = nil;
   local item3 = nil;
   local side = "left";
   if ( ShoppingTooltip1:SetHyperlinkCompareItem(link, 1, 1, AtlasLootTooltip) ) then
      item1 = true;
   end
   if ( ShoppingTooltip2:SetHyperlinkCompareItem(link, 2, 1, AtlasLootTooltip) ) then
      item2 = true;
   end
   if ( ShoppingTooltip3:SetHyperlinkCompareItem(link, 3, 1, AtlasLootTooltip) ) then
      item3 = true;
   end
   if not item1 and not item2 and not item3 then 
        return 
    end
   
   if item3 then
        if not item1 then
            item1, item3 = true, nil;
            ShoppingTooltip1:SetHyperlinkCompareItem(link, 3, 1, AtlasLootTooltip);
        elseif not item2 then
            item2, item3 = true, nil;
            ShoppingTooltip2:SetHyperlinkCompareItem(link, 3, 1, AtlasLootTooltip);
        end
    end
    if item2 and not item1 then
        item1, item2 = true, nil;
        ShoppingTooltip1:SetHyperlinkCompareItem(link, 2, 1, AtlasLootTooltip);
    end
   
   local left, right, anchor1, anchor2 = AtlasLootTooltip:GetLeft(), AtlasLootTooltip:GetRight(), "TOPLEFT", "TOPRIGHT";
   if not left or not right then return end
	if (GetScreenWidth() - right) < left then anchor1, anchor2 = anchor2, anchor1 end
    
    if item1 then
		ShoppingTooltip1:ClearAllPoints();
		ShoppingTooltip1:SetPoint(anchor1, AtlasLootTooltip, anchor2, 0, -10);
		ShoppingTooltip1:Show();

		if item2 then
			ShoppingTooltip2:ClearAllPoints();
			ShoppingTooltip2:SetPoint(anchor1, ShoppingTooltip1, anchor2);
			ShoppingTooltip2:Show();
		end
        
        if item3 then
			ShoppingTooltip3:ClearAllPoints();
			ShoppingTooltip3:SetPoint(anchor1, ShoppingTooltip2, anchor2);
			ShoppingTooltip3:Show();
		end
	end
    
end

   
